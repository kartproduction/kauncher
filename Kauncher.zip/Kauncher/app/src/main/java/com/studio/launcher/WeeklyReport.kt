package com.studio.launcher

import android.app.AlarmManager
import android.app.AppOpsManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.temporal.TemporalAdjusters

// ---------------------------------------------------------------------------------------------
// Weekly report: how long you used your phone last week, which apps, and more or less than the
// week before. Everything is worked out on the phone from Android's own usage data. Nothing is
// uploaded. It is opt-in (Kettings > Weekly report) because Android asks for "Usage access".
// ---------------------------------------------------------------------------------------------

const val WR_CHANNEL = "weekly_report"
const val WR_PREFS = "weeklyReport"            // its own small prefs file
private const val WR_ALARM_CODE = 4401

class AppUse(val pkg: String, val label: String, val ms: Long)
class LimitStat(val label: String, val limitMin: Int, val daysHit: Int, val shown: Int)
class WeekSummary(
    val startDay: LocalDate, val totalMs: Long, val perDay: LongArray, val top: List<AppUse>,
    val focusMin: Int = 0, val paused: Int = 0, val skipped: Int = 0, val made: List<String> = emptyList(),
    val capMin: Int = 0, val capOver: Int = 0, val intDone: Int = 0, val intTotal: Int = 0, val limits: List<LimitStat> = emptyList()
)

fun studioPrefs(ctx: Context) = ctx.getSharedPreferences("studio", Context.MODE_PRIVATE)

fun dayOfMs(t: Long): LocalDate = java.time.Instant.ofEpochMilli(t).atZone(ZoneId.systemDefault()).toLocalDate()
fun inWeek(d: LocalDate, start: LocalDate) = !d.isBefore(start) && !d.isAfter(start.plusDays(6))

fun weeklyGoalMin(ctx: Context) = studioPrefs(ctx).getInt("weeklyGoalMin", 0)       // 0 = no goal

// Focus minutes in one Sunday-to-Saturday week, from the focus log.
fun focusMinutesInWeek(ctx: Context, start: LocalDate): Int =
    loadFocusLog(studioPrefs(ctx)).filter { inWeek(dayOfMs(it.t), start) }.sumOf { it.min }

// How many finished weeks in a row (ending with the week that starts on `start`) reached the goal.
fun goalWeekStreak(ctx: Context, start: LocalDate): Int {
    val goal = weeklyGoalMin(ctx)
    if (goal <= 0) return 0
    val log = loadFocusLog(studioPrefs(ctx))
    var n = 0
    var w = start
    while (n < 52) {
        val m = log.filter { inWeek(dayOfMs(it.t), w) }.sumOf { it.min }
        if (m < goal) break
        n++; w = w.minusDays(7)
    }
    return n
}

// ---- Permission and switch -------------------------------------------------------------------

fun hasUsageAccess(ctx: Context): Boolean {
    val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
    val mode = if (Build.VERSION.SDK_INT >= 29)
        ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
    else
        @Suppress("DEPRECATION") ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
    return mode == AppOpsManager.MODE_ALLOWED
}

fun openUsageAccessSettings(ctx: Context) {
    try { ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (e: Exception) { openPhoneSettings(ctx, "android.settings.SETTINGS") }
}

fun weeklyReportOn(ctx: Context) = ctx.getSharedPreferences(WR_PREFS, Context.MODE_PRIVATE).getBoolean("on", false)

fun setWeeklyReportOn(ctx: Context, on: Boolean) {
    ctx.getSharedPreferences(WR_PREFS, Context.MODE_PRIVATE).edit().putBoolean("on", on).apply()
    if (on) scheduleWeeklyReport(ctx) else cancelWeeklyReport(ctx)
}

// ---- Reading the usage data ------------------------------------------------------------------

fun labelFor(ctx: Context, pkg: String): String = try {
    val pm = ctx.packageManager
    pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
} catch (e: Exception) { pkg }

// Adds up how long each app was on screen between from and to, using resume/pause events.
// Kauncher itself is left out, because the home screen is where you "rest" between apps.
fun usageBetween(ctx: Context, from: Long, to: Long): Map<String, Long> {
    val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
    val ev = usm.queryEvents(from, to)
    val e = UsageEvents.Event()
    val started = HashMap<String, Long>()
    val total = HashMap<String, Long>()
    fun stop(pkg: String, at: Long) {
        val s = started.remove(pkg) ?: return
        if (at > s) total[pkg] = (total[pkg] ?: 0L) + (at - s)
    }
    while (ev.hasNextEvent()) {
        ev.getNextEvent(e)
        val pkg = e.packageName ?: continue
        if (pkg == ctx.packageName) continue
        when (e.eventType) {
            UsageEvents.Event.ACTIVITY_RESUMED -> { stop(pkg, e.timeStamp); started[pkg] = e.timeStamp }
            UsageEvents.Event.ACTIVITY_PAUSED, UsageEvents.Event.ACTIVITY_STOPPED -> stop(pkg, e.timeStamp)
        }
    }
    for (pkg in started.keys.toList()) stop(pkg, to)
    return total
}

fun dayStartMs(d: LocalDate) = d.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()

// One Sunday-to-Saturday week that starts on startDay.
fun summarizeWeek(ctx: Context, startDay: LocalDate, withUsage: Boolean = true): WeekSummary {
    val perDay = LongArray(7)
    val perApp = HashMap<String, Long>()
    val dayMaps = ArrayList<Map<String, Long>>()
    for (i in 0 until 7) {
        if (!withUsage) break
        val d = startDay.plusDays(i.toLong())
        val m = usageBetween(ctx, dayStartMs(d), dayStartMs(d.plusDays(1)))
        dayMaps.add(m)
        perDay[i] = m.values.sum()
        for ((k, v) in m) perApp[k] = (perApp[k] ?: 0L) + v
    }
    val top = perApp.entries.sortedByDescending { it.value }.take(3).map { AppUse(it.key, labelFor(ctx, it.key), it.value) }
    val sp = studioPrefs(ctx)
    val fl = loadFocusLog(sp).filter { inWeek(dayOfMs(it.t), startDay) }
    val made = fl.filter { it.done && it.note.isNotBlank() }.map { (if (it.what.isBlank()) "" else it.what + ": ") + it.note }
    val pl = loadPauseLog(sp).filter { inWeek(dayOfMs(it.first), startDay) }
    val cap = phoneCapMin(ctx)
    val (iDone, iTotal) = intentionsInWeek(sp, startDay)
    val hits = loadLimitLog(sp).filter { inWeek(dayOfMs(it.first), startDay) }.groupingBy { it.second }.eachCount()
    val limits = loadAppLimits(sp).map { (pkg, min) ->
        LimitStat(labelFor(ctx, pkg), min, dayMaps.count { (it[pkg] ?: 0L) >= min * 60_000L }, hits[pkg] ?: 0)
    }.sortedByDescending { it.shown }
    return WeekSummary(
        startDay, perDay.sum(), perDay, top, fl.sumOf { it.min }, pl.size, pl.count { !it.second }, made,
        cap, if (withUsage) daysOverCap(perDay, cap) else 0, iDone, iTotal, limits
    )
}

// The Sunday that began the most recent finished week (Sunday to Saturday), as of today.
fun lastFinishedWeekStart(today: LocalDate = LocalDate.now()): LocalDate =
    today.with(TemporalAdjusters.previousOrSame(DayOfWeek.SUNDAY)).minusDays(7)

// Android only keeps a few days of detailed events, so last week's total is saved on the phone
// the first time it is worked out. That saved number is what next week is compared against.
private fun saveSummary(ctx: Context, s: WeekSummary) {
    val p = ctx.getSharedPreferences(WR_PREFS, Context.MODE_PRIVATE)
    val o = JSONObject(p.getString("weeks", "{}") ?: "{}")
    o.put(s.startDay.toString(), JSONObject().put("total", s.totalMs).put("perDay", JSONArray(s.perDay.toList())))
    // keep only the latest 12 weeks
    val keys = o.keys().asSequence().toList().sortedDescending()
    for (k in keys.drop(12)) o.remove(k)
    p.edit().putString("weeks", o.toString()).apply()
}

fun savedTotalMs(ctx: Context, startDay: LocalDate): Long? {
    val o = JSONObject(ctx.getSharedPreferences(WR_PREFS, Context.MODE_PRIVATE).getString("weeks", "{}") ?: "{}")
    val w = o.optJSONObject(startDay.toString()) ?: return null
    return w.optLong("total", -1L).takeIf { it >= 0 }
}

fun fmtMs(ms: Long): String {
    val m = (ms / 60000).toInt()
    return if (m < 60) "$m min" else "${m / 60} h ${m % 60} m"
}

// "5 h 30 m a day, 1 h 5 m less than the week before"
fun comparisonText(thisMs: Long, lastMs: Long?): String {
    if (lastMs == null) return "This is your first report. Next Sunday it will compare with this week."
    val diff = thisMs - lastMs
    val pct = if (lastMs > 0) Math.abs(diff) * 100 / lastMs else 0
    return when {
        Math.abs(diff) < 60_000 -> "About the same as the week before."
        diff < 0 -> "${fmtMs(-diff)} less than the week before (down $pct%). Nice."
        else -> "${fmtMs(diff)} more than the week before (up $pct%)."
    }
}

// "You stayed under 4 h on every day." / "You went over 4 h on 2 days."
fun capSentence(s: WeekSummary): String =
    if (s.capOver == 0) "You stayed under ${fmtDur(s.capMin)} a day on every day ✓"
    else "You went over ${fmtDur(s.capMin)} a day on ${s.capOver} ${if (s.capOver == 1) "day" else "days"}."

// ---- Notification ----------------------------------------------------------------------------

fun postWeeklyReport(ctx: Context) {
    if (!hasUsageAccess(ctx)) return
    val start = lastFinishedWeekStart()
    val key = start.toString()
    val p = ctx.getSharedPreferences(WR_PREFS, Context.MODE_PRIVATE)
    if (p.getString("lastNotified", "") == key) return          // one report per week
    val s = summarizeWeek(ctx, start)
    val prev = savedTotalMs(ctx, start.minusDays(7))
    saveSummary(ctx, s)
    p.edit().putString("lastNotified", key).apply()

    val avg = s.totalMs / 7
    val title = "Your week: ${fmtMs(avg)} a day on your phone"
    val apps = if (s.top.isEmpty()) "No app use recorded." else "Most used: " + s.top.joinToString(", ") { "${it.label} ${fmtMs(it.ms)}" }
    val goal = weeklyGoalMin(ctx)
    val focusLine = "Focus: ${fmtDur(s.focusMin)}" + (if (goal > 0) " of ${fmtDur(goal)} goal" + (if (s.focusMin >= goal) " ✓" else "") else "") +
        " · Phone: ${fmtMs(s.totalMs)}"
    val pauseLine = if (s.paused > 0) "\nYou paused ${s.paused} times before opening apps and chose not to open ${s.skipped}." else ""
    val capLine = if (s.capMin > 0) "\n" + capSentence(s) else ""
    val intLine = if (s.intTotal > 0) "\nIntentions: ${s.intDone} of ${s.intTotal} done." else ""
    val limitLine = if (s.limits.any { it.shown > 0 }) "\nApp limits: " + s.limits.filter { it.shown > 0 }.joinToString(", ") { "${it.label} ${it.shown}x" } + "." else ""
    val body = comparisonText(s.totalMs, prev) + capLine + "\n" + focusLine + "\n" + apps + pauseLine + intLine + limitLine

    val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (Build.VERSION.SDK_INT >= 26)
        nm.createNotificationChannel(NotificationChannel(WR_CHANNEL, "Weekly report", NotificationManager.IMPORTANCE_DEFAULT))
    if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) return
    val open = PendingIntent.getActivity(
        ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("openWeeklyReport", true),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    val n = android.app.Notification.Builder(ctx, WR_CHANNEL)
        .setSmallIcon(android.R.drawable.ic_menu_recent_history)
        .setContentTitle(title)
        .setContentText(body.lineSequence().first())
        .setStyle(android.app.Notification.BigTextStyle().bigText(body))
        .setContentIntent(open)
        .setAutoCancel(true)
        .build()
    nm.notify(WR_ALARM_CODE, n)
}

// ---- Sunday 9:00 alarm -----------------------------------------------------------------------

private fun alarmIntent(ctx: Context) = PendingIntent.getBroadcast(
    ctx, WR_ALARM_CODE, Intent(ctx, WeeklyReportReceiver::class.java),
    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
)

fun nextSundayNine(now: LocalDateTime = LocalDateTime.now()): LocalDateTime {
    var t = now.with(TemporalAdjusters.nextOrSame(DayOfWeek.SUNDAY)).with(LocalTime.of(9, 0))
    if (!t.isAfter(now)) t = t.plusWeeks(1)
    return t
}

// Inexact alarm: needs no special permission. Android may deliver it a little late, which is fine.
fun scheduleWeeklyReport(ctx: Context) {
    if (!weeklyReportOn(ctx)) return
    val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val at = nextSundayNine().atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, alarmIntent(ctx))
}

fun cancelWeeklyReport(ctx: Context) {
    (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(alarmIntent(ctx))
}

// If the phone was off or the alarm was late on Sunday, send the report the next time Kauncher opens.
fun catchUpWeeklyReport(ctx: Context) {
    if (!weeklyReportOn(ctx)) return
    scheduleWeeklyReport(ctx)
    val p = ctx.getSharedPreferences(WR_PREFS, Context.MODE_PRIVATE)
    val due = lastFinishedWeekStart().plusDays(7)               // the Sunday after that week
    val sundayNine = due.atTime(9, 0)
    if (p.getString("lastNotified", "") != lastFinishedWeekStart().toString() && LocalDateTime.now().isAfter(sundayNine))
        postWeeklyReport(ctx)
}

class WeeklyReportReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent?) {
        try { postWeeklyReport(ctx) } catch (e: Exception) { }
        scheduleWeeklyReport(ctx)                                // book next Sunday
    }
}

class WeeklyReportBootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent?) { scheduleWeeklyReport(ctx) }
}

// ---- The report screen (Kettings > Weekly report) --------------------------------------------

@Composable
fun WeeklyReportScreen(ctx: Context, ink: Color, mute: Color, surface: Color, line: Color, accent: Color, onClose: () -> Unit) {
    var tick by remember { mutableStateOf(0) }                   // bump to refresh after a change
    val allowed = remember(tick) { hasUsageAccess(ctx) }
    val on = remember(tick) { weeklyReportOn(ctx) }
    val start = remember { lastFinishedWeekStart() }
    val summary = remember(tick, allowed) { try { summarizeWeek(ctx, start, allowed) } catch (e: Exception) { null } }
    val prev = remember(tick) { savedTotalMs(ctx, start.minusDays(7)) }
    val goal = remember(tick) { weeklyGoalMin(ctx) }
    val goalStreak = remember(tick) { goalWeekStreak(ctx, start) }
    val days = listOf("S", "M", "T", "W", "T", "F", "S")
    val madeWeek = remember(tick) { loadMade(studioPrefs(ctx)).filter { inWeek(dayOfMs(it.t), start) } }
    val madeNow = remember(tick) { loadMade(studioPrefs(ctx)).count { inWeek(dayOfMs(it.t), LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.SUNDAY))) } }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null && addMadeFile(ctx, uri)) tick++ }

    @Composable
    fun Header(text: String) = Text(text.uppercase(), color = mute, fontSize = 12.sp, letterSpacing = 1.sp, modifier = Modifier.padding(top = 28.dp, bottom = 4.dp))

    Box(
        Modifier.fillMaxSize().background(surface).pointerInput(Unit) { detectTapGestures { } }
            .padding(horizontal = 26.dp, vertical = 20.dp)
    ) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Weekly report", color = ink, fontSize = 30.sp, fontWeight = FontWeight.Light, modifier = Modifier.weight(1f))
                Text("Close", color = accent, fontSize = 16.sp, modifier = Modifier.clickable { onClose() }.padding(8.dp))
            }
            Text("${start.month.name.lowercase().replaceFirstChar { it.uppercase() }} ${start.dayOfMonth} to ${start.plusDays(6).dayOfMonth}", color = mute, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp))

            if (summary == null) {
                Text("Couldn’t read your week this time.", color = mute, fontSize = 15.sp, modifier = Modifier.padding(top = 24.dp))
            } else {
                // ---- Focus (always shown)
                Header("Focus")
                Text(fmtDur(summary.focusMin), color = ink, fontSize = 44.sp, fontWeight = FontWeight.Light)
                Text(if (allowed) "of focus work, and ${fmtMs(summary.totalMs)} on your phone" else "of focus work last week", color = mute, fontSize = 14.sp)
                if (goal > 0) {
                    val frac = (summary.focusMin.toFloat() / goal).coerceIn(0f, 1f)
                    Box(Modifier.fillMaxWidth().padding(top = 14.dp).height(8.dp).clip(RoundedCornerShape(4.dp)).background(line)) {
                        Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(accent))
                    }
                    Text(
                        "Goal ${fmtDur(goal)}" + (if (summary.focusMin >= goal) " reached ✓" else ": ${fmtDur(goal - summary.focusMin)} short") +
                            (if (goalStreak > 1) " · $goalStreak weeks in a row" else ""),
                        color = accent, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp)
                    )
                }
                Row(Modifier.fillMaxWidth().clickable {
                    val opts = listOf(0, 300, 600, 900, 1200)
                    studioPrefs(ctx).edit().putInt("weeklyGoalMin", opts[(opts.indexOf(goal).coerceAtLeast(0) + 1) % opts.size]).apply(); tick++
                }.padding(top = 14.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Weekly focus goal", color = ink, fontSize = 17.sp, modifier = Modifier.weight(1f))
                    Text(if (goal == 0) "Off" else fmtDur(goal), color = accent, fontSize = 15.sp)
                }

                // ---- Phone time
                if (!allowed) {
                    Header("Phone time")
                    Text("To see your phone time, Kauncher needs “Usage access”. It reads how long apps were open, on this phone only. Nothing is uploaded.",
                        color = ink, fontSize = 16.sp)
                    Text("Allow usage access", color = accent, fontSize = 17.sp,
                        modifier = Modifier.clickable { openUsageAccessSettings(ctx) }.padding(vertical = 14.dp))
                    Text("I’ve allowed it", color = mute, fontSize = 15.sp, modifier = Modifier.clickable { tick++ }.padding(vertical = 6.dp))
                } else {
                    Header("Phone time")
                    Text(fmtMs(summary.totalMs / 7), color = ink, fontSize = 44.sp, fontWeight = FontWeight.Light)
                    Text("Daily average screen time", color = mute, fontSize = 14.sp)
                    Text(comparisonText(summary.totalMs, prev), color = accent, fontSize = 15.sp, modifier = Modifier.padding(top = 10.dp))
                    if (summary.capMin > 0) Text(capSentence(summary), color = accent, fontSize = 15.sp, modifier = Modifier.padding(top = 6.dp))
                    Row(Modifier.fillMaxWidth().clickable {
                        studioPrefs(ctx).edit().putInt("phoneCapMin", nextOption(PHONE_CAP_OPTIONS, phoneCapMin(ctx))).apply(); tick++
                    }.padding(top = 14.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Daily phone time cap", color = ink, fontSize = 17.sp, modifier = Modifier.weight(1f))
                        Text(hrsText(phoneCapMin(ctx)), color = accent, fontSize = 15.sp)
                    }
                    val maxMs = (summary.perDay.maxOrNull() ?: 1L).coerceAtLeast(1L)
                    Row(Modifier.fillMaxWidth().padding(top = 22.dp).height(130.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                        for (i in 0 until 7) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(Modifier.width(22.dp).height((100.dp * (summary.perDay[i].toFloat() / maxMs)).coerceAtLeast(3.dp))
                                    .clip(RoundedCornerShape(11.dp)).background(accent))
                                Text(days[i], color = mute, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                            }
                        }
                    }
                    Header("Most used apps")
                    if (summary.top.isEmpty()) Text("No app use recorded for this week.", color = mute, fontSize = 15.sp)
                    for (a in summary.top) {
                        Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(a.label, color = ink, fontSize = 18.sp, modifier = Modifier.weight(1f))
                            Text(fmtMs(a.ms), color = accent, fontSize = 16.sp)
                        }
                        Box(Modifier.fillMaxWidth().height(1.dp).background(line))
                    }
                }

                // ---- Pauses
                if (summary.paused > 0) {
                    Header("Pauses")
                    Text("You paused ${summary.paused} times before opening an app and chose not to open it ${summary.skipped} times.", color = ink, fontSize = 16.sp)
                }

                // ---- Intentions
                if (summary.intTotal > 0) {
                    Header("Intentions")
                    Text("You ticked off ${summary.intDone} of ${summary.intTotal} intentions this week.", color = ink, fontSize = 16.sp)
                }

                // ---- App limits
                if (summary.limits.isNotEmpty() && allowed) {
                    Header("App limits")
                    for (l in summary.limits) {
                        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(l.label, color = ink, fontSize = 17.sp)
                                Text("Limit ${fmtDur(l.limitMin)} a day", color = mute, fontSize = 13.sp)
                            }
                            Text(
                                (if (l.daysHit == 0) "Under it all week ✓" else "Reached on ${l.daysHit} ${if (l.daysHit == 1) "day" else "days"}") +
                                    (if (l.shown > 0) " · pause shown ${l.shown}x" else ""),
                                color = accent, fontSize = 13.sp
                            )
                        }
                    }
                }

                // ---- Things made
                if (summary.made.isNotEmpty() || madeWeek.isNotEmpty()) {
                    Header("What you made")
                    if (madeWeek.isNotEmpty()) MadeRow(ctx, madeWeek, ink, mute, line)
                    for (m in summary.made.take(8)) Text("• $m", color = ink, fontSize = 16.sp, modifier = Modifier.padding(vertical = 3.dp))
                }
            }

            Header("Add what you made")
            Text("Made something outside the phone? Add a photo or file of it. It shows in the report for the week you add it" + (if (madeNow > 0) " ($madeNow so far this week)." else "."), color = mute, fontSize = 14.sp)
            Text("Add a photo or file", color = accent, fontSize = 17.sp, modifier = Modifier.clickable { filePicker.launch("*/*") }.padding(vertical = 12.dp))

            Header("Sunday notification")
            Row(Modifier.fillMaxWidth().clickable {
                if (!allowed) { openUsageAccessSettings(ctx) } else {
                    setWeeklyReportOn(ctx, !on); tick++
                    if (!on && android.os.Build.VERSION.SDK_INT >= 33 &&
                        ctx.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED)
                        findActivity(ctx)?.requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 44)
                }
            }.padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Send my report every Sunday morning", color = ink, fontSize = 17.sp, modifier = Modifier.weight(1f))
                Text(if (on && allowed) "On" else "Off", color = accent, fontSize = 15.sp)
            }
            Text("Needs Usage access, and notifications allowed for Kauncher. Phone time is counted from the apps you open; Kauncher’s own home screen is not counted.",
                color = mute, fontSize = 13.sp, modifier = Modifier.padding(bottom = 40.dp))
        }
    }
}
