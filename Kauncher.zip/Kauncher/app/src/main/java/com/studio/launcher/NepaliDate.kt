package com.studio.launcher

import java.time.LocalDate
import java.time.temporal.ChronoUnit

/**
 * Nepali (BS) date for the home screen. The month lengths and festival list are copied from
 * Kalendar by Kasign (www/index.html), so both apps agree. BS data covers 2082-2088 only.
 * Baisakh 1, 2083 BS = 14 April 2026.
 */
object NepaliDate {
    private const val FIRST_YEAR = 2082
    private val ANCHOR: LocalDate = LocalDate.of(2026, 4, 14)

    private val MONTH_DAYS = arrayOf(
        intArrayOf(30,32,31,32,31,30,30,30,29,30,30,30),  // 2082
        intArrayOf(31,31,32,31,31,31,30,29,30,29,30,30),  // 2083
        intArrayOf(31,31,32,31,31,31,30,29,30,29,30,30),  // 2084
        intArrayOf(31,32,31,32,30,31,30,30,29,30,30,30),  // 2085
        intArrayOf(30,32,31,32,31,30,30,30,29,30,30,30),  // 2086
        intArrayOf(31,31,32,31,31,31,30,30,29,30,30,30),  // 2087
        intArrayOf(30,31,32,32,30,31,30,30,29,30,30,30),  // 2088
    )

    // {start, end, English name, Nepali name}
    private val FEST = arrayOf(
        arrayOf("2026-04-14", "2026-04-14", "Nepali New Year 2083", "नयाँ वर्ष २०८३"),
        arrayOf("2026-05-01", "2026-05-01", "Buddha Jayanti · Labour Day", "बुद्ध जयन्ती · श्रमिक दिवस"),
        arrayOf("2026-05-29", "2026-05-29", "Republic Day", "गणतन्त्र दिवस"),
        arrayOf("2026-08-28", "2026-08-28", "Janai Purnima", "जनै पूर्णिमा"),
        arrayOf("2026-08-29", "2026-08-29", "Gai Jatra", "गाईजात्रा"),
        arrayOf("2026-09-04", "2026-09-04", "Krishna Janmashtami", "कृष्ण जन्माष्टमी"),
        arrayOf("2026-09-14", "2026-09-14", "Haritalika Teej", "हरितालिका तीज"),
        arrayOf("2026-09-19", "2026-09-19", "Constitution Day", "संविधान दिवस"),
        arrayOf("2026-09-25", "2026-09-25", "Indra Jatra", "इन्द्रजात्रा"),
        arrayOf("2026-10-04", "2026-10-04", "Jitiya", "जितिया"),
        arrayOf("2026-10-11", "2026-10-11", "Ghatasthapana", "घटस्थापना"),
        arrayOf("2026-10-17", "2026-10-23", "Dashain holidays", "दशैं बिदा"),
        arrayOf("2026-10-21", "2026-10-21", "Vijaya Dashami", "विजया दशमी"),
        arrayOf("2026-11-07", "2026-11-07", "Kaag Tihar", "काग तिहार"),
        arrayOf("2026-11-08", "2026-11-08", "Laxmi Puja · Kukur Tihar", "लक्ष्मी पूजा · कुकुर तिहार"),
        arrayOf("2026-11-09", "2026-11-09", "Gai Tihar", "गाई तिहार"),
        arrayOf("2026-11-10", "2026-11-10", "Mha Puja", "म्ह पूजा"),
        arrayOf("2026-11-11", "2026-11-11", "Bhai Tika", "भाइटीका"),
        arrayOf("2026-12-24", "2026-12-24", "Yomari Punhi", "योमरी पुन्ही"),
        arrayOf("2026-12-25", "2026-12-25", "Christmas", "क्रिसमस"),
        arrayOf("2026-12-30", "2026-12-30", "Tamu Lhosar", "तमु ल्होसार"),
        arrayOf("2027-01-11", "2027-01-11", "Prithvi Jayanti", "पृथ्वी जयन्ती"),
        arrayOf("2027-01-15", "2027-01-15", "Maghe Sankranti", "माघे सङ्क्रान्ति"),
        arrayOf("2027-01-30", "2027-01-30", "Martyrs' Day", "शहीद दिवस"),
        arrayOf("2027-02-07", "2027-02-07", "Sonam Lhosar", "सोनाम ल्होसार"),
        arrayOf("2027-02-11", "2027-02-11", "Basanta Panchami", "बसन्त पञ्चमी"),
        arrayOf("2027-02-19", "2027-02-19", "Democracy Day", "प्रजातन्त्र दिवस"),
        arrayOf("2027-03-06", "2027-03-06", "Maha Shivaratri", "महाशिवरात्रि"),
        arrayOf("2027-03-08", "2027-03-08", "Women's Day", "महिला दिवस"),
        arrayOf("2027-03-09", "2027-03-09", "Gyalpo Lhosar", "ग्याल्पो ल्होसार"),
        arrayOf("2027-03-21", "2027-03-21", "Fagu Purnima (Holi, hills)", "फागु पूर्णिमा (होली, पहाड)"),
        arrayOf("2027-03-22", "2027-03-22", "Holi (Terai)", "होली (तराई)"),
        arrayOf("2027-04-06", "2027-04-06", "Ghode Jatra", "घोडेजात्रा"),
        arrayOf("2027-04-14", "2027-04-14", "Nepali New Year 2084", "नयाँ वर्ष २०८४"),
    )

    private val BS_MONTHS = arrayOf("बैशाख", "जेठ", "असार", "श्रावण", "भदौ", "असोज", "कात्तिक", "मंसिर", "पौष", "माघ", "फागुन", "चैत")

    private fun digits(n: Int): String = n.toString().map { if (it in '0'..'9') '\u0966' + (it - '0') else it }.joinToString("")

    /** Returns Triple(year, month0, day) in BS, or null when the date is outside the table. */
    fun toBs(date: LocalDate): Triple<Int, Int, Int>? {
        var off = ChronoUnit.DAYS.between(ANCHOR, date)
        var y = 2083
        var m = 0
        val lastYear = FIRST_YEAR + MONTH_DAYS.size - 1
        while (off < 0) {
            m--
            if (m < 0) { m = 11; y-- }
            if (y < FIRST_YEAR) return null
            off += MONTH_DAYS[y - FIRST_YEAR][m]
        }
        while (true) {
            if (y > lastYear) return null
            val l = MONTH_DAYS[y - FIRST_YEAR][m]
            if (off < l) break
            off -= l
            m++
            if (m > 11) { m = 0; y++ }
        }
        return Triple(y, m, off.toInt() + 1)
    }

    /** "कात्तिक १५, २०८३" or null when the date is not covered. */
    fun format(date: LocalDate): String? {
        val b = toBs(date) ?: return null
        return BS_MONTHS[b.second] + " " + digits(b.third) + ", " + digits(b.first)
    }

    /** Next festival starting today or later, e.g. "भाइटीका · ६ दिनमा", or null. */
    fun nextFestival(date: LocalDate): String? {
        val key = date.toString()
        val f = FEST.firstOrNull { it[0] >= key } ?: return null
        val days = ChronoUnit.DAYS.between(date, LocalDate.parse(f[0])).toInt()
        val whenText = when {
            days <= 0 -> "आज"
            days == 1 -> "भोलि"
            else -> digits(days) + " दिनमा"
        }
        return f[3] + " · " + whenText
    }
}
