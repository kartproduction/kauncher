package com.studio.launcher

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

// ---------------------------------------------------------------------------------------------
// Home screen widget: today's focus time and your streak. It reads the focus log on the phone.
// No internet, no permissions. Tapping it opens Kauncher.
// ---------------------------------------------------------------------------------------------

fun streakText(streak: Int): String =
    if (streak <= 0) "No streak yet" else "$streak day" + (if (streak == 1) "" else "s") + " in a row"

fun buildFocusViews(ctx: Context): RemoteViews {
    val (todayMin, streak) = focusStats(studioPrefs(ctx))
    val v = RemoteViews(ctx.packageName, R.layout.widget_focus)
    v.setTextViewText(R.id.w_today, fmtDur(todayMin))
    v.setTextViewText(R.id.w_streak, streakText(streak))
    val open = PendingIntent.getActivity(
        ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    v.setOnClickPendingIntent(R.id.w_root, open)
    return v
}

// Call after a focus session is saved (and whenever Kauncher is left), so the widget stays current.
fun refreshFocusWidgets(ctx: Context) {
    try {
        val mgr = AppWidgetManager.getInstance(ctx)
        val ids = mgr.getAppWidgetIds(ComponentName(ctx, FocusWidgetProvider::class.java))
        for (id in ids) mgr.updateAppWidget(id, buildFocusViews(ctx))
    } catch (e: Exception) { }
    applyStreakWallpaper(ctx)       // only does anything if "Streak on the lock screen" is on
}

class FocusWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) appWidgetManager.updateAppWidget(id, buildFocusViews(context))
    }
}
