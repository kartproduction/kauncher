package com.studio.launcher

import android.content.SharedPreferences
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

// ---------------------------------------------------------------------------------------------
// Intentions for the day: up to three things to make today, ticked off when done. They are kept
// per day on the phone, so the focus log and the weekly report can show them.
// ---------------------------------------------------------------------------------------------

class Intention(val text: String, val done: Boolean)

const val MAX_INTENTIONS = 3
private const val INT_KEY = "intentions"

private fun intentionObject(prefs: SharedPreferences): JSONObject =
    try { JSONObject(prefs.getString(INT_KEY, "{}") ?: "{}") } catch (e: Exception) { JSONObject() }

fun loadIntentions(prefs: SharedPreferences, day: LocalDate): List<Intention> = try {
    val a = intentionObject(prefs).optJSONArray(day.toString()) ?: JSONArray()
    List(a.length()) { val o = a.getJSONObject(it); Intention(o.optString("t", ""), o.optBoolean("d", false)) }
        .filter { it.text.isNotBlank() }.take(MAX_INTENTIONS)
} catch (e: Exception) { emptyList() }

fun saveIntentions(prefs: SharedPreferences, day: LocalDate, list: List<Intention>) {
    val o = intentionObject(prefs)
    val a = JSONArray()
    for (i in list.filter { it.text.isNotBlank() }.take(MAX_INTENTIONS))
        a.put(JSONObject().put("t", i.text.trim().take(60)).put("d", i.done))
    if (a.length() == 0) o.remove(day.toString()) else o.put(day.toString(), a)
    // keep the latest 90 days
    val keys = o.keys().asSequence().toList().sortedDescending()
    for (k in keys.drop(90)) o.remove(k)
    prefs.edit().putString(INT_KEY, o.toString()).apply()
}

fun intentionDays(prefs: SharedPreferences): List<LocalDate> =
    intentionObject(prefs).keys().asSequence().mapNotNull { try { LocalDate.parse(it) } catch (e: Exception) { null } }.toList()

// (done, total) over the seven days that start on `start`.
fun intentionsInWeek(prefs: SharedPreferences, start: LocalDate): Pair<Int, Int> {
    var done = 0; var total = 0
    for (i in 0 until 7) {
        val l = loadIntentions(prefs, start.plusDays(i.toLong()))
        total += l.size; done += l.count { it.done }
    }
    return done to total
}

fun intentionsLine(prefs: SharedPreferences): String {
    val l = loadIntentions(prefs, LocalDate.now())
    return when {
        l.isEmpty() -> "Today's intentions"
        l.all { it.done } -> "Intentions: all ${l.size} done ✓"
        else -> "Intentions: ${l.count { it.done }} of ${l.size} done"
    }
}

@Composable
fun IntentionsScreen(prefs: SharedPreferences, ink: Color, mute: Color, surface: Color, line: Color, accent: Color, onClose: () -> Unit) {
    val today = LocalDate.now()
    val items = remember {
        val saved = loadIntentions(prefs, today)
        mutableStateListOf<Intention>().apply { for (i in 0 until MAX_INTENTIONS) add(saved.getOrNull(i) ?: Intention("", false)) }
    }
    val focusManager = LocalFocusManager.current
    fun persist() = saveIntentions(prefs, today, items.toList())

    Box(
        Modifier.fillMaxSize().background(surface).pointerInput(Unit) { detectTapGestures { } }
            .padding(horizontal = 26.dp, vertical = 20.dp)
    ) {
        Column(Modifier.fillMaxSize()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Today", color = ink, fontSize = 30.sp, fontWeight = FontWeight.Light, modifier = Modifier.weight(1f))
                Text("Close", color = accent, fontSize = 16.sp, modifier = Modifier.clickable { persist(); onClose() }.padding(8.dp))
            }
            Text("Up to three things to make today. Tick them off as you go. They show in your focus log and your weekly report.", color = mute, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp, bottom = 18.dp))
            for (idx in 0 until MAX_INTENTIONS) {
                val cur = items[idx]
                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (cur.done) "✓" else "○", color = if (cur.done) accent else mute, fontSize = 24.sp,
                        modifier = Modifier.width(40.dp).clickable(enabled = cur.text.isNotBlank()) {
                            items[idx] = Intention(cur.text, !cur.done); persist()
                        }.padding(vertical = 4.dp)
                    )
                    BasicTextField(
                        value = cur.text,
                        onValueChange = { v -> items[idx] = Intention(v.take(60), if (v.isBlank()) false else cur.done); persist() },
                        singleLine = true,
                        textStyle = TextStyle(color = if (cur.done) mute else ink, fontSize = 20.sp),
                        cursorBrush = SolidColor(accent),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
                        modifier = Modifier.weight(1f),
                        decorationBox = { inner ->
                            Column {
                                Box(Modifier.padding(bottom = 8.dp)) {
                                    if (cur.text.isEmpty()) Text(if (idx == 0) "What will you make today?" else "Another one (optional)", color = mute.copy(alpha = .55f), fontSize = 20.sp)
                                    inner()
                                }
                                Box(Modifier.fillMaxWidth().height(1.5.dp).background(line))
                            }
                        }
                    )
                }
            }
        }
    }
}
