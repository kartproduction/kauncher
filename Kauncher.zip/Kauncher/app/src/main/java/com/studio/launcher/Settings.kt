package com.studio.launcher

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// The version of the installed app, read from the app itself, so it always matches the APK that was downloaded.
fun appVersion(ctx: Context): String = try {
    ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
} catch (e: Exception) { "" }

// Opens a page of the phone's own Settings app (falls back to the main Settings page).
fun openPhoneSettings(ctx: Context, action: String) {
    try {
        ctx.startActivity(Intent(action))
    } catch (e: Exception) {
        try { ctx.startActivity(Intent("android.settings.SETTINGS")) } catch (e2: Exception) { }
    }
}

private val PHONE_SETTINGS = listOf(
    "Wi-Fi" to "android.settings.WIFI_SETTINGS",
    "Bluetooth" to "android.settings.BLUETOOTH_SETTINGS",
    "Mobile network and airplane mode" to "android.settings.WIRELESS_SETTINGS",
    "Display" to "android.settings.DISPLAY_SETTINGS",
    "Sound" to "android.settings.SOUND_SETTINGS",
    "Notifications" to "android.settings.ALL_APPS_NOTIFICATION_SETTINGS",
    "Battery" to "android.settings.BATTERY_SAVER_SETTINGS",
    "Apps" to "android.settings.APPLICATION_SETTINGS",
    "Storage" to "android.settings.INTERNAL_STORAGE_SETTINGS",
    "Location" to "android.settings.LOCATION_SOURCE_SETTINGS",
    "Security" to "android.settings.SECURITY_SETTINGS",
    "Privacy" to "android.settings.PRIVACY_SETTINGS",
    "Accessibility" to "android.settings.ACCESSIBILITY_SETTINGS",
    "Date and time" to "android.settings.DATE_SETTINGS",
    "Language" to "android.settings.LOCALE_SETTINGS",
    "Default apps" to "android.settings.MANAGE_DEFAULT_APPS_SETTINGS",
    "Default home app" to "android.settings.HOME_SETTINGS",
    "All phone settings" to "android.settings.SETTINGS"
)

private fun <T> next(list: List<T>, cur: T): T = list[(list.indexOf(cur) + 1) % list.size]

@Composable
fun SettingsScreen(
    ctx: Context, ink: Color, mute: Color, surface: Color, line: Color, accent: Color,
    artMin: Int, lockMin: Int, autoStart: Boolean, pinLock: Boolean, themeMode: Int, h24: Boolean, kTop: Boolean, writeKotepad: Boolean, ownMedia: Boolean, focusSummary: String,
    onArtMin: (Int) -> Unit, onLockMin: (Int) -> Unit, onAutoStart: (Boolean) -> Unit,
    onPinLock: (Boolean) -> Unit, onTheme: (Int) -> Unit, onH24: (Boolean) -> Unit, onKTop: (Boolean) -> Unit, onWriteKotepad: (Boolean) -> Unit, onOwnMedia: (Boolean) -> Unit, onFocusLog: () -> Unit, onWeeklyReport: () -> Unit, onExtras: () -> Unit, showExtras: Boolean, onShowExtras: (Boolean) -> Unit, onWelcome: () -> Unit,
    onBackup: () -> Unit, onRestore: () -> Unit, themeId: Int = 0, onThemeId: (Int) -> Unit = {}, onClose: () -> Unit
) {
    @Composable
    fun Header(text: String) {
        Text(text.uppercase(), color = mute, fontSize = 12.sp, letterSpacing = 1.sp,
            modifier = Modifier.padding(top = 26.dp, bottom = 4.dp))
    }

    @Composable
    fun Item(title: String, value: String? = null, onClick: () -> Unit) {
        Row(
            Modifier.fillMaxWidth().clickable(role = Role.Button) { onClick() }.padding(vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(title, color = ink, fontSize = 17.sp, modifier = Modifier.weight(1f))
            if (value != null) Text(value, color = accent, fontSize = 15.sp)
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(line))
    }

    Box(
        Modifier.fillMaxSize().background(surface).pointerInput(Unit) { detectTapGestures { } }
            .padding(horizontal = 26.dp, vertical = 20.dp)
    ) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Kettings", color = ink, fontSize = 30.sp, fontWeight = FontWeight.Light, modifier = Modifier.weight(1f))
                Text(tr("Close"), color = accent, fontSize = 16.sp, modifier = Modifier.clickable { onClose() }.padding(8.dp))
            }

            Header(tr("Focus"))
            Item(tr("Creative focus length"), "$artMin min") { onArtMin(next(listOf(15, 30, 45, 60, 90), artMin)) }
            Item(tr("Locked focus length"), "$lockMin min") { onLockMin(next(listOf(30, 45, 60, 90, 120), lockMin)) }
            Item(tr("Start focus automatically"), if (autoStart) "On" else "Off") { onAutoStart(!autoStart) }
            Item(tr("Lock the screen during locked focus"), if (pinLock) "On" else "Off") { onPinLock(!pinLock) }
            Item(tr("Focus log"), focusSummary) { onFocusLog() }
            Item(tr("Calm tools: pause, app limits, focus sound, breaks, backup, quiet apps")) { onExtras() }
            Item(tr("Weekly report"), if (weeklyReportOn(ctx) && hasUsageAccess(ctx)) "On" else "Off") { onWeeklyReport() }

            Item(tr("Kord and Kamera open"), if (ownMedia) "Kauncher" else "Phone apps") { onOwnMedia(!ownMedia) }
            Item(tr("Krite and Ketch open"), if (writeKotepad) "Kotepad" else "Your notes app") { onWriteKotepad(!writeKotepad) }

            Header(tr("Look"))
            Item(tr("Theme"), listOf("Auto", "Light", "Dark")[themeMode]) { onTheme((themeMode + 1) % 3) }
            Item(tr("Color theme"), tr(themeName(themeId))) { onThemeId((themeId + 1) % THEME_NAMES.size) }
            Item(tr("Clock"), if (h24) "24-hour" else "12-hour") { onH24(!h24) }
            Item(tr("Kames and Kettings in All apps"), if (kTop) "On top" else "A to Z") { onKTop(!kTop) }

            Item(stringResource(R.string.set_extras), stringResource(if (showExtras) R.string.val_on else R.string.val_off)) { onShowExtras(!showExtras) }

            Header(tr("Your data"))
            Item(tr("Back up folders")) { onBackup() }
            Item(tr("Restore folders")) { onRestore() }

            Header(tr("Phone settings"))
            for ((title, action) in PHONE_SETTINGS) Item(title) { openPhoneSettings(ctx, action) }

            Header(stringResource(R.string.hdr_help))
            Item(stringResource(R.string.set_welcome)) { onWelcome() }
            Item(stringResource(R.string.set_updates)) { openUrl(ctx, SITE_URL) }
            Item(stringResource(R.string.set_feedback)) { sendFeedback(ctx) }
            Item(stringResource(R.string.set_privacy)) { openUrl(ctx, SITE_URL + "privacy.html") }

            Header(tr("About"))
            Text("Kauncher ${remember { appVersion(ctx) }}", color = ink, fontSize = 17.sp, modifier = Modifier.padding(top = 12.dp))
            Text(
                tr("© 2026 Kart Production. All rights reserved. Official download only: kartproduction.github.io/kauncher"),
                color = mute, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp, bottom = 40.dp)
            )
        }
    }
}

const val SITE_URL = "https://kartproduction.github.io/kauncher/"

// Put your own email here to get feedback by email. While it is empty, "Send feedback" opens the GitHub issues page instead.
private const val FEEDBACK_EMAIL = ""

fun openUrl(ctx: Context, url: String) {
    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))) } catch (e: Exception) { }
}

fun sendFeedback(ctx: Context) {
    if (FEEDBACK_EMAIL.isBlank()) { openUrl(ctx, "https://github.com/kartproduction/kauncher/issues"); return }
    val body = "\n\n---\nKauncher ${appVersion(ctx)}\nAndroid ${android.os.Build.VERSION.RELEASE}\n${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}\n"
    val i = Intent(Intent.ACTION_SENDTO, android.net.Uri.parse("mailto:")).apply {
        putExtra(Intent.EXTRA_EMAIL, arrayOf(FEEDBACK_EMAIL))
        putExtra(Intent.EXTRA_SUBJECT, "Kauncher feedback")
        putExtra(Intent.EXTRA_TEXT, body)
    }
    try { ctx.startActivity(i) } catch (e: Exception) { }
}
