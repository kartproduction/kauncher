package com.studio.launcher

import android.content.SharedPreferences
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalDateTime

// ---------------------------------------------------------------------------------------------
// Version 4.14: Pomodoro mode, sleep timer, open counter and the evening reflection.
// Everything is stored on the phone. No new permissions.
// ---------------------------------------------------------------------------------------------

fun pomodoroOn(prefs: SharedPreferences) = prefs.getBoolean("pomodoro", false)
fun sleepMinutes(prefs: SharedPreferences) = prefs.getInt("sleepMin", 30)

// ---- Open counter: how many times you opened an app from Kauncher today -------------------------

fun opensToday(prefs: SharedPreferences, pkg: String): Int {
    if (prefs.getString("opensDay", "") != LocalDate.now().toString()) return 0
    return prefs.getInt("opens_$pkg", 0)
}

fun bumpOpens(prefs: SharedPreferences, pkg: String) {
    val day = LocalDate.now().toString()
    val e = prefs.edit()
    if (prefs.getString("opensDay", "") != day) {
        for (k in prefs.all.keys) if (k.startsWith("opens_")) e.remove(k)
        e.putString("opensDay", day)
        e.putInt("opens_$pkg", 1)
    } else e.putInt("opens_$pkg", prefs.getInt("opens_$pkg", 0) + 1)
    e.apply()
}

// ---- Evening reflection --------------------------------------------------------------------------

fun reflectHour(prefs: SharedPreferences) = prefs.getInt("reflectHour", 0)   // 0 = off, otherwise 18..22

fun shouldAskReflection(prefs: SharedPreferences, now: LocalDateTime): Boolean {
    val h = reflectHour(prefs)
    return h > 0 && now.hour >= h && prefs.getString("reflectDone", "") != now.toLocalDate().toString()
}

fun skipReflection(prefs: SharedPreferences) {
    prefs.edit().putString("reflectDone", LocalDate.now().toString()).apply()
}

// Saves the line for the weekly report and as a note in Kotepad.
fun saveReflection(prefs: SharedPreferences, text: String) {
    val t = text.trim().take(300)
    skipReflection(prefs)
    if (t.isEmpty()) return
    val day = LocalDate.now().toString()
    try {
        val o = try { JSONObject(prefs.getString("reflections", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }
        o.put(day, t)
        // keep about a year
        val keys = o.keys().asSequence().toList().sorted()
        for (k in keys.dropLast(400)) o.remove(k)
        prefs.edit().putString("reflections", o.toString()).apply()
    } catch (e: Exception) { }
    val note = Note(System.currentTimeMillis().toString(36) + (0..999).random(), "Evening reflection · $day\n$t", System.currentTimeMillis(), "text")
    saveNotes(prefs, listOf(note) + loadNotes(prefs))
}

fun loadReflections(prefs: SharedPreferences): List<Pair<LocalDate, String>> = try {
    val o = JSONObject(prefs.getString("reflections", "{}") ?: "{}")
    o.keys().asSequence().mapNotNull { k -> try { LocalDate.parse(k) to o.getString(k) } catch (e: Exception) { null } }.sortedBy { it.first.toEpochDay() }.toList()
} catch (e: Exception) { emptyList() }

@Composable
fun ReflectionCard(ink: Color, mute: Color, surface: Color, line: Color, accent: Color, onSave: (String) -> Unit, onSkip: () -> Unit) {
    var text by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { try { focus.requestFocus() } catch (e: Exception) { } }
    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = .55f)).clickable { onSkip() },
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.padding(28.dp).clip(RoundedCornerShape(24.dp)).background(surface)
                .pointerInput(Unit) { detectTapGestures { } }.padding(24.dp)
        ) {
            Text(tr("Evening reflection"), color = mute, fontSize = 14.sp)
            Spacer(Modifier.height(6.dp))
            Text(tr("What did you make today?"), color = ink, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
            BasicTextField(
                value = text, onValueChange = { text = it.take(300) },
                textStyle = TextStyle(color = ink, fontSize = 18.sp), cursorBrush = SolidColor(accent),
                modifier = Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 6.dp).focusRequester(focus),
                decorationBox = { inner -> Box { if (text.isEmpty()) Text(tr("One line is enough"), color = mute, fontSize = 18.sp); inner() } }
            )
            Box(Modifier.fillMaxWidth().height(1.5.dp).background(line))
            Spacer(Modifier.height(14.dp))
            Text(tr("Save"), color = accent, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clickable { onSave(text) }.padding(vertical = 10.dp))
            Text(tr("Skip"), color = mute, fontSize = 17.sp, modifier = Modifier.clickable { onSkip() }.padding(vertical = 10.dp))
        }
    }
}
