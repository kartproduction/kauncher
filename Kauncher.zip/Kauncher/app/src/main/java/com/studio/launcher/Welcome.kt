package com.studio.launcher

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Shown once on a new install, and again from Kettings > Help > Welcome guide.
@Composable
fun WelcomeScreen(ink: Color, mute: Color, surface: Color, line: Color, accent: Color, onDone: () -> Unit) {
    val steps = listOf(R.string.welcome_1, R.string.welcome_2, R.string.welcome_3, R.string.welcome_4, R.string.welcome_5)
    Box(Modifier.fillMaxSize().background(surface).pointerInput(Unit) { detectTapGestures { } }.padding(horizontal = 28.dp, vertical = 24.dp)) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.Center) {
            Text(stringResource(R.string.welcome_title), color = ink, fontSize = 32.sp, fontWeight = FontWeight.Light)
            Text(stringResource(R.string.welcome_sub), color = mute, fontSize = 16.sp, modifier = Modifier.padding(top = 8.dp, bottom = 24.dp))
            steps.forEachIndexed { i, id ->
                Row(Modifier.padding(vertical = 8.dp)) {
                    Text("${i + 1}", color = accent, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.width(28.dp))
                    Text(stringResource(id), color = ink, fontSize = 17.sp, lineHeight = 24.sp)
                }
            }
            Spacer(Modifier.height(24.dp))
            Box(
                Modifier.align(Alignment.CenterHorizontally).clip(RoundedCornerShape(50)).background(ink)
                    .clickable(role = Role.Button) { onDone() }.padding(horizontal = 32.dp, vertical = 14.dp)
            ) { Text(stringResource(R.string.welcome_done), color = surface, fontSize = 18.sp) }
        }
    }
}
