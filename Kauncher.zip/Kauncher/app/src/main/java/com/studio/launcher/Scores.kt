package com.studio.launcher

import android.content.Context
import android.content.SharedPreferences

// Wins, losses and draws against the computer, per game ("ttt", "chess", "bagh", "ludo", "keshey").
fun scorePrefs(ctx: Context): SharedPreferences = ctx.getSharedPreferences("studio", Context.MODE_PRIVATE)

fun scoreOf(prefs: SharedPreferences, game: String): IntArray = try {
    val a = org.json.JSONObject(prefs.getString("kameScores", "{}") ?: "{}").optJSONArray(game)
    if (a == null) intArrayOf(0, 0, 0) else intArrayOf(a.getInt(0), a.getInt(1), a.getInt(2))
} catch (e: Exception) { intArrayOf(0, 0, 0) }

// outcome: 0 = you won, 1 = you lost, 2 = draw
fun addScore(prefs: SharedPreferences, game: String, outcome: Int) {
    try {
        val all = org.json.JSONObject(prefs.getString("kameScores", "{}") ?: "{}")
        val s = scoreOf(prefs, game)
        s[outcome]++
        all.put(game, org.json.JSONArray(listOf(s[0], s[1], s[2])))
        prefs.edit().putString("kameScores", all.toString()).apply()
    } catch (e: Exception) { }
}

fun scoreText(prefs: SharedPreferences, game: String): String {
    if (game == "chungi") { val b = prefs.getInt("chungiBest", 0); return if (b == 0) "" else "Best: $b kicks" }
    val s = scoreOf(prefs, game)
    return if (s.sum() == 0) "" else "Against the computer: won ${s[0]}, lost ${s[1]}, drew ${s[2]}"
}
