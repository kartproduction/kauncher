package com.studio.launcher

import android.content.SharedPreferences
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.DateTimeFormatter

// ---------------------------------------------------------------------------------------------
// Version 4.16: focus calendar, colour themes (with a fully monochrome one) and the edit lock.
// Everything is stored on the phone. No new permissions.
// ---------------------------------------------------------------------------------------------

// ---- Colour themes ------------------------------------------------------------------------------

class Palette(val bg: Color, val surface: Color, val ink: Color, val mute: Color, val line: Color, val accent: Color)

val THEME_NAMES = listOf("Kauncher", "Paper", "Forest", "Ocean", "Sunset", "Mono")

fun themeName(id: Int): String = THEME_NAMES[id.coerceIn(0, THEME_NAMES.size - 1)]

private fun pal(bg: Long, surface: Long, ink: Long, mute: Long, line: Long, accent: Long) =
    Palette(Color(bg), Color(surface), Color(ink), Color(mute), Color(line), Color(accent))

/** Colours for a theme, or null for the original Kauncher colours (id 0). */
fun themePalette(id: Int, dark: Boolean): Palette? = when (id) {
    1 -> if (dark) pal(0xFF1E1A15, 0xFF2A251E, 0xFFEFE8DA, 0xFFA39A88, 0xFF3B352B, 0xFFE08A5C)
         else pal(0xFFF4EFE6, 0xFFFBF8F1, 0xFF2B2620, 0xFF7A7164, 0xFFD8CFBF, 0xFFB5532B)
    2 -> if (dark) pal(0xFF11201A, 0xFF1A2D25, 0xFFE4F0E6, 0xFF8DA698, 0xFF2A4236, 0xFF6FCB93)
         else pal(0xFFE3EBE2, 0xFFF1F6F0, 0xFF1B2B20, 0xFF5F7266, 0xFFC3D2C4, 0xFF2F7D4F)
    3 -> if (dark) pal(0xFF0F1B2A, 0xFF172838, 0xFFE3EEF8, 0xFF8AA3BA, 0xFF263C52, 0xFF6DB6F2)
         else pal(0xFFE0EAF1, 0xFFF0F5F9, 0xFF14283A, 0xFF5C7287, 0xFFC0D0DD, 0xFF1F6FB5)
    4 -> if (dark) pal(0xFF25141C, 0xFF33202A, 0xFFF6E6E8, 0xFFB08E98, 0xFF4A3039, 0xFFFF7C9A)
         else pal(0xFFF3E4DE, 0xFFFAF0EB, 0xFF3A1F26, 0xFF85626B, 0xFFDDC4BF, 0xFFD1456B)
    5 -> if (dark) pal(0xFF0E0E0E, 0xFF1A1A1A, 0xFFEDEDED, 0xFF8C8C8C, 0xFF2E2E2E, 0xFFEDEDED)
         else pal(0xFFEDEDED, 0xFFF7F7F7, 0xFF111111, 0xFF6B6B6B, 0xFFCFCFCF, 0xFF111111)
    else -> null
}

// ---- Edit lock ----------------------------------------------------------------------------------
// Protects the focus settings (Calm tools, focus lengths, app pause and limit changes, Restore).
// A PIN, or a wait of 1, 5 or 15 minutes, opens them for 10 minutes. It cannot stop an uninstall.

fun editLockMode(p: SharedPreferences) = p.getInt("editMode", 0)               // 0 off, 1 PIN, 2 wait
fun editWaitMin(p: SharedPreferences) = p.getInt("editWait", 5)
fun editUnlocked(p: SharedPreferences) = editLockMode(p) == 0 || System.currentTimeMillis() < p.getLong("editUntil", 0L)
fun grantEdit(p: SharedPreferences) { p.edit().putLong("editUntil", System.currentTimeMillis() + 10 * 60_000L).apply() }
fun relockEdit(p: SharedPreferences) { p.edit().putLong("editUntil", 0L).apply() }

fun editLockLabel(p: SharedPreferences): String = when (editLockMode(p)) {
    1 -> "PIN"
    2 -> "Wait ${editWaitMin(p)} min"
    else -> "Off"
}

/** Off, Wait 1, Wait 5, Wait 15, PIN, then Off again. Returns true when the PIN screen must open to finish. */
fun cycleEditLock(p: SharedPreferences): Boolean {
    val waits = listOf(1, 5, 15)
    val cur = when (editLockMode(p)) { 0 -> 0; 1 -> 4; else -> 1 + waits.indexOf(editWaitMin(p)).coerceAtLeast(0) }
    val next = (cur + 1) % 5
    return when (next) {
        0 -> { p.edit().putInt("editMode", 0).apply(); false }
        4 -> true
        else -> { p.edit().putInt("editMode", 2).putInt("editWait", waits[next - 1]).apply(); false }
    }
}

private fun sha(s: String): String =
    java.security.MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

fun setEditPin(p: SharedPreferences, pin: String) {
    val salt = System.nanoTime().toString(36) + (0..99999).random()
    p.edit().putString("editSalt", salt).putString("editPinHash", sha(salt + pin)).putInt("editMode", 1).apply()
}

fun checkEditPin(p: SharedPreferences, pin: String): Boolean =
    pin.isNotEmpty() && sha((p.getString("editSalt", "") ?: "") + pin) == (p.getString("editPinHash", "") ?: "")

private fun mmss(sec: Long): String { val s = sec.coerceAtLeast(0L); return "%d:%02d".format(s / 60, s % 60) }

@Composable
fun EditLockGate(
    prefs: SharedPreferences, ink: Color, mute: Color, surface: Color, line: Color, accent: Color,
    onUnlocked: () -> Unit, onCancel: () -> Unit
) {
    val mode = remember { editLockMode(prefs) }
    var pin by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    var left by remember { mutableIntStateOf(editWaitMin(prefs) * 60) }
    var forgotAt by remember { mutableLongStateOf(prefs.getLong("editForgotAt", 0L)) }
    var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    fun done() { prefs.edit().putLong("editForgotAt", 0L).apply(); grantEdit(prefs); onUnlocked() }
    if (mode == 2) LaunchedEffect(Unit) { while (left > 0) { delay(1000); left-- } }
    LaunchedEffect(forgotAt) {
        while (forgotAt > 0L) {
            nowMs = System.currentTimeMillis()
            if (nowMs >= forgotAt) { done(); break }
            delay(1000)
        }
    }
    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = .55f)).clickable { onCancel() },
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.padding(28.dp).clip(RoundedCornerShape(24.dp)).background(surface)
                .pointerInput(Unit) { detectTapGestures { } }.padding(24.dp)
        ) {
            Text(tr("Settings are locked"), color = ink, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            if (mode == 1) {
                Text(tr("Enter your PIN to change focus settings."), color = mute, fontSize = 15.sp)
                BasicTextField(
                    value = pin, onValueChange = { pin = it.filter { c -> c.isDigit() }.take(8); wrong = false },
                    singleLine = true, visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    textStyle = TextStyle(color = ink, fontSize = 24.sp), cursorBrush = SolidColor(accent),
                    modifier = Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 6.dp)
                )
                Box(Modifier.fillMaxWidth().height(1.5.dp).background(line))
                if (wrong) Text(tr("That PIN is not right."), color = accent, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
                Text(tr("Unlock"), color = accent, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable { if (checkEditPin(prefs, pin)) done() else { wrong = true; pin = "" } }.padding(top = 14.dp, bottom = 10.dp))
                if (forgotAt > 0L) {
                    Text(tr("Unlocking in %s").replace("%s", mmss((forgotAt - nowMs) / 1000)), color = mute, fontSize = 14.sp, modifier = Modifier.padding(vertical = 6.dp))
                } else {
                    Text(tr("Forgot PIN? Wait 10 minutes"), color = mute, fontSize = 14.sp,
                        modifier = Modifier.clickable {
                            val t = System.currentTimeMillis() + 10 * 60_000L
                            prefs.edit().putLong("editForgotAt", t).apply(); nowMs = System.currentTimeMillis(); forgotAt = t
                        }.padding(vertical = 6.dp))
                }
            } else {
                Text(tr("Wait for the timer to finish, then unlock. It gives you a moment to think first."), color = mute, fontSize = 15.sp)
                Text(mmss(left.toLong()), color = ink, fontSize = 44.sp, fontWeight = FontWeight.Light, modifier = Modifier.padding(vertical = 12.dp))
                Text(tr("Unlock"), color = if (left > 0) mute else accent, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable(enabled = left <= 0) { done() }.padding(vertical = 10.dp))
            }
            Text(tr("Cancel"), color = mute, fontSize = 16.sp, modifier = Modifier.clickable { onCancel() }.padding(vertical = 10.dp))
        }
    }
}

@Composable
fun SetPinScreen(prefs: SharedPreferences, ink: Color, mute: Color, surface: Color, line: Color, accent: Color, onDone: () -> Unit) {
    var first by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    Box(Modifier.fillMaxSize().background(surface).pointerInput(Unit) { detectTapGestures { } }.padding(horizontal = 26.dp, vertical = 20.dp)) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(tr("Set a PIN"), color = ink, fontSize = 30.sp, fontWeight = FontWeight.Light, modifier = Modifier.weight(1f))
                Text(tr("Back"), color = accent, fontSize = 16.sp, modifier = Modifier.clickable { onDone() }.padding(8.dp))
            }
            Text(if (first.isEmpty()) tr("Choose a PIN with 4 to 8 digits.") else tr("Type it again to confirm."), color = mute, fontSize = 15.sp, modifier = Modifier.padding(top = 10.dp))
            BasicTextField(
                value = pin, onValueChange = { pin = it.filter { c -> c.isDigit() }.take(8); msg = "" },
                singleLine = true, visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                textStyle = TextStyle(color = ink, fontSize = 26.sp), cursorBrush = SolidColor(accent),
                modifier = Modifier.fillMaxWidth().padding(top = 20.dp, bottom = 8.dp)
            )
            Box(Modifier.fillMaxWidth().height(1.5.dp).background(line))
            if (msg.isNotEmpty()) Text(msg, color = accent, fontSize = 14.sp, modifier = Modifier.padding(top = 10.dp))
            Text(if (first.isEmpty()) tr("Next") else tr("Save PIN"), color = accent, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clickable {
                    if (first.isEmpty()) {
                        if (pin.length >= 4) { first = pin; pin = ""; msg = "" } else msg = tr("Use at least 4 digits.")
                    } else if (pin == first) {
                        setEditPin(prefs, pin); onDone()
                    } else {
                        msg = tr("The two PINs do not match."); first = ""; pin = ""
                    }
                }.padding(top = 16.dp, bottom = 8.dp))
            Text(tr("If you forget the PIN, you can wait 10 minutes to unlock."), color = mute, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
        }
    }
}

// ---- Focus calendar -----------------------------------------------------------------------------

@Composable
fun FocusCalendarScreen(prefs: SharedPreferences, ink: Color, mute: Color, surface: Color, line: Color, accent: Color, onClose: () -> Unit) {
    val zone = remember { ZoneId.systemDefault() }
    val byDay = remember { loadFocusLog(prefs).groupBy { Instant.ofEpochMilli(it.t).atZone(zone).toLocalDate() } }
    val today = remember { LocalDate.now() }
    var month by remember { mutableStateOf(YearMonth.from(today)) }
    var sel by remember { mutableStateOf<LocalDate?>(today) }

    val len = month.lengthOfMonth()
    val monthMin = (1..len).sumOf { d -> byDay[month.atDay(d)]?.sumOf { it.min } ?: 0 }
    val monthActive = (1..len).count { d -> byDay.containsKey(month.atDay(d)) }
    val offset = month.atDay(1).dayOfWeek.value % 7            // Sunday = 0
    val rows = (offset + len + 6) / 7
    val title = month.month.getDisplayName(java.time.format.TextStyle.FULL, java.util.Locale.getDefault()) + " " + month.year
    val canNext = month.isBefore(YearMonth.from(today))
    val alphas = listOf(0f, .22f, .42f, .65f, .9f)
    fun level(m: Int) = when { m <= 0 -> 0; m < 30 -> 1; m < 60 -> 2; m < 120 -> 3; else -> 4 }

    Box(Modifier.fillMaxSize().background(surface).pointerInput(Unit) { detectTapGestures { } }.padding(horizontal = 24.dp, vertical = 20.dp)) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(tr("Focus calendar"), color = ink, fontSize = 30.sp, fontWeight = FontWeight.Light, modifier = Modifier.weight(1f))
                Text(tr("Close"), color = accent, fontSize = 16.sp, modifier = Modifier.clickable { onClose() }.padding(8.dp))
            }
            Row(Modifier.fillMaxWidth().padding(top = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("‹", color = accent, fontSize = 28.sp, modifier = Modifier.clickable { month = month.minusMonths(1); sel = null }.padding(horizontal = 14.dp, vertical = 2.dp))
                Text(title, color = ink, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                Text("›", color = if (canNext) accent else Color.Transparent, fontSize = 28.sp,
                    modifier = Modifier.clickable(enabled = canNext) { month = month.plusMonths(1); sel = null }.padding(horizontal = 14.dp, vertical = 2.dp))
            }
            Text(fmtDur(monthMin) + "  ·  " + tr("Days with focus: %d").replace("%d", monthActive.toString()), color = mute, fontSize = 14.sp,
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 12.dp), textAlign = TextAlign.Center)
            Row(Modifier.fillMaxWidth()) {
                for (w in listOf("S", "M", "T", "W", "T", "F", "S"))
                    Text(w, color = mute, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
            }
            for (r in 0 until rows) {
                Row(Modifier.fillMaxWidth()) {
                    for (c in 0..6) {
                        val dayNum = r * 7 + c - offset + 1
                        if (dayNum in 1..len) {
                            val d = month.atDay(dayNum)
                            val m = byDay[d]?.sumOf { it.min } ?: 0
                            val lv = level(m)
                            val shape = RoundedCornerShape(10.dp)
                            Box(
                                Modifier.weight(1f).aspectRatio(1f).padding(3.dp).clip(shape)
                                    .background(if (lv > 0) accent.copy(alpha = alphas[lv]) else line.copy(alpha = .35f))
                                    .then(if (d == sel) Modifier.border(2.dp, ink, shape) else Modifier)
                                    .clickable { sel = d },
                                contentAlignment = Alignment.Center
                            ) { Text(dayNum.toString(), color = if (lv >= 3) surface else ink, fontSize = 14.sp) }
                        } else Box(Modifier.weight(1f).aspectRatio(1f))
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                Text(tr("Less"), color = mute, fontSize = 12.sp)
                for (lv in 0..4) Box(Modifier.padding(horizontal = 3.dp).size(14.dp).clip(RoundedCornerShape(4.dp))
                    .background(if (lv > 0) accent.copy(alpha = alphas[lv]) else line.copy(alpha = .35f)))
                Text(tr("More"), color = mute, fontSize = 12.sp)
            }
            val s = sel
            if (s != null) {
                val list = (byDay[s] ?: emptyList()).sortedBy { it.t }
                Box(Modifier.fillMaxWidth().padding(top = 18.dp).height(1.5.dp).background(line))
                Text(s.format(DateTimeFormatter.ofPattern("EEEE, MMMM d")), color = ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 14.dp))
                NepaliDate.format(s)?.let { Text(it, color = mute, fontSize = 14.sp, modifier = Modifier.padding(top = 2.dp)) }
                if (list.isEmpty()) Text(tr("No focus sessions this day."), color = mute, fontSize = 15.sp, modifier = Modifier.padding(top = 10.dp))
                else {
                    Text(fmtDur(list.sumOf { it.min }), color = accent, fontSize = 15.sp, modifier = Modifier.padding(top = 4.dp, bottom = 6.dp))
                    for (e in list) {
                        val at = Instant.ofEpochMilli(e.t).atZone(zone).toLocalTime().format(DateTimeFormatter.ofPattern("h:mm a"))
                        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                            Column(Modifier.weight(1f)) {
                                Text(if (e.what.isBlank()) tr("Focus") else e.what, color = ink, fontSize = 16.sp)
                                Text(at + (if (!e.done) "  ·  " + tr("stopped early") else ""), color = mute, fontSize = 12.sp)
                            }
                            Text(fmtDur(e.min), color = mute, fontSize = 14.sp)
                        }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
