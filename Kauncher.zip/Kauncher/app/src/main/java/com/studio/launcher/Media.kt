package com.studio.launcher

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Date

// Kauncher's own camera and voice recorder. Photos and recordings are stored inside the app.
private fun mediaDir(ctx: Context, sub: String): File = File(ctx.filesDir, sub).apply { mkdirs() }

private fun listMedia(dir: File): List<File> =
    (dir.listFiles() ?: emptyArray()).filter { it.isFile && it.length() > 0 }.sortedByDescending { it.lastModified() }

private fun hasPermission(ctx: Context, p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

private fun loadBitmap(path: String, target: Int): ImageBitmap? = try {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, bounds)
    var s = 1
    while (bounds.outWidth / (s * 2) >= target && bounds.outHeight / (s * 2) >= target) s *= 2
    val bmp = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s })
    if (bmp == null) null else {
        val rot = when (ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        val out = if (rot != 0f) Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rot) }, true) else bmp
        out.asImageBitmap()
    }
} catch (e: Exception) { null }

// Copies a photo or recording to the phone's normal gallery or music folder.
private fun exportFile(ctx: Context, f: File, image: Boolean): Boolean = try {
    val values = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, f.name)
        put(MediaStore.MediaColumns.MIME_TYPE, if (image) "image/jpeg" else "audio/mp4")
        if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, if (image) "Pictures/Kauncher" else "Music/Kauncher")
    }
    val uri = ctx.contentResolver.insert(
        if (image) MediaStore.Images.Media.EXTERNAL_CONTENT_URI else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values
    )
    if (uri == null) false else {
        ctx.contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }
        true
    }
} catch (e: Exception) { false }

private fun openAppSettings(ctx: Context) {
    try {
        ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))
    } catch (e: Exception) { }
}

@Composable
private fun TextButton(label: String, color: Color, onClick: () -> Unit) {
    Text(label, color = color, fontSize = 16.sp, modifier = Modifier.clickable { onClick() }.padding(vertical = 8.dp, horizontal = 4.dp))
}

// ================= Capture (camera) =================
@Composable
fun CaptureScreen(ctx: Context, ink: Color, mute: Color, surface: Color, line: Color, accent: Color, onClose: () -> Unit) {
    val dir = remember { mediaDir(ctx, "photos") }
    var photos by remember { mutableStateOf(listMedia(dir)) }
    var granted by remember { mutableStateOf(hasPermission(ctx, Manifest.permission.CAMERA)) }
    var gallery by remember { mutableStateOf(false) }
    var viewing by remember { mutableStateOf<File?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    var lens by remember { mutableIntStateOf(CameraSelector.LENS_FACING_BACK) }
    val owner = remember { findActivity(ctx) as? ComponentActivity }

    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) { if (!granted) ask.launch(Manifest.permission.CAMERA) }

    val previewView = remember { PreviewView(ctx).apply { implementationMode = PreviewView.ImplementationMode.COMPATIBLE } }
    val imageCapture = remember { ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build() }

    DisposableEffect(granted, lens, gallery) {
        val future = ProcessCameraProvider.getInstance(ctx)
        if (granted && !gallery && owner != null) {
            future.addListener({
                try {
                    val provider = future.get()
                    val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                    provider.unbindAll()
                    provider.bindToLifecycle(owner, CameraSelector.Builder().requireLensFacing(lens).build(), preview, imageCapture)
                } catch (e: Exception) { }
            }, ContextCompat.getMainExecutor(ctx))
        }
        onDispose { try { if (future.isDone) future.get().unbindAll() } catch (e: Exception) { } }
    }

    fun shoot() {
        try { previewView.display?.let { imageCapture.targetRotation = it.rotation } } catch (e: Exception) { }
        val file = File(dir, "IMG_${System.currentTimeMillis()}.jpg")
        imageCapture.takePicture(
            ImageCapture.OutputFileOptions.Builder(file).build(), ContextCompat.getMainExecutor(ctx),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) { photos = listMedia(dir) }
                override fun onError(e: ImageCaptureException) {
                    Toast.makeText(ctx, "Could not take the photo", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    BackHandler(viewing != null) { viewing = null; confirmDelete = false }
    BackHandler(gallery && viewing == null) { gallery = false }

    Box(
        Modifier.fillMaxSize().background(surface).pointerInput(Unit) { detectTapGestures { } }
            .padding(horizontal = 20.dp, vertical = 20.dp)
    ) {
        Column(Modifier.fillMaxSize()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Kapture", color = ink, fontSize = 30.sp, fontWeight = FontWeight.Light, modifier = Modifier.weight(1f))
                TextButton("Close", accent) { onClose() }
            }
            Spacer(Modifier.height(10.dp))
            if (!gallery) {
                if (!granted) {
                    Text("Kauncher needs permission to use the camera.", color = ink, fontSize = 16.sp)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        TextButton("Allow", accent) { ask.launch(Manifest.permission.CAMERA) }
                        TextButton("Open settings", accent) { openAppSettings(ctx) }
                    }
                    Spacer(Modifier.weight(1f))
                } else {
                    Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color.Black)) {
                        AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
                    }
                    Spacer(Modifier.height(16.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.weight(1f)) { TextButton("Gallery (${photos.size})", accent) { gallery = true } }
                        Box(
                            Modifier.size(74.dp).clip(CircleShape).border(4.dp, ink, CircleShape).padding(7.dp)
                                .clip(CircleShape).background(ink).clickable { shoot() }
                        )
                        Box(Modifier.weight(1f), contentAlignment = Alignment.CenterEnd) {
                            TextButton("Flip", accent) {
                                lens = if (lens == CameraSelector.LENS_FACING_BACK) CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
                            }
                        }
                    }
                }
            } else {
                TextButton("← Camera", accent) { gallery = false }
                if (photos.isEmpty()) Text("No photos yet.", color = mute, fontSize = 15.sp, modifier = Modifier.padding(top = 20.dp))
                LazyVerticalGrid(GridCells.Fixed(3), Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(photos, key = { it.path }) { f ->
                        val thumb by produceState<ImageBitmap?>(null, f.path) { value = withContext(Dispatchers.IO) { loadBitmap(f.path, 300) } }
                        Box(Modifier.aspectRatio(1f).clip(RoundedCornerShape(10.dp)).background(line).clickable { viewing = f }) {
                            thumb?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                        }
                    }
                }
            }
        }

        val open = viewing
        if (open != null) {
            Column(Modifier.fillMaxSize().background(surface)) {
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton("← Back", accent) { viewing = null; confirmDelete = false }
                    Spacer(Modifier.weight(1f))
                    TextButton("Save to gallery", accent) {
                        val ok = exportFile(ctx, open, true)
                        Toast.makeText(ctx, if (ok) "Saved to Pictures/Kauncher" else "Could not save", Toast.LENGTH_SHORT).show()
                    }
                    TextButton(if (confirmDelete) "Tap again" else "Delete", accent) {
                        if (!confirmDelete) confirmDelete = true
                        else { open.delete(); photos = listMedia(dir); viewing = null; confirmDelete = false }
                    }
                }
                val big by produceState<ImageBitmap?>(null, open.path) { value = withContext(Dispatchers.IO) { loadBitmap(open.path, 1600) } }
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    big?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit) }
                }
            }
        }
    }
}

// ================= Record (voice recorder) =================
@Composable
fun RecordScreen(ctx: Context, ink: Color, mute: Color, surface: Color, line: Color, accent: Color, onClose: () -> Unit) {
    val dir = remember { mediaDir(ctx, "recordings") }
    var clips by remember { mutableStateOf(listMedia(dir)) }
    var granted by remember { mutableStateOf(hasPermission(ctx, Manifest.permission.RECORD_AUDIO)) }
    var recording by remember { mutableStateOf(false) }
    var elapsed by remember { mutableIntStateOf(0) }
    var playing by remember { mutableStateOf<String?>(null) }
    var confirmId by remember { mutableStateOf<String?>(null) }
    val recorder = remember { arrayOfNulls<MediaRecorder>(1) }
    val current = remember { arrayOfNulls<File>(1) }
    val player = remember { arrayOfNulls<MediaPlayer>(1) }

    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) { if (!granted) ask.launch(Manifest.permission.RECORD_AUDIO) }

    fun stopPlayback() {
        try { player[0]?.release() } catch (e: Exception) { }
        player[0] = null; playing = null
    }

    fun stopRecording() {
        val r = recorder[0] ?: return
        recorder[0] = null
        try { r.stop() } catch (e: RuntimeException) { current[0]?.delete() }   // too short to keep
        try { r.release() } catch (e: Exception) { }
        recording = false
        clips = listMedia(dir)
    }

    fun startRecording() {
        stopPlayback()
        val file = File(dir, "Recording-${java.text.SimpleDateFormat("yyyyMMdd-HHmmss", java.util.Locale.US).format(Date())}.m4a")
        try {
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else @Suppress("DEPRECATION") MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(128000)
            r.setAudioSamplingRate(44100)
            r.setOutputFile(file.absolutePath)
            r.prepare(); r.start()
            recorder[0] = r; current[0] = file; recording = true
        } catch (e: Exception) {
            Toast.makeText(ctx, "Could not start recording", Toast.LENGTH_SHORT).show()
        }
    }

    fun toggle(f: File) {
        if (playing == f.path) { stopPlayback(); return }
        stopPlayback()
        try {
            val p = MediaPlayer()
            p.setDataSource(f.path); p.prepare(); p.start()
            p.setOnCompletionListener { stopPlayback() }
            player[0] = p; playing = f.path
        } catch (e: Exception) {
            Toast.makeText(ctx, "Could not play this recording", Toast.LENGTH_SHORT).show()
        }
    }

    LaunchedEffect(recording) {
        val start = SystemClock.elapsedRealtime()
        while (recording) { elapsed = ((SystemClock.elapsedRealtime() - start) / 1000).toInt(); delay(250) }
        elapsed = 0
    }

    // Leaving the screen (Back, Home, Close) stops and keeps whatever is being recorded.
    DisposableEffect(Unit) { onDispose { stopRecording(); stopPlayback() } }

    Box(
        Modifier.fillMaxSize().background(surface).pointerInput(Unit) { detectTapGestures { } }
            .padding(horizontal = 22.dp, vertical = 20.dp)
    ) {
        Column(Modifier.fillMaxSize()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Kord", color = ink, fontSize = 30.sp, fontWeight = FontWeight.Light, modifier = Modifier.weight(1f))
                TextButton("Close", accent) { onClose() }
            }
            Spacer(Modifier.height(18.dp))
            if (!granted) {
                Text("Kauncher needs permission to use the microphone.", color = ink, fontSize = 16.sp)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    TextButton("Allow", accent) { ask.launch(Manifest.permission.RECORD_AUDIO) }
                    TextButton("Open settings", accent) { openAppSettings(ctx) }
                }
            } else {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        "%d:%02d".format(elapsed / 60, elapsed % 60),
                        color = if (recording) accent else mute, fontSize = 44.sp, fontWeight = FontWeight.Light
                    )
                    Spacer(Modifier.height(12.dp))
                    Box(
                        Modifier.size(84.dp).clip(CircleShape).border(4.dp, ink, CircleShape).padding(9.dp)
                            .clip(if (recording) RoundedCornerShape(10.dp) else CircleShape)
                            .background(if (recording) Color(0xFFD64545) else ink)
                            .clickable { if (recording) stopRecording() else startRecording() }
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(if (recording) "Tap to stop and save" else "Tap to record", color = mute, fontSize = 14.sp)
                }
            }
            Spacer(Modifier.height(18.dp))
            Box(Modifier.fillMaxWidth().height(1.5.dp).background(line))
            if (clips.isEmpty()) Text("No recordings yet.", color = mute, fontSize = 15.sp, modifier = Modifier.padding(top = 20.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(clips, key = { it.path }) { f ->
                    val seconds = remember(f.path) {
                        try {
                            val m = MediaMetadataRetriever()
                            m.setDataSource(f.path)
                            val ms = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                            m.release(); (ms / 1000).toInt()
                        } catch (e: Exception) { 0 }
                    }
                    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(f.lastModified())),
                                color = ink, fontSize = 16.sp
                            )
                            Text("%d:%02d".format(seconds / 60, seconds % 60), color = mute, fontSize = 13.sp)
                        }
                        TextButton(if (playing == f.path) "Stop" else "Play", accent) { toggle(f) }
                        TextButton("Save", accent) {
                            val ok = exportFile(ctx, f, false)
                            Toast.makeText(ctx, if (ok) "Saved to Music/Kauncher" else "Could not save", Toast.LENGTH_SHORT).show()
                        }
                        TextButton(if (confirmId == f.path) "Tap again" else "Delete", accent) {
                            if (confirmId != f.path) confirmId = f.path
                            else { if (playing == f.path) stopPlayback(); f.delete(); clips = listMedia(dir); confirmId = null }
                        }
                    }
                    Box(Modifier.fillMaxWidth().height(1.dp).background(line))
                }
            }
        }
    }
}
