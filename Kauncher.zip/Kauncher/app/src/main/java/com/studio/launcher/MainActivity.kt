package com.studio.launcher

import android.content.Context
import android.app.WallpaperManager
import android.content.Intent
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import android.content.SharedPreferences
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import android.widget.Toast
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import java.io.File
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { Launcher(this) }
    }
}

data class AppItem(val label: String, val pkg: String)

fun loadApps(ctx: Context): List<AppItem> {
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val pm = ctx.packageManager
    return pm.queryIntentActivities(i, 0)
        .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
        .filter { it.pkg != ctx.packageName }
        .sortedBy { it.label.lowercase() }
}

fun findActivity(ctx: Context): android.app.Activity? {
    var c: Context? = ctx
    while (c is android.content.ContextWrapper) {
        if (c is android.app.Activity) return c
        c = c.baseContext
    }
    return null
}

fun openApp(ctx: Context, pkg: String): Boolean {
    val intent = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
    ctx.startActivity(intent)
    return true
}

// Background colour choices: colour to dark-theme flag.
val swatches = listOf(
    Color(0xFF16122A) to true, Color(0xFF000000) to true, Color(0xFF1F3A2E) to true,
    Color(0xFFF4EFE6) to false, Color(0xFFDDE7F0) to false
)

fun bgFile(ctx: Context) = File(ctx.filesDir, "bg.jpg")

fun loadBg(ctx: Context): ImageBitmap? =
    bgFile(ctx).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path)?.asImageBitmap() }

fun saveBg(ctx: Context, uri: Uri): Boolean {
    return try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 2000 || bounds.outHeight / sample > 2000) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: return false
        val rot = ctx.contentResolver.openInputStream(uri)?.use {
            androidx.exifinterface.media.ExifInterface(it).rotationDegrees
        } ?: 0
        if (rot != 0) {
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rot.toFloat()) }, true)
        }
        bgFile(ctx).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        true
    } catch (e: Exception) {
        false
    }
}

fun loadFolders(prefs: SharedPreferences): Map<String, List<String>> {
    val out = LinkedHashMap<String, List<String>>()
    try {
        val o = org.json.JSONObject(prefs.getString("folders", "{}") ?: "{}")
        for (k in o.keys()) {
            val a = o.getJSONArray(k)
            out[k] = List(a.length()) { a.getString(it) }
        }
    } catch (e: Exception) { }
    return out
}

fun saveFoldersPrefs(prefs: SharedPreferences, m: Map<String, List<String>>) {
    val o = org.json.JSONObject()
    for ((k, v) in m) o.put(k, org.json.JSONArray(v))
    prefs.edit().putString("folders", o.toString()).apply()
}

val glyphs = listOf("●", "▲", "■", "★", "♥", "Hidden")

fun loadIcons(prefs: SharedPreferences): Map<String, String> {
    val out = LinkedHashMap<String, String>()
    try {
        val o = org.json.JSONObject(prefs.getString("folderIcons", "{}") ?: "{}")
        for (k in o.keys()) out[k] = o.getString(k)
    } catch (e: Exception) { }
    return out
}

fun saveIcons(prefs: SharedPreferences, m: Map<String, String>) {
    val o = org.json.JSONObject()
    for ((k, v) in m) o.put(k, v)
    prefs.edit().putString("folderIcons", o.toString()).apply()
}

val artWords = listOf(
    "art", "draw", "paint", "sketch", "illustrat", "design", "poem", "poetry", "song", "lyric", "music",
    "compos", "melod", "guitar", "piano", "sing", "writ", "story", "stories", "novel", "book", "script",
    "film", "video", "photo", "edit", "animat", "craft", "sculpt", "potter", "danc", "logo", "poster",
    "cover", "podcast", "record", "beat", "cartoon", "comic", "calligraph", "knit", "sew", "carv",
    "color", "colour", "canvas", "mural", "fashion"
)

// True when the text mentions something creative or art related.
fun looksArtistic(text: String): Boolean {
    val words = text.lowercase().split(Regex("[^a-z]+")).filter { it.isNotEmpty() }
    return words.any { w -> artWords.any { w.startsWith(it) } }
}

// Searches YouTube (app if installed, otherwise the browser).
fun searchYouTube(ctx: Context, q: String) {
    val t = q.trim()
    if (t.isEmpty()) return
    try {
        ctx.startActivity(Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra("query", t))
    } catch (e: Exception) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(t))))
        } catch (e2: Exception) { }
    }
}

// Opens the phone's default notes app (Android 14+), or a known notes app as a fallback.
fun openNotes(ctx: Context): Boolean {
    try {
        ctx.startActivity(Intent("android.intent.action.CREATE_NOTE"))
        return true
    } catch (e: Exception) { }
    val known = listOf(
        "com.samsung.android.app.notes", "com.google.android.keep", "com.miui.notes",
        "com.oneplus.note", "com.coloros.note", "com.microsoft.office.onenote"
    )
    for (p in known) if (openApp(ctx, p)) return true
    return false
}

@Composable
fun Launcher(ctx: Context) {
    val sysDark = isSystemInDarkTheme()
    val prefs = remember { ctx.getSharedPreferences("studio", Context.MODE_PRIVATE) }
    var photo by remember { mutableStateOf<ImageBitmap?>(loadBg(ctx)) }
    var swatch by remember { mutableIntStateOf(prefs.getInt("swatch", -1)) }
    var menu by remember { mutableStateOf(false) }
    var folders by remember { mutableStateOf(loadFolders(prefs)) }
    var openFolder by remember { mutableStateOf<String?>(null) }
    var pickFor by remember { mutableStateOf<String?>(null) }
    var naming by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    val focusManager = LocalFocusManager.current
    var icons by remember { mutableStateOf(loadIcons(prefs)) }
    fun setIcon(name: String, g: String) { icons = icons + (name to g); saveIcons(prefs, icons) }
    fun saveFolders(m: Map<String, List<String>>) { folders = m; saveFoldersPrefs(prefs, m) }
    fun addToFolder(f: String, pkg: String) {
        val l = folders[f] ?: return
        if (pkg !in l) saveFolders(folders + (f to (l + pkg)))
    }
    val dark = when {
        photo != null -> true
        swatch >= 0 -> swatches[swatch].second
        else -> sysDark
    }
    val bg = if (photo == null && swatch >= 0) swatches[swatch].first
        else if (dark) Color(0xFF16122A) else Color(0xFFE4E0EE)
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null && saveBg(ctx, uri)) {
            photo = loadBg(ctx); swatch = -1; prefs.edit().putInt("swatch", -1).apply()
        }
    }
    fun pickSwatch(i: Int) {
        swatch = i; photo = null; bgFile(ctx).delete(); prefs.edit().putInt("swatch", i).apply(); menu = false
    }
    val surface = if (dark) Color(0xFF221C3D) else Color(0xFFF3F1F8)
    val ink = if (dark) Color(0xFFEDEAF8) else Color(0xFF201A33)
    val mute = if (dark) Color(0xFF9189B0) else Color(0xFF6B6483)
    val line = if (dark) Color(0xFF342D55) else Color(0xFFC9C3DB)
    val accent = if (dark) Color(0xFF9C8CFF) else Color(0xFF4A35FF)

    var focus by remember { mutableStateOf(prefs.getString("focus", "") ?: "") }
    // The session survives the activity being recreated: its end time is stored.
    val savedEnd = remember { prefs.getLong("endAt", 0L) }
    val resumed = remember { savedEnd > System.currentTimeMillis() }
    var endAt by remember { mutableStateOf(savedEnd) }
    var left by remember { mutableIntStateOf(if (resumed) ((savedEnd - System.currentTimeMillis()) / 1000).toInt() + 1 else 1500) }
    var running by remember { mutableStateOf(resumed) }
    var drawer by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    val apps = remember { loadApps(ctx) }
    var creating by remember {
        mutableStateOf(
            if (prefs.getString("creatingDay", "") == LocalDate.now().toString()) prefs.getString("creating", "") ?: "" else ""
        )
    }
    var locked by remember { mutableStateOf(resumed && prefs.getBoolean("sessLocked", false)) }
    var lastAuto by remember { mutableStateOf<String?>(creating) }
    fun startFocusFor(text: String) {
        val art = looksArtistic(text)
        left = if (art) 1800 else 3600
        locked = !art
        lastAuto = text
        endAt = System.currentTimeMillis() + left * 1000L
        prefs.edit().putLong("endAt", endAt).putBoolean("sessLocked", locked).apply()
        running = true
    }
    fun clearSession() { prefs.edit().putLong("endAt", 0L).putBoolean("sessLocked", false).apply() }
    fun onFocusTap() {
        if (running) {
            if (locked) Toast.makeText(ctx, "Locked until the hour ends", Toast.LENGTH_SHORT).show()
            else { running = false; lastAuto = creating; clearSession() }
        } else startFocusFor(creating)
    }
    // Starts by itself only after you type what you are creating (never on an empty field or on open).
    LaunchedEffect(creating, running) {
        if (running || creating.isBlank() || lastAuto == creating) return@LaunchedEffect
        delay(if (looksArtistic(creating)) 3_000L else 6_000L)
        startFocusFor(creating)
    }

    // While a locked (1 hour) session runs, pin the screen: Recents (|||) and Home stop working.
    LaunchedEffect(running, locked) {
        val act = findActivity(ctx) ?: return@LaunchedEffect
        try {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
            val pinned = am.lockTaskModeState != android.app.ActivityManager.LOCK_TASK_MODE_NONE
            if (running && locked) { if (!pinned) act.startLockTask() }
            else if (pinned) act.stopLockTask()
        } catch (e: Exception) { }
    }

    DisposableEffect(running, locked) {
        val act = findActivity(ctx) as? ComponentActivity
        val obs = androidx.lifecycle.LifecycleEventObserver { _, ev ->
            if (ev == androidx.lifecycle.Lifecycle.Event.ON_RESUME && running && locked) {
                try {
                    val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
                    if (am.lockTaskModeState == android.app.ActivityManager.LOCK_TASK_MODE_NONE) act?.startLockTask()
                } catch (e: Exception) { }
            }
        }
        act?.lifecycle?.addObserver(obs)
        onDispose { act?.lifecycle?.removeObserver(obs) }
    }

    LaunchedEffect(Unit) { while (true) { now = LocalDateTime.now(); delay(15_000) } }
    LaunchedEffect(running) {
        if (running) {
            while (true) {
                left = maxOf(0, ((endAt - System.currentTimeMillis() + 999) / 1000).toInt())
                if (left <= 0) break
                delay(500)
            }
            running = false; locked = false; clearSession()
        }
    }
    BackHandler(openFolder != null) { openFolder = null }
    BackHandler(naming) { naming = false }
    BackHandler(drawer) { drawer = false; query = ""; pickFor = null }
    BackHandler(menu) { menu = false }
    // Back does nothing while a focus session is running, so it can never reset the session.
    BackHandler(running) { }

    // Edit these package names to point the four tools at your favourite apps.
    val tools = listOf(
        Triple("Write", "✎", ""),
        Triple("Sketch", "〰", ""),
        Triple("Record", "●", ""),
        Triple("Capture", "◉", ""),
        Triple("Phone", "✆", "")
    )
    fun runTool(name: String, pkg: String) {
        when (name) {
            "Record" -> ctx.startActivity(Intent(MediaStore.Audio.Media.RECORD_SOUND_ACTION))
            "Capture" -> ctx.startActivity(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
            "Phone" -> ctx.startActivity(Intent(Intent.ACTION_DIAL))
            "Write", "Sketch" -> if (!openNotes(ctx)) { query = "note"; drawer = true }
            else -> if (!openApp(ctx, pkg)) { query = name; drawer = true }
        }
    }

    Box(Modifier.fillMaxSize().background(bg)) {
    photo?.let {
        Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .45f)))
    }
    Box(
        Modifier.fillMaxSize().systemBarsPadding()
            .pointerInput(Unit) { detectTapGestures(onLongPress = { if (!running) menu = true }) }
            .pointerInput(running) {
                var drag = 0f
                detectVerticalDragGestures(
                    onDragStart = { drag = 0f },
                    onDragEnd = { if (drag < -150f && !running) drawer = true }
                ) { _, dy -> drag += dy }
            }
    ) {
        // In landscape the home screen scrolls so both fields stay reachable.
        val land = androidx.compose.ui.platform.LocalConfiguration.current.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
        Column(
            (if (land) Modifier.fillMaxSize().verticalScroll(rememberScrollState()) else Modifier.fillMaxSize())
                .padding(horizontal = 26.dp, vertical = if (land) 12.dp else 28.dp)
        ) {
            Text(
                now.format(DateTimeFormatter.ofPattern("h:mm")),
                color = ink, fontSize = if (running || land) 30.sp else 64.sp, fontWeight = FontWeight.Light
            )
            Text(now.format(DateTimeFormatter.ofPattern("EEEE, MMMM d")), color = mute, fontSize = 15.sp)

            Column(if (land) Modifier.padding(vertical = 16.dp) else Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                BasicTextField(
                    value = focus,
                    onValueChange = { focus = it.take(60); prefs.edit().putString("focus", focus).apply() },
                    textStyle = TextStyle(color = ink, fontSize = 34.sp, fontWeight = FontWeight.SemiBold, lineHeight = 38.sp),
                    cursorBrush = SolidColor(accent),
                    singleLine = true,
                    readOnly = running,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { if (!running) searchYouTube(ctx, focus); focusManager.clearFocus() }),
                    modifier = Modifier.fillMaxWidth(),
                    decorationBox = { inner ->
                        Column {
                            Box(Modifier.padding(bottom = 14.dp)) {
                                if (focus.isEmpty()) Text("What are you learning today?", color = mute.copy(alpha = .55f), fontSize = 34.sp, fontWeight = FontWeight.SemiBold, lineHeight = 38.sp)
                                inner()
                            }
                            Box(Modifier.fillMaxWidth().height(1.5.dp).background(line))
                        }
                    }
                )
                Spacer(Modifier.height(20.dp))
                BasicTextField(
                    value = creating,
                    onValueChange = {
                        creating = it.take(40)
                        prefs.edit().putString("creating", creating).putString("creatingDay", LocalDate.now().toString()).apply()
                    },
                    readOnly = running,
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus(); if (!running && creating.isNotBlank()) startFocusFor(creating) }),
                    textStyle = TextStyle(color = ink, fontSize = 22.sp, fontWeight = FontWeight.SemiBold),
                    cursorBrush = SolidColor(accent),
                    modifier = Modifier.fillMaxWidth(),
                    decorationBox = { inner ->
                        Column {
                            Box(Modifier.padding(bottom = 10.dp)) {
                                if (creating.isEmpty()) Text("What are you creating?", color = mute.copy(alpha = .55f), fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                                inner()
                            }
                            Box(Modifier.fillMaxWidth().height(1.5.dp).background(line))
                        }
                    }
                )
                Text("Starts after you type what you are creating. Creative: 30 min. Anything else: 1 hour, locked.", color = mute, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                Spacer(Modifier.height(22.dp))
                Row(
                    Modifier.clip(CircleShape).background(ink)
                        .clickable { onFocusTap() }
                        .padding(horizontal = 20.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(9.dp).clip(CircleShape).background(accent))
                    Spacer(Modifier.width(12.dp))
                    Text(
                        if (running) "%d:%02d".format(left / 60, left % 60) + (if (locked) "  ·  locked" else "")
                        else "Start focus · ${if (looksArtistic(creating)) 30 else 60} min",
                        color = bg, fontSize = 16.sp, fontWeight = FontWeight.Medium
                    )
                }
            }

            Row(
                Modifier.fillMaxWidth().alpha(if (running) .12f else 1f).horizontalScroll(rememberScrollState()).padding(bottom = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                folders.keys.forEach { name ->
                    val g = icons[name] ?: "●"
                    val hidden = g == "Hidden"
                    Box(
                        Modifier.size(44.dp)
                            .then(if (hidden) Modifier else Modifier.border(1.5.dp, line, CircleShape))
                            .clip(CircleShape).clickable(enabled = !running) { openFolder = name },
                        contentAlignment = Alignment.Center
                    ) { if (!hidden) Text(g, color = ink, fontSize = 18.sp) }
                }
                Box(
                    Modifier.size(44.dp).clip(CircleShape).clickable(enabled = !running) { naming = true },
                    contentAlignment = Alignment.Center
                ) { Text("+", color = mute, fontSize = 22.sp) }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                tools.forEach { (name, glyph, pkg) ->
                    Column(
                        Modifier.alpha(if (running && name != "Phone") .12f else 1f)
                            .clickable(enabled = !running || name == "Phone") { runTool(name, pkg) }.padding(4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(Modifier.size(46.dp).border(1.5.dp, line, CircleShape), contentAlignment = Alignment.Center) {
                            Text(glyph, color = ink, fontSize = 20.sp)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(name, color = mute, fontSize = 13.sp)
                    }
                }
            }
            Text(
                "All apps", color = mute, fontSize = 13.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally).alpha(if (running) .12f else 1f)
                    .clickable(enabled = !running) { drawer = true }.padding(16.dp)
            )
        }

        AnimatedVisibility(drawer, enter = slideInVertically { it }, exit = slideOutVertically { it }) {
            Column(Modifier.fillMaxSize().background(surface).padding(horizontal = 26.dp, vertical = 20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    BasicTextField(
                        value = query, onValueChange = { query = it }, singleLine = true,
                        textStyle = TextStyle(color = ink, fontSize = 20.sp),
                        cursorBrush = SolidColor(accent),
                        modifier = Modifier.weight(1f),
                        decorationBox = { inner ->
                            Box(Modifier.padding(vertical = 10.dp)) {
                                if (query.isEmpty()) Text(if (pickFor != null) "Choose an app for ${pickFor}" else "Find an app", color = mute, fontSize = 20.sp)
                                inner()
                            }
                        }
                    )
                    Text("Close", color = mute, modifier = Modifier.clickable { drawer = false; query = ""; pickFor = null }.padding(8.dp))
                }
                Box(Modifier.fillMaxWidth().height(1.5.dp).background(line))
                LazyColumn(Modifier.weight(1f)) {
                    items(apps.filter { it.label.contains(query, ignoreCase = true) }) { app ->
                        Text(
                            app.label, color = ink, fontSize = 28.sp, fontWeight = FontWeight.Light,
                            modifier = Modifier.fillMaxWidth()
                                .clickable {
                                    val pf = pickFor
                                    if (pf != null) { addToFolder(pf, app.pkg); drawer = false; query = ""; pickFor = null }
                                    else if (openApp(ctx, app.pkg)) { drawer = false; query = "" }
                                }
                                .padding(vertical = 10.dp)
                        )
                    }
                }
            }
        }
        val fo = openFolder
        if (fo != null && !drawer && folders.containsKey(fo)) {
            Box(
                Modifier.fillMaxSize().background(Color.Black.copy(alpha = .55f)).clickable { openFolder = null },
                contentAlignment = Alignment.Center
            ) {
                Column(
                    Modifier.padding(32.dp).clip(RoundedCornerShape(24.dp)).background(surface)
                        .pointerInput(Unit) { detectTapGestures { } }.padding(24.dp)
                ) {
                    Text(fo, color = ink, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    Row {
                        glyphs.forEach { g ->
                            val on = (icons[fo] ?: "●") == g
                            Text(
                                if (g == "Hidden") "Hide" else g,
                                color = if (on) accent else mute, fontSize = 20.sp,
                                modifier = Modifier.clickable { setIcon(fo, g) }.padding(end = 16.dp, top = 4.dp, bottom = 8.dp)
                            )
                        }
                    }
                    val members = folders[fo] ?: emptyList()
                    members.forEach { pkg ->
                        val label = apps.firstOrNull { it.pkg == pkg }?.label
                        if (label != null) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    label, color = ink, fontSize = 18.sp,
                                    modifier = Modifier.weight(1f)
                                        .clickable { if (openApp(ctx, pkg)) openFolder = null }.padding(vertical = 10.dp)
                                )
                                Text(
                                    "✕", color = mute, fontSize = 16.sp,
                                    modifier = Modifier.clickable { saveFolders(folders + (fo to members.filter { it != pkg })) }.padding(10.dp)
                                )
                            }
                        }
                    }
                    Text(
                        "+ Add an app", color = accent, fontSize = 16.sp,
                        modifier = Modifier.clickable { pickFor = fo; drawer = true }.padding(vertical = 10.dp)
                    )
                    Text(
                        "Delete folder", color = mute, fontSize = 14.sp,
                        modifier = Modifier.clickable { saveFolders(folders - fo); openFolder = null }.padding(vertical = 10.dp)
                    )
                }
            }
        }
        if (naming) {
            Box(
                Modifier.fillMaxSize().background(Color.Black.copy(alpha = .55f)).clickable { naming = false },
                contentAlignment = Alignment.Center
            ) {
                Column(
                    Modifier.padding(32.dp).clip(RoundedCornerShape(24.dp)).background(surface)
                        .pointerInput(Unit) { detectTapGestures { } }.padding(24.dp)
                ) {
                    Text("New folder", color = ink, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    BasicTextField(
                        value = newName, onValueChange = { newName = it.take(20) }, singleLine = true,
                        textStyle = TextStyle(color = ink, fontSize = 20.sp),
                        cursorBrush = SolidColor(accent),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                        decorationBox = { inner ->
                            Box {
                                if (newName.isEmpty()) Text("Folder name", color = mute, fontSize = 20.sp)
                                inner()
                            }
                        }
                    )
                    Box(Modifier.fillMaxWidth().height(1.5.dp).background(line))
                    Text(
                        "Create", color = accent, fontSize = 16.sp,
                        modifier = Modifier.clickable {
                            val n = newName.trim()
                            if (n.isNotEmpty() && !folders.containsKey(n)) {
                                saveFolders(folders + (n to emptyList<String>())); openFolder = n
                            }
                            naming = false; newName = ""
                        }.padding(top = 14.dp, bottom = 4.dp)
                    )
                }
            }
        }
        if (menu) {
            Box(
                Modifier.fillMaxSize().background(Color.Black.copy(alpha = .55f)).clickable { menu = false },
                contentAlignment = Alignment.Center
            ) {
                Column(
                    Modifier.padding(32.dp).clip(RoundedCornerShape(24.dp)).background(surface)
                        .pointerInput(Unit) { detectTapGestures { } }.padding(24.dp)
                ) {
                    Text("Background", color = ink, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "Choose a photo", color = ink, fontSize = 18.sp,
                        modifier = Modifier.clickable { menu = false; picker.launch("image/*") }.padding(vertical = 10.dp)
                    )
                    if (photo != null) {
                        Text(
                            "Set as lock screen", color = ink, fontSize = 18.sp,
                            modifier = Modifier.clickable {
                                menu = false
                                val ok = try {
                                    val bmp = BitmapFactory.decodeFile(bgFile(ctx).path)
                                    WallpaperManager.getInstance(ctx).setBitmap(bmp, null, true, WallpaperManager.FLAG_LOCK)
                                    true
                                } catch (e: Exception) { false }
                                Toast.makeText(ctx, if (ok) "Lock screen updated" else "Couldn’t change the lock screen", Toast.LENGTH_SHORT).show()
                            }.padding(vertical = 10.dp)
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Row {
                        swatches.forEachIndexed { i, sw ->
                            Box(
                                Modifier.padding(end = 12.dp).size(40.dp).clip(CircleShape).background(sw.first)
                                    .border(1.5.dp, line, CircleShape).clickable { pickSwatch(i) }
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Reset to default", color = mute, fontSize = 15.sp,
                        modifier = Modifier.clickable { pickSwatch(-1) }.padding(vertical = 10.dp)
                    )
                }
            }
        }
    }
    }
}
