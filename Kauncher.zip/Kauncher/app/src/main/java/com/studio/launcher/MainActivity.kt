package com.studio.launcher

import android.content.Context
import android.app.WallpaperManager
import android.content.Intent
import android.widget.Toast
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import java.io.File
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { Launcher(this) }
    }
}

data class AppItem(val label: String, val pkg: String)

fun loadApps(ctx: Context): List<AppItem> {
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val pm = ctx.packageManager
    return pm.queryIntentActivities(i, 0)
        .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
        .filter { it.pkg != ctx.packageName }
        .sortedBy { it.label.lowercase() }
}

fun openApp(ctx: Context, pkg: String): Boolean {
    val intent = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
    ctx.startActivity(intent)
    return true
}

// Background colour choices: colour to dark-theme flag.
val swatches = listOf(
    Color(0xFF16122A) to true, Color(0xFF000000) to true, Color(0xFF1F3A2E) to true,
    Color(0xFFF4EFE6) to false, Color(0xFFDDE7F0) to false
)

fun bgFile(ctx: Context) = File(ctx.filesDir, "bg.jpg")

fun loadBg(ctx: Context): ImageBitmap? =
    bgFile(ctx).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path)?.asImageBitmap() }

fun saveBg(ctx: Context, uri: Uri): Boolean {
    return try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 2000 || bounds.outHeight / sample > 2000) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: return false
        val rot = ctx.contentResolver.openInputStream(uri)?.use {
            androidx.exifinterface.media.ExifInterface(it).rotationDegrees
        } ?: 0
        if (rot != 0) {
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rot.toFloat()) }, true)
        }
        bgFile(ctx).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        true
    } catch (e: Exception) {
        false
    }
}

// Opens the phone's default notes app (Android 14+), or a known notes app as a fallback.
fun openNotes(ctx: Context): Boolean {
    try {
        ctx.startActivity(Intent("android.intent.action.CREATE_NOTE"))
        return true
    } catch (e: Exception) { }
    val known = listOf(
        "com.samsung.android.app.notes", "com.google.android.keep", "com.miui.notes",
        "com.oneplus.note", "com.coloros.note", "com.microsoft.office.onenote"
    )
    for (p in known) if (openApp(ctx, p)) return true
    return false
}

@Composable
fun Launcher(ctx: Context) {
    val sysDark = isSystemInDarkTheme()
    val prefs = remember { ctx.getSharedPreferences("studio", Context.MODE_PRIVATE) }
    var photo by remember { mutableStateOf<ImageBitmap?>(loadBg(ctx)) }
    var swatch by remember { mutableIntStateOf(prefs.getInt("swatch", -1)) }
    var menu by remember { mutableStateOf(false) }
    val dark = when {
        photo != null -> true
        swatch >= 0 -> swatches[swatch].second
        else -> sysDark
    }
    val bg = if (photo == null && swatch >= 0) swatches[swatch].first
        else if (dark) Color(0xFF16122A) else Color(0xFFE4E0EE)
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null && saveBg(ctx, uri)) {
            photo = loadBg(ctx); swatch = -1; prefs.edit().putInt("swatch", -1).apply()
        }
    }
    fun pickSwatch(i: Int) {
        swatch = i; photo = null; bgFile(ctx).delete(); prefs.edit().putInt("swatch", i).apply(); menu = false
    }
    val surface = if (dark) Color(0xFF221C3D) else Color(0xFFF3F1F8)
    val ink = if (dark) Color(0xFFEDEAF8) else Color(0xFF201A33)
    val mute = if (dark) Color(0xFF9189B0) else Color(0xFF6B6483)
    val line = if (dark) Color(0xFF342D55) else Color(0xFFC9C3DB)
    val accent = if (dark) Color(0xFF9C8CFF) else Color(0xFF4A35FF)

    var focus by remember { mutableStateOf(prefs.getString("focus", "") ?: "") }
    var left by remember { mutableIntStateOf(1500) }
    var running by remember { mutableStateOf(false) }
    var drawer by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    val apps = remember { loadApps(ctx) }

    LaunchedEffect(Unit) { while (true) { now = LocalDateTime.now(); delay(15_000) } }
    LaunchedEffect(running) {
        if (running) {
            while (left > 0) { delay(1000); left-- }
            running = false; left = 1500
        }
    }
    BackHandler(drawer) { drawer = false; query = "" }
    BackHandler(menu) { menu = false }

    // Edit these package names to point the four tools at your favourite apps.
    val tools = listOf(
        Triple("Write", "✎", ""),
        Triple("Sketch", "〰", ""),
        Triple("Record", "●", ""),
        Triple("Capture", "◉", ""),
        Triple("Phone", "✆", "")
    )
    fun runTool(name: String, pkg: String) {
        when (name) {
            "Record" -> ctx.startActivity(Intent(MediaStore.Audio.Media.RECORD_SOUND_ACTION))
            "Capture" -> ctx.startActivity(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
            "Phone" -> ctx.startActivity(Intent(Intent.ACTION_DIAL))
            "Write", "Sketch" -> if (!openNotes(ctx)) { query = "note"; drawer = true }
            else -> if (!openApp(ctx, pkg)) { query = name; drawer = true }
        }
    }

    Box(Modifier.fillMaxSize().background(bg)) {
    photo?.let {
        Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .45f)))
    }
    Box(
        Modifier.fillMaxSize().systemBarsPadding()
            .pointerInput(Unit) { detectTapGestures(onLongPress = { if (!running) menu = true }) }
            .pointerInput(running) {
                var drag = 0f
                detectVerticalDragGestures(
                    onDragStart = { drag = 0f },
                    onDragEnd = { if (drag < -150f && !running) drawer = true }
                ) { _, dy -> drag += dy }
            }
    ) {
        Column(Modifier.fillMaxSize().padding(horizontal = 26.dp, vertical = 28.dp)) {
            Text(
                now.format(DateTimeFormatter.ofPattern("h:mm")),
                color = ink, fontSize = if (running) 30.sp else 64.sp, fontWeight = FontWeight.Light
            )
            Text(now.format(DateTimeFormatter.ofPattern("EEEE, MMMM d")), color = mute, fontSize = 15.sp)

            Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                BasicTextField(
                    value = focus,
                    onValueChange = { focus = it.take(60); prefs.edit().putString("focus", focus).apply() },
                    textStyle = TextStyle(color = ink, fontSize = 34.sp, fontWeight = FontWeight.SemiBold, lineHeight = 38.sp),
                    cursorBrush = SolidColor(accent),
                    modifier = Modifier.fillMaxWidth(),
                    decorationBox = { inner ->
                        Column {
                            Box(Modifier.padding(bottom = 14.dp)) {
                                if (focus.isEmpty()) Text("What are you making today?", color = mute.copy(alpha = .55f), fontSize = 34.sp, fontWeight = FontWeight.SemiBold, lineHeight = 38.sp)
                                inner()
                            }
                            Box(Modifier.fillMaxWidth().height(1.5.dp).background(line))
                        }
                    }
                )
                Spacer(Modifier.height(22.dp))
                Row(
                    Modifier.clip(CircleShape).background(ink)
                        .clickable { if (running) { running = false; left = 1500 } else running = true }
                        .padding(horizontal = 20.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(9.dp).clip(CircleShape).background(accent))
                    Spacer(Modifier.width(12.dp))
                    Text(
                        if (running) "%d:%02d".format(left / 60, left % 60) else "Focus 25:00",
                        color = bg, fontSize = 16.sp, fontWeight = FontWeight.Medium
                    )
                }
            }

            Row(Modifier.fillMaxWidth().alpha(if (running) .12f else 1f), horizontalArrangement = Arrangement.SpaceEvenly) {
                tools.forEach { (name, glyph, pkg) ->
                    Column(
                        Modifier.clickable(enabled = !running) { runTool(name, pkg) }.padding(4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(Modifier.size(46.dp).border(1.5.dp, line, CircleShape), contentAlignment = Alignment.Center) {
                            Text(glyph, color = ink, fontSize = 20.sp)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(name, color = mute, fontSize = 13.sp)
                    }
                }
            }
            Text(
                "All apps", color = mute, fontSize = 13.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally).alpha(if (running) .12f else 1f)
                    .clickable(enabled = !running) { drawer = true }.padding(16.dp)
            )
        }

        AnimatedVisibility(drawer, enter = slideInVertically { it }, exit = slideOutVertically { it }) {
            Column(Modifier.fillMaxSize().background(surface).padding(horizontal = 26.dp, vertical = 20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    BasicTextField(
                        value = query, onValueChange = { query = it }, singleLine = true,
                        textStyle = TextStyle(color = ink, fontSize = 20.sp),
                        cursorBrush = SolidColor(accent),
                        modifier = Modifier.weight(1f),
                        decorationBox = { inner ->
                            Box(Modifier.padding(vertical = 10.dp)) {
                                if (query.isEmpty()) Text("Find an app", color = mute, fontSize = 20.sp)
                                inner()
                            }
                        }
                    )
                    Text("Close", color = mute, modifier = Modifier.clickable { drawer = false; query = "" }.padding(8.dp))
                }
                Box(Modifier.fillMaxWidth().height(1.5.dp).background(line))
                LazyColumn(Modifier.weight(1f)) {
                    items(apps.filter { it.label.contains(query, ignoreCase = true) }) { app ->
                        Text(
                            app.label, color = ink, fontSize = 28.sp, fontWeight = FontWeight.Light,
                            modifier = Modifier.fillMaxWidth()
                                .clickable { if (openApp(ctx, app.pkg)) { drawer = false; query = "" } }
                                .padding(vertical = 10.dp)
                        )
                    }
                }
            }
        }
        if (menu) {
            Box(
                Modifier.fillMaxSize().background(Color.Black.copy(alpha = .55f)).clickable { menu = false },
                contentAlignment = Alignment.Center
            ) {
                Column(
                    Modifier.padding(32.dp).clip(RoundedCornerShape(24.dp)).background(surface)
                        .pointerInput(Unit) { detectTapGestures { } }.padding(24.dp)
                ) {
                    Text("Background", color = ink, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "Choose a photo", color = ink, fontSize = 18.sp,
                        modifier = Modifier.clickable { menu = false; picker.launch("image/*") }.padding(vertical = 10.dp)
                    )
                    if (photo != null) {
                        Text(
                            "Set as lock screen", color = ink, fontSize = 18.sp,
                            modifier = Modifier.clickable {
                                menu = false
                                val ok = try {
                                    val bmp = BitmapFactory.decodeFile(bgFile(ctx).path)
                                    WallpaperManager.getInstance(ctx).setBitmap(bmp, null, true, WallpaperManager.FLAG_LOCK)
                                    true
                                } catch (e: Exception) { false }
                                Toast.makeText(ctx, if (ok) "Lock screen updated" else "Couldn’t change the lock screen", Toast.LENGTH_SHORT).show()
                            }.padding(vertical = 10.dp)
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Row {
                        swatches.forEachIndexed { i, sw ->
                            Box(
                                Modifier.padding(end = 12.dp).size(40.dp).clip(CircleShape).background(sw.first)
                                    .border(1.5.dp, line, CircleShape).clickable { pickSwatch(i) }
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Reset to default", color = mute, fontSize = 15.sp,
                        modifier = Modifier.clickable { pickSwatch(-1) }.padding(vertical = 10.dp)
                    )
                }
            }
        }
    }
    }
}
