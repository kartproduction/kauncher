package com.studio.launcher

import android.content.Context
import android.app.WallpaperManager
import android.content.Intent
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import android.content.SharedPreferences
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import android.widget.Toast
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import java.io.File
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

// Bumped every time the Home button is pressed while Kauncher is already open.
val homeSignal = mutableIntStateOf(0)

class MainActivity : ComponentActivity() {
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME)) homeSignal.intValue++
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { Launcher(this) }
    }
}

data class AppItem(val label: String, val pkg: String)

// One row of the All apps list: either an installed app or one of Kauncher's own items.
class ListEntry(val label: String, val special: String?, val sub: String?, val app: AppItem?)

fun uninstallApp(ctx: Context, pkg: String) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_DELETE, android.net.Uri.parse("package:$pkg")))
    } catch (e: Exception) {
        try {
            ctx.startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:$pkg")))
        } catch (e2: Exception) { }
    }
}

fun appInfo(ctx: Context, pkg: String) {
    try {
        ctx.startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:$pkg")))
    } catch (e: Exception) { }
}

fun loadApps(ctx: Context): List<AppItem> {
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val pm = ctx.packageManager
    return pm.queryIntentActivities(i, 0)
        .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
        .filter { it.pkg != ctx.packageName }
        .sortedBy { it.label.lowercase() }
}

fun findActivity(ctx: Context): android.app.Activity? {
    var c: Context? = ctx
    while (c is android.content.ContextWrapper) {
        if (c is android.app.Activity) return c
        c = c.baseContext
    }
    return null
}

fun openApp(ctx: Context, pkg: String): Boolean {
    val intent = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
    ctx.startActivity(intent)
    return true
}

// Background colour choices: colour to dark-theme flag.
val swatches = listOf(
    Color(0xFF16122A) to true, Color(0xFF000000) to true, Color(0xFF1F3A2E) to true,
    Color(0xFFF4EFE6) to false, Color(0xFFDDE7F0) to false
)

fun bgFile(ctx: Context) = File(ctx.filesDir, "bg.jpg")

fun loadBg(ctx: Context): ImageBitmap? =
    bgFile(ctx).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path)?.asImageBitmap() }

fun saveBg(ctx: Context, uri: Uri): Boolean {
    return try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 2000 || bounds.outHeight / sample > 2000) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: return false
        val rot = ctx.contentResolver.openInputStream(uri)?.use {
            androidx.exifinterface.media.ExifInterface(it).rotationDegrees
        } ?: 0
        if (rot != 0) {
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rot.toFloat()) }, true)
        }
        bgFile(ctx).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        true
    } catch (e: Exception) {
        false
    }
}

// Backup code: your folders and folder icons, as text you can save and paste back after a reinstall.
fun makeBackup(prefs: SharedPreferences): String {
    val o = org.json.JSONObject()
    o.put("folders", org.json.JSONObject(prefs.getString("folders", "{}") ?: "{}"))
    o.put("icons", org.json.JSONObject(prefs.getString("folderIcons", "{}") ?: "{}"))
    o.put("notes", org.json.JSONArray(prefs.getString("notes", "[]") ?: "[]"))
    val b = android.util.Base64.encodeToString(
        o.toString().toByteArray(Charsets.UTF_8), android.util.Base64.NO_WRAP or android.util.Base64.URL_SAFE
    )
    return "KAUNCHER1:$b"
}

fun restoreBackup(prefs: SharedPreferences, code: String): Boolean {
    return try {
        val t = code.replace(Regex("\\s"), "")
        if (!t.startsWith("KAUNCHER1:")) return false
        val json = String(android.util.Base64.decode(t.removePrefix("KAUNCHER1:"), android.util.Base64.URL_SAFE), Charsets.UTF_8)
        val o = org.json.JSONObject(json)
        val folders = o.getJSONObject("folders").toString()
        val icons = o.getJSONObject("icons").toString()
        val e = prefs.edit().putString("folders", folders).putString("folderIcons", icons)
        if (o.has("notes")) e.putString("notes", o.getJSONArray("notes").toString())
        e.apply()
        true
    } catch (e: Exception) { false }
}

fun loadFolders(prefs: SharedPreferences): Map<String, List<String>> {
    val out = LinkedHashMap<String, List<String>>()
    try {
        val o = org.json.JSONObject(prefs.getString("folders", "{}") ?: "{}")
        for (k in o.keys()) {
            val a = o.getJSONArray(k)
            out[k] = List(a.length()) { a.getString(it) }
        }
    } catch (e: Exception) { }
    return out
}

fun saveFoldersPrefs(prefs: SharedPreferences, m: Map<String, List<String>>) {
    val o = org.json.JSONObject()
    for ((k, v) in m) o.put(k, org.json.JSONArray(v))
    prefs.edit().putString("folders", o.toString()).apply()
}

val glyphs = listOf("●", "▲", "■", "★", "♥", "Hidden")

fun loadIcons(prefs: SharedPreferences): Map<String, String> {
    val out = LinkedHashMap<String, String>()
    try {
        val o = org.json.JSONObject(prefs.getString("folderIcons", "{}") ?: "{}")
        for (k in o.keys()) out[k] = o.getString(k)
    } catch (e: Exception) { }
    return out
}

fun saveIcons(prefs: SharedPreferences, m: Map<String, String>) {
    val o = org.json.JSONObject()
    for ((k, v) in m) o.put(k, v)
    prefs.edit().putString("folderIcons", o.toString()).apply()
}

val artWords = listOf(
    "art", "draw", "paint", "sketch", "illustrat", "design", "poem", "poetry", "song", "lyric", "music",
    "compos", "melod", "guitar", "piano", "sing", "writ", "story", "stories", "novel", "book", "script",
    "film", "video", "photo", "edit", "animat", "craft", "sculpt", "potter", "danc", "logo", "poster",
    "cover", "podcast", "record", "beat", "cartoon", "comic", "calligraph", "knit", "sew", "carv",
    "color", "colour", "canvas", "mural", "fashion"
)

// True when the text mentions something creative or art related.
fun looksArtistic(text: String): Boolean {
    val words = text.lowercase().split(Regex("[^a-z]+")).filter { it.isNotEmpty() }
    return words.any { w -> artWords.any { w.startsWith(it) } }
}

// Searches YouTube (app if installed, otherwise the browser).
fun searchYouTube(ctx: Context, q: String) {
    val t = q.trim()
    if (t.isEmpty()) return
    try {
        ctx.startActivity(Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra("query", t))
    } catch (e: Exception) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(t))))
        } catch (e2: Exception) { }
    }
}

// Opens the phone's default notes app (Android 14+), or a known notes app as a fallback.
fun openNotes(ctx: Context): Boolean {
    // Open the real notes app (so your notes are saved normally), then fall back to the system "create note" request.
    val known = listOf(
        "com.samsung.android.app.notes", "com.google.android.keep", "com.miui.notes",
        "com.oneplus.note", "com.coloros.note", "com.microsoft.office.onenote"
    )
    for (p in known) if (openApp(ctx, p)) return true
    try {
        ctx.startActivity(Intent("android.intent.action.CREATE_NOTE"))
        return true
    } catch (e: Exception) { }
    return false
}

// Opens the camera app itself (photos are saved to the gallery), not the "return one photo" request.
fun openCamera(ctx: Context): Boolean {
    try { ctx.startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)); return true } catch (e: Exception) { }
    try { ctx.startActivity(Intent(MediaStore.ACTION_IMAGE_CAPTURE)); return true } catch (e: Exception) { }
    return false
}

// Opens the voice recorder app itself (recordings are saved in the app).
fun openRecorder(ctx: Context): Boolean {
    val known = listOf(
        "com.sec.android.app.voicenote", "com.google.android.apps.recorder", "com.android.soundrecorder",
        "com.coloros.soundrecorder", "com.miui.soundrecorder"
    )
    for (p in known) if (openApp(ctx, p)) return true
    try { ctx.startActivity(Intent(MediaStore.Audio.Media.RECORD_SOUND_ACTION)); return true } catch (e: Exception) { }
    return false
}

@Composable
fun Launcher(ctx: Context) {
    val sysDark = isSystemInDarkTheme()
    val prefs = remember { ctx.getSharedPreferences("studio", Context.MODE_PRIVATE) }
    var photo by remember { mutableStateOf<ImageBitmap?>(loadBg(ctx)) }
    var swatch by remember { mutableIntStateOf(prefs.getInt("swatch", -1)) }
    var menu by remember { mutableStateOf(false) }
    var settingsOpen by remember { mutableStateOf(false) }
    var kotepad by remember { mutableStateOf(false) }
    var captureOpen by remember { mutableStateOf(false) }
    var recordOpen by remember { mutableStateOf(false) }
    var ownMedia by remember { mutableStateOf(prefs.getBoolean("ownMedia", true)) }
    var kotepadSketch by remember { mutableStateOf(false) }
    var writeKotepad by remember { mutableStateOf(prefs.getBoolean("writeKotepad", true)) }
    var artMin by remember { mutableIntStateOf(prefs.getInt("artMin", 30)) }
    var lockMin by remember { mutableIntStateOf(prefs.getInt("lockMin", 60)) }
    var autoStart by remember { mutableStateOf(prefs.getBoolean("autoStart", true)) }
    var pinLock by remember { mutableStateOf(prefs.getBoolean("pinLock", true)) }
    var themeMode by remember { mutableIntStateOf(prefs.getInt("themeMode", 0)) }   // 0 auto, 1 light, 2 dark
    var h24 by remember { mutableStateOf(prefs.getBoolean("h24", false)) }
    var kTop by remember { mutableStateOf(prefs.getBoolean("kTop", false)) }
    var game by remember { mutableStateOf(false) }
    var chess by remember { mutableStateOf(false) }
    var folders by remember { mutableStateOf(loadFolders(prefs)) }
    var openFolder by remember { mutableStateOf<String?>(null) }
    var pickFor by remember { mutableStateOf<String?>(null) }
    var naming by remember { mutableStateOf(false) }
    var backupMode by remember { mutableIntStateOf(0) }   // 0 = closed, 1 = back up, 2 = restore
    var backupCode by remember { mutableStateOf("") }
    var restoreText by remember { mutableStateOf("") }
    var newName by remember { mutableStateOf("") }
    val focusManager = LocalFocusManager.current
    var icons by remember { mutableStateOf(loadIcons(prefs)) }
    fun setIcon(name: String, g: String) { icons = icons + (name to g); saveIcons(prefs, icons) }
    fun saveFolders(m: Map<String, List<String>>) { folders = m; saveFoldersPrefs(prefs, m) }
    fun addToFolder(f: String, pkg: String) {
        val l = folders[f] ?: return
        if (pkg !in l) saveFolders(folders + (f to (l + pkg)))
    }
    val dark = when {
        photo != null -> true
        swatch >= 0 -> swatches[swatch].second
        themeMode == 1 -> false
        themeMode == 2 -> true
        else -> sysDark
    }
    val bg = if (photo == null && swatch >= 0) swatches[swatch].first
        else if (dark) Color(0xFF16122A) else Color(0xFFE4E0EE)
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null && saveBg(ctx, uri)) {
            photo = loadBg(ctx); swatch = -1; prefs.edit().putInt("swatch", -1).apply()
        }
    }
    fun pickSwatch(i: Int) {
        swatch = i; photo = null; bgFile(ctx).delete(); prefs.edit().putInt("swatch", i).apply(); menu = false
    }
    val surface = if (dark) Color(0xFF221C3D) else Color(0xFFF3F1F8)
    val ink = if (dark) Color(0xFFEDEAF8) else Color(0xFF201A33)
    val mute = if (dark) Color(0xFF9189B0) else Color(0xFF6B6483)
    val line = if (dark) Color(0xFF342D55) else Color(0xFFC9C3DB)
    val accent = if (dark) Color(0xFF9C8CFF) else Color(0xFF4A35FF)

    var focus by remember { mutableStateOf(prefs.getString("focus", "") ?: "") }
    // The session survives the activity being recreated: its end time is stored.
    val savedEnd = remember { prefs.getLong("endAt", 0L) }
    val resumed = remember { savedEnd > System.currentTimeMillis() }
    var endAt by remember { mutableStateOf(savedEnd) }
    var left by remember { mutableIntStateOf(if (resumed) ((savedEnd - System.currentTimeMillis()) / 1000).toInt() + 1 else 1500) }
    var running by remember { mutableStateOf(resumed) }
    var drawer by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    var apps by remember { mutableStateOf(loadApps(ctx)) }
    var appMenu by remember { mutableStateOf<AppItem?>(null) }
    // Refresh the list whenever Kauncher comes back to the front (after an uninstall or install).
    DisposableEffect(Unit) {
        val act = findActivity(ctx) as? ComponentActivity
        val obs = androidx.lifecycle.LifecycleEventObserver { _, ev ->
            if (ev == androidx.lifecycle.Lifecycle.Event.ON_RESUME) apps = loadApps(ctx)
        }
        act?.lifecycle?.addObserver(obs)
        onDispose { act?.lifecycle?.removeObserver(obs) }
    }
    var creating by remember {
        mutableStateOf(
            if (prefs.getString("creatingDay", "") == LocalDate.now().toString()) prefs.getString("creating", "") ?: "" else ""
        )
    }
    var locked by remember { mutableStateOf(resumed && prefs.getBoolean("sessLocked", false)) }
    var lastAuto by remember { mutableStateOf<String?>(creating) }
    fun startFocusFor(text: String) {
        val art = looksArtistic(text)
        left = (if (art) artMin else lockMin) * 60
        locked = !art
        lastAuto = text
        endAt = System.currentTimeMillis() + left * 1000L
        prefs.edit().putLong("endAt", endAt).putBoolean("sessLocked", locked).apply()
        running = true
    }
    fun clearSession() { prefs.edit().putLong("endAt", 0L).putBoolean("sessLocked", false).apply() }
    // When a session ends, the "What are you creating?" text is cleared.
    fun clearCreating() { creating = ""; lastAuto = ""; prefs.edit().putString("creating", "").apply() }
    fun onFocusTap() {
        if (running) {
            if (locked) Toast.makeText(ctx, "Locked until the session ends", Toast.LENGTH_SHORT).show()
            else { running = false; clearSession(); clearCreating() }
        } else startFocusFor(creating)
    }
    // Starts by itself only after you type what you are creating (never on an empty field or on open).
    LaunchedEffect(creating, running, autoStart) {
        if (!autoStart || running || creating.isBlank() || lastAuto == creating) return@LaunchedEffect
        delay(if (looksArtistic(creating)) 3_000L else 6_000L)
        startFocusFor(creating)
    }

    // While a locked (1 hour) session runs, pin the screen: Recents (|||) and Home stop working.
    LaunchedEffect(running, locked, pinLock) {
        val act = findActivity(ctx) ?: return@LaunchedEffect
        try {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
            val pinned = am.lockTaskModeState != android.app.ActivityManager.LOCK_TASK_MODE_NONE
            if (running && locked && pinLock) { if (!pinned) act.startLockTask() }
            else if (pinned) act.stopLockTask()
        } catch (e: Exception) { }
    }

    DisposableEffect(running, locked, pinLock) {
        val act = findActivity(ctx) as? ComponentActivity
        val obs = androidx.lifecycle.LifecycleEventObserver { _, ev ->
            if (ev == androidx.lifecycle.Lifecycle.Event.ON_RESUME && running && locked && pinLock) {
                try {
                    val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
                    if (am.lockTaskModeState == android.app.ActivityManager.LOCK_TASK_MODE_NONE) act?.startLockTask()
                } catch (e: Exception) { }
            }
        }
        act?.lifecycle?.addObserver(obs)
        onDispose { act?.lifecycle?.removeObserver(obs) }
    }

    LaunchedEffect(Unit) { while (true) { now = LocalDateTime.now(); delay(15_000) } }
    LaunchedEffect(running) {
        if (running) {
            while (true) {
                left = maxOf(0, ((endAt - System.currentTimeMillis() + 999) / 1000).toInt())
                if (left <= 0) break
                delay(500)
            }
            running = false; locked = false; clearSession(); clearCreating()
        }
    }
    BackHandler(openFolder != null) { openFolder = null }
    BackHandler(naming) { naming = false }
    BackHandler(settingsOpen) { settingsOpen = false }
    BackHandler(kotepad) { kotepad = false }
    BackHandler(captureOpen) { captureOpen = false }
    BackHandler(recordOpen) { recordOpen = false }
    BackHandler(backupMode != 0) { backupMode = 0 }
    BackHandler(drawer) { drawer = false; query = ""; pickFor = null }
    BackHandler(menu) { menu = false }
    BackHandler(appMenu != null) { appMenu = null }
    BackHandler(game) { game = false }
    BackHandler(chess) { chess = false }
    // Back does nothing while a focus session is running, so it can never reset the session.
    BackHandler(running) { }

    // Home button: close folders, the app list, search, menus and games, and show the home screen.
    var seenHome by remember { mutableIntStateOf(homeSignal.intValue) }
    LaunchedEffect(homeSignal.intValue) {
        if (homeSignal.intValue != seenHome) {
            seenHome = homeSignal.intValue
            openFolder = null; pickFor = null; naming = false; appMenu = null; backupMode = 0; settingsOpen = false; kotepad = false; captureOpen = false; recordOpen = false
            drawer = false; query = ""; menu = false; game = false; chess = false
        }
    }

    // Edit these package names to point the four tools at your favourite apps.
    val tools = listOf(
        Triple("Krite", "✎", ""),
        Triple("Ketch", "〰", ""),
        Triple("Kord", "●", ""),
        Triple("Kapture", "◉", ""),
        Triple("Phone", "✆", "")
    )
    fun runTool(name: String, pkg: String) {
        when (name) {
            "Kord" -> if (ownMedia) recordOpen = true else if (!openRecorder(ctx)) { query = "record"; drawer = true }
            "Kapture" -> if (ownMedia) captureOpen = true else if (!openCamera(ctx)) { query = "camera"; drawer = true }
            "Phone" -> ctx.startActivity(Intent(Intent.ACTION_DIAL))
            "Krite" -> if (writeKotepad) { kotepadSketch = false; kotepad = true } else if (!openNotes(ctx)) { query = "note"; drawer = true }
            "Ketch" -> if (writeKotepad) { kotepadSketch = true; kotepad = true } else if (!openNotes(ctx)) { query = "note"; drawer = true }
            else -> if (!openApp(ctx, pkg)) { query = name; drawer = true }
        }
    }

    Box(Modifier.fillMaxSize().background(bg)) {
    photo?.let {
        Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .45f)))
    }
    Box(
        Modifier.fillMaxSize().systemBarsPadding()
            .pointerInput(Unit) { detectTapGestures(onLongPress = { if (!running) menu = true }) }
            .pointerInput(running) {
                var drag = 0f
                detectVerticalDragGestures(
                    onDragStart = { drag = 0f },
                    onDragEnd = { if (drag < -150f && !running) drawer = true }
                ) { _, dy -> drag += dy }
            }
    ) {
        // In landscape the home screen scrolls so both fields stay reachable.
        BoxWithConstraints(Modifier.fillMaxSize()) {
        val land = maxWidth > maxHeight
        Column(
            (if (land) Modifier.fillMaxSize().verticalScroll(rememberScrollState()) else Modifier.fillMaxSize())
                .padding(horizontal = 26.dp, vertical = if (land) 12.dp else 28.dp)
        ) {
            Text(
                now.format(DateTimeFormatter.ofPattern(if (h24) "HH:mm" else "h:mm")),
                color = ink, fontSize = if (running || land) 30.sp else 64.sp, fontWeight = FontWeight.Light
            )
            Text(now.format(DateTimeFormatter.ofPattern("EEEE, MMMM d")), color = mute, fontSize = 15.sp)

            Column(if (land) Modifier.padding(vertical = 16.dp) else Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                BasicTextField(
                    value = focus,
                    onValueChange = { focus = it.take(60); prefs.edit().putString("focus", focus).apply() },
                    textStyle = TextStyle(color = ink, fontSize = 34.sp, fontWeight = FontWeight.SemiBold, lineHeight = 38.sp),
                    cursorBrush = SolidColor(accent),
                    singleLine = true,
                    readOnly = running,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { if (!running && focus.isNotBlank()) { searchYouTube(ctx, focus); focus = ""; prefs.edit().putString("focus", "").apply() }; focusManager.clearFocus() }),
                    modifier = Modifier.fillMaxWidth(),
                    decorationBox = { inner ->
                        Column {
                            Box(Modifier.padding(bottom = 14.dp)) {
                                if (focus.isEmpty()) Text("What are you learning today?", color = mute.copy(alpha = .55f), fontSize = 34.sp, fontWeight = FontWeight.SemiBold, lineHeight = 38.sp)
                                inner()
                            }
                            Box(Modifier.fillMaxWidth().height(1.5.dp).background(line))
                        }
                    }
                )
                Spacer(Modifier.height(20.dp))
                BasicTextField(
                    value = creating,
                    onValueChange = {
                        creating = it.take(40)
                        prefs.edit().putString("creating", creating).putString("creatingDay", LocalDate.now().toString()).apply()
                    },
                    readOnly = running,
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus(); if (!running && creating.isNotBlank()) startFocusFor(creating) }),
                    textStyle = TextStyle(color = ink, fontSize = 22.sp, fontWeight = FontWeight.SemiBold),
                    cursorBrush = SolidColor(accent),
                    modifier = Modifier.fillMaxWidth(),
                    decorationBox = { inner ->
                        Column {
                            Box(Modifier.padding(bottom = 10.dp)) {
                                if (creating.isEmpty()) Text("What are you creating?", color = mute.copy(alpha = .55f), fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                                inner()
                            }
                            Box(Modifier.fillMaxWidth().height(1.5.dp).background(line))
                        }
                    }
                )
                Text("Starts after you type what you are creating. Creative: 30 min. Anything else: 1 hour, locked.", color = mute, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                Spacer(Modifier.height(22.dp))
                Row(
                    Modifier.clip(CircleShape).background(ink)
                        .clickable { onFocusTap() }
                        .padding(horizontal = 20.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(9.dp).clip(CircleShape).background(accent))
                    Spacer(Modifier.width(12.dp))
                    Text(
                        if (running) "%d:%02d".format(left / 60, left % 60) + (if (locked) "  ·  locked" else "")
                        else "Start focus · ${if (looksArtistic(creating)) artMin else lockMin} min",
                        color = bg, fontSize = 16.sp, fontWeight = FontWeight.Medium
                    )
                }
            }

            Row(
                Modifier.fillMaxWidth().alpha(if (running) .12f else 1f).horizontalScroll(rememberScrollState()).padding(bottom = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                folders.keys.forEach { name ->
                    val g = icons[name] ?: "●"
                    val hidden = g == "Hidden"
                    Box(
                        Modifier.size(44.dp)
                            .then(if (hidden) Modifier else Modifier.border(1.5.dp, line, CircleShape))
                            .clip(CircleShape).clickable(enabled = !running) { openFolder = name },
                        contentAlignment = Alignment.Center
                    ) { if (!hidden) Text(g, color = ink, fontSize = 18.sp) }
                }
                Box(
                    Modifier.size(44.dp).clip(CircleShape).clickable(enabled = !running) { naming = true },
                    contentAlignment = Alignment.Center
                ) { Text("+", color = mute, fontSize = 22.sp) }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                tools.forEach { (name, glyph, pkg) ->
                    Column(
                        Modifier.alpha(if (running && name != "Phone") .12f else 1f)
                            .clickable(enabled = !running || name == "Phone") { runTool(name, pkg) }.padding(4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(Modifier.size(46.dp).border(1.5.dp, line, CircleShape), contentAlignment = Alignment.Center) {
                            Text(glyph, color = ink, fontSize = 20.sp)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(name, color = mute, fontSize = 13.sp)
                    }
                }
            }
            Text(
                "All apps", color = mute, fontSize = 13.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally).alpha(if (running) .12f else 1f)
                    .clickable(enabled = !running) { drawer = true }.padding(16.dp)
            )
        }
        }

        AnimatedVisibility(drawer, enter = slideInVertically { it }, exit = slideOutVertically { it }) {
            val listState = rememberLazyListState()
            Column(Modifier.fillMaxSize().background(surface).padding(horizontal = 26.dp, vertical = 20.dp)) {
                Row(
                    Modifier.pointerInput(Unit) {
                        // Swipe down on the search bar to go back home.
                        var drag = 0f
                        detectVerticalDragGestures(
                            onDragStart = { drag = 0f },
                            onDragEnd = { if (drag > 150f) { drawer = false; query = ""; pickFor = null } }
                        ) { _, dy -> drag += dy }
                    },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BasicTextField(
                        value = query, onValueChange = { query = it }, singleLine = true,
                        textStyle = TextStyle(color = ink, fontSize = 20.sp),
                        cursorBrush = SolidColor(accent),
                        modifier = Modifier.weight(1f),
                        decorationBox = { inner ->
                            Box(Modifier.padding(vertical = 10.dp)) {
                                if (query.isEmpty()) Text(if (pickFor != null) "Choose an app for ${pickFor}" else "Find an app", color = mute, fontSize = 20.sp)
                                inner()
                            }
                        }
                    )
                    Text("Close", color = mute, modifier = Modifier.clickable { drawer = false; query = ""; pickFor = null }.padding(8.dp))
                }
                Box(Modifier.fillMaxWidth().height(1.5.dp).background(line))
                LazyColumn(
                    Modifier.weight(1f).pointerInput(Unit) {
                        // Swipe down while the list is already at the top to go back home. This only watches the touch, so scrolling still works.
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                            val atTop = listState.firstVisibleItemIndex == 0 && listState.firstVisibleItemScrollOffset == 0
                            var total = 0f
                            while (true) {
                                val ev = awaitPointerEvent(PointerEventPass.Initial)
                                val c = ev.changes.firstOrNull { it.id == down.id } ?: break
                                total += c.positionChange().y
                                if (!c.pressed) break
                            }
                            if (atTop && total > 200f) { drawer = false; query = ""; pickFor = null }
                        }
                    },
                    state = listState
                ) {
                    val q = query.trim()
                    val kalendarMissing = apps.none { it.label.contains("kalendar", ignoreCase = true) }
                    val entries = ArrayList<ListEntry>()
                    if (pickFor == null) {
                        if ("chess game".contains(q, ignoreCase = true)) entries.add(ListEntry("Chess", "chess", null, null))
                        if ("kotepad notes notepad".contains(q, ignoreCase = true)) entries.add(ListEntry("Kotepad", "kotepad", "Your notes", null))
                        if (kalendarMissing && "kalendar by kasign".contains(q, ignoreCase = true))
                            entries.add(ListEntry("Kalendar", "kalendar", "by Kasign · tap to get the app", null))
                        if ("settings".contains(q, ignoreCase = true)) entries.add(ListEntry("Settings", "settings", "Kauncher and phone", null))
                        if ("tic-tac-toe game".contains(q, ignoreCase = true)) entries.add(ListEntry("Tic-Tac-Toe", "ttt", null, null))
                    }
                    for (a in apps) if (a.label.contains(query, ignoreCase = true)) entries.add(ListEntry(a.label, null, null, a))
                    // A to Z. With "Kauncher items on top" switched on, Kauncher's own rows come first (also A to Z).
                    val ordered = if (kTop) entries.sortedWith(compareBy({ it.special == null }, { it.label.lowercase() }))
                                  else entries.sortedBy { it.label.lowercase() }
                    items(ordered) { e ->
                        val app = e.app
                        if (app != null) {
                            Text(
                                app.label, color = ink, fontSize = 28.sp, fontWeight = FontWeight.Light,
                                modifier = Modifier.fillMaxWidth()
                                    .pointerInput(app.pkg) {
                                        detectTapGestures(
                                            onTap = {
                                                val pf = pickFor
                                                if (pf != null) { addToFolder(pf, app.pkg); drawer = false; query = ""; pickFor = null }
                                                else if (openApp(ctx, app.pkg)) { drawer = false; query = "" }
                                            },
                                            onLongPress = { if (pickFor == null) appMenu = app }
                                        )
                                    }
                                    .padding(vertical = 10.dp)
                            )
                        } else {
                            Column(
                                Modifier.fillMaxWidth()
                                    .clickable {
                                        drawer = false; query = ""
                                        when (e.special) {
                                            "chess" -> chess = true
                                            "kotepad" -> { kotepadSketch = false; kotepad = true }
                                            "ttt" -> game = true
                                            "settings" -> settingsOpen = true
                                            "kalendar" -> try {
                                                ctx.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://kartproduction.github.io/kalendarbykasign/download.html")))
                                            } catch (ex: Exception) { }
                                            else -> { }
                                        }
                                    }
                                    .padding(vertical = 10.dp)
                            ) {
                                Text(e.label, color = ink, fontSize = 28.sp, fontWeight = FontWeight.Light)
                                if (e.sub != null) Text(e.sub, color = mute, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        }
        val am = appMenu
        if (am != null) {
            Box(
                Modifier.fillMaxSize().background(Color.Black.copy(alpha = .55f)).clickable { appMenu = null },
                contentAlignment = Alignment.Center
            ) {
                Column(
                    Modifier.padding(32.dp).clip(RoundedCornerShape(24.dp)).background(surface)
                        .pointerInput(Unit) { detectTapGestures { } }.padding(24.dp)
                ) {
                    Text(am.label, color = ink, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    Text("Uninstall", color = ink, fontSize = 18.sp,
                        modifier = Modifier.clickable { uninstallApp(ctx, am.pkg); appMenu = null }.padding(vertical = 10.dp))
                    Text("App info", color = ink, fontSize = 18.sp,
                        modifier = Modifier.clickable { appInfo(ctx, am.pkg); appMenu = null }.padding(vertical = 10.dp))
                    Text("Cancel", color = mute, fontSize = 18.sp,
                        modifier = Modifier.clickable { appMenu = null }.padding(vertical = 10.dp))
                }
            }
        }
        val fo = openFolder
        if (fo != null && !drawer && folders.containsKey(fo)) {
            Box(
                Modifier.fillMaxSize().background(Color.Black.copy(alpha = .55f)).clickable { openFolder = null },
                contentAlignment = Alignment.Center
            ) {
                Column(
                    Modifier.padding(32.dp).clip(RoundedCornerShape(24.dp)).background(surface)
                        .pointerInput(Unit) { detectTapGestures { } }.padding(24.dp)
                ) {
                    Text(fo, color = ink, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    Row {
                        glyphs.forEach { g ->
                            val on = (icons[fo] ?: "●") == g
                            Text(
                                if (g == "Hidden") "Hide" else g,
                                color = if (on) accent else mute, fontSize = 20.sp,
                                modifier = Modifier.clickable { setIcon(fo, g) }.padding(end = 16.dp, top = 4.dp, bottom = 8.dp)
                            )
                        }
                    }
                    val members = folders[fo] ?: emptyList()
                    members.forEach { pkg ->
                        val label = apps.firstOrNull { it.pkg == pkg }?.label
                        if (label != null) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    label, color = ink, fontSize = 18.sp,
                                    modifier = Modifier.weight(1f)
                                        .clickable { if (openApp(ctx, pkg)) openFolder = null }.padding(vertical = 10.dp)
                                )
                                Text(
                                    "✕", color = mute, fontSize = 16.sp,
                                    modifier = Modifier.clickable { saveFolders(folders + (fo to members.filter { it != pkg })) }.padding(10.dp)
                                )
                            }
                        }
                    }
                    Text(
                        "+ Add an app", color = accent, fontSize = 16.sp,
                        modifier = Modifier.clickable { pickFor = fo; drawer = true }.padding(vertical = 10.dp)
                    )
                    Text(
                        "Delete folder", color = mute, fontSize = 14.sp,
                        modifier = Modifier.clickable { saveFolders(folders - fo); openFolder = null }.padding(vertical = 10.dp)
                    )
                }
            }
        }
        if (naming) {
            Box(
                Modifier.fillMaxSize().background(Color.Black.copy(alpha = .55f)).clickable { naming = false },
                contentAlignment = Alignment.Center
            ) {
                Column(
                    Modifier.padding(32.dp).clip(RoundedCornerShape(24.dp)).background(surface)
                        .pointerInput(Unit) { detectTapGestures { } }.padding(24.dp)
                ) {
                    Text("New folder", color = ink, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    BasicTextField(
                        value = newName, onValueChange = { newName = it.take(20) }, singleLine = true,
                        textStyle = TextStyle(color = ink, fontSize = 20.sp),
                        cursorBrush = SolidColor(accent),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                        decorationBox = { inner ->
                            Box {
                                if (newName.isEmpty()) Text("Folder name", color = mute, fontSize = 20.sp)
                                inner()
                            }
                        }
                    )
                    Box(Modifier.fillMaxWidth().height(1.5.dp).background(line))
                    Text(
                        "Create", color = accent, fontSize = 16.sp,
                        modifier = Modifier.clickable {
                            val n = newName.trim()
                            if (n.isNotEmpty() && !folders.containsKey(n)) {
                                saveFolders(folders + (n to emptyList<String>())); openFolder = n
                            }
                            naming = false; newName = ""
                        }.padding(top = 14.dp, bottom = 4.dp)
                    )
                }
            }
        }
        if (settingsOpen && !running) SettingsScreen(
            ctx = ctx, ink = ink, mute = mute, surface = surface, line = line, accent = accent,
            artMin = artMin, lockMin = lockMin, autoStart = autoStart, pinLock = pinLock, themeMode = themeMode, h24 = h24, kTop = kTop, writeKotepad = writeKotepad, ownMedia = ownMedia,
            onArtMin = { artMin = it; prefs.edit().putInt("artMin", it).apply() },
            onLockMin = { lockMin = it; prefs.edit().putInt("lockMin", it).apply() },
            onAutoStart = { autoStart = it; prefs.edit().putBoolean("autoStart", it).apply() },
            onPinLock = { pinLock = it; prefs.edit().putBoolean("pinLock", it).apply() },
            onTheme = { themeMode = it; prefs.edit().putInt("themeMode", it).apply() },
            onH24 = { h24 = it; prefs.edit().putBoolean("h24", it).apply() },
            onKTop = { kTop = it; prefs.edit().putBoolean("kTop", it).apply() },
            onOwnMedia = { ownMedia = it; prefs.edit().putBoolean("ownMedia", it).apply() },
            onWriteKotepad = { writeKotepad = it; prefs.edit().putBoolean("writeKotepad", it).apply() },
            onBackup = { backupCode = makeBackup(prefs); backupMode = 1 },
            onRestore = { restoreText = ""; backupMode = 2 },
            onClose = { settingsOpen = false }
        )
        if (backupMode != 0) {
            Box(
                Modifier.fillMaxSize().background(Color.Black.copy(alpha = .55f)).clickable { backupMode = 0 },
                contentAlignment = Alignment.Center
            ) {
                Column(
                    Modifier.padding(32.dp).clip(RoundedCornerShape(24.dp)).background(surface)
                        .pointerInput(Unit) { detectTapGestures { } }.padding(24.dp)
                ) {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    if (backupMode == 1) {
                        Text("Back up folders", color = ink, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Save this code somewhere safe, such as a note or a message to yourself. After a reinstall, choose Restore folders and paste it.",
                            color = mute, fontSize = 14.sp
                        )
                        Spacer(Modifier.height(10.dp))
                        Text(backupCode, color = mute, fontSize = 11.sp, maxLines = 3, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                        Spacer(Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                            Text(
                                "Copy", color = accent, fontSize = 16.sp,
                                modifier = Modifier.clickable {
                                    cm.setPrimaryClip(android.content.ClipData.newPlainText("Kauncher backup", backupCode))
                                    Toast.makeText(ctx, "Backup code copied", Toast.LENGTH_SHORT).show()
                                }.padding(vertical = 10.dp)
                            )
                            Text(
                                "Share", color = accent, fontSize = 16.sp,
                                modifier = Modifier.clickable {
                                    val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, backupCode) }
                                    try { ctx.startActivity(Intent.createChooser(send, "Save backup code")) } catch (e: Exception) { }
                                }.padding(vertical = 10.dp)
                            )
                        }
                    } else {
                        Text("Restore folders", color = ink, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        Text("Paste your backup code. This replaces your current folders.", color = mute, fontSize = 14.sp)
                        BasicTextField(
                            value = restoreText, onValueChange = { restoreText = it }, singleLine = true,
                            textStyle = TextStyle(color = ink, fontSize = 16.sp), cursorBrush = SolidColor(accent),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                            decorationBox = { inner ->
                                Box { if (restoreText.isEmpty()) Text("KAUNCHER1:…", color = mute, fontSize = 16.sp); inner() }
                            }
                        )
                        Box(Modifier.fillMaxWidth().height(1.5.dp).background(line))
                        Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                            Text(
                                "Paste", color = accent, fontSize = 16.sp,
                                modifier = Modifier.clickable {
                                    val t = cm.primaryClip?.getItemAt(0)?.coerceToText(ctx)?.toString() ?: ""
                                    if (t.isNotBlank()) restoreText = t
                                }.padding(top = 14.dp, bottom = 4.dp)
                            )
                            Text(
                                "Restore", color = accent, fontSize = 16.sp,
                                modifier = Modifier.clickable {
                                    if (restoreBackup(prefs, restoreText)) {
                                        folders = loadFolders(prefs); icons = loadIcons(prefs); openFolder = null
                                        backupMode = 0
                                        Toast.makeText(ctx, "Folders restored", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(ctx, "That code doesn’t look right", Toast.LENGTH_SHORT).show()
                                    }
                                }.padding(top = 14.dp, bottom = 4.dp)
                            )
                        }
                    }
                }
            }
        }
        if (captureOpen) CaptureScreen(ctx = ctx, ink = ink, mute = mute, surface = surface, line = line, accent = accent) { captureOpen = false }
        if (recordOpen) RecordScreen(ctx = ctx, ink = ink, mute = mute, surface = surface, line = line, accent = accent) { recordOpen = false }
        if (kotepad) Kotepad(ctx = ctx, prefs = prefs, startSketch = kotepadSketch, ink = ink, mute = mute, surface = surface, line = line, accent = accent) { kotepad = false }
        if (chess && !running) Chess(surface = surface, ink = ink, mute = mute, line = line) { chess = false }
        if (game && !running) TicTacToe(surface = surface, ink = ink, mute = mute, line = line) { game = false }
        if (menu) {
            Box(
                Modifier.fillMaxSize().background(Color.Black.copy(alpha = .55f)).clickable { menu = false },
                contentAlignment = Alignment.Center
            ) {
                Column(
                    Modifier.padding(32.dp).clip(RoundedCornerShape(24.dp)).background(surface)
                        .pointerInput(Unit) { detectTapGestures { } }.padding(24.dp)
                ) {
                    Text("Background", color = ink, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "Choose a photo", color = ink, fontSize = 18.sp,
                        modifier = Modifier.clickable { menu = false; picker.launch("image/*") }.padding(vertical = 10.dp)
                    )
                    if (photo != null) {
                        Text(
                            "Set as lock screen", color = ink, fontSize = 18.sp,
                            modifier = Modifier.clickable {
                                menu = false
                                val ok = try {
                                    val bmp = BitmapFactory.decodeFile(bgFile(ctx).path)
                                    WallpaperManager.getInstance(ctx).setBitmap(bmp, null, true, WallpaperManager.FLAG_LOCK)
                                    true
                                } catch (e: Exception) { false }
                                Toast.makeText(ctx, if (ok) "Lock screen updated" else "Couldn’t change the lock screen", Toast.LENGTH_SHORT).show()
                            }.padding(vertical = 10.dp)
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Row {
                        swatches.forEachIndexed { i, sw ->
                            Box(
                                Modifier.padding(end = 12.dp).size(40.dp).clip(CircleShape).background(sw.first)
                                    .border(1.5.dp, line, CircleShape).clickable { pickSwatch(i) }
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Reset to default", color = mute, fontSize = 15.sp,
                        modifier = Modifier.clickable { pickSwatch(-1) }.padding(vertical = 10.dp)
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Play Tic-Tac-Toe", color = ink, fontSize = 18.sp,
                        modifier = Modifier.clickable { menu = false; game = true }.padding(vertical = 10.dp)
                    )
                    Text(
                        "Play Chess", color = ink, fontSize = 18.sp,
                        modifier = Modifier.clickable { menu = false; chess = true }.padding(vertical = 10.dp)
                    )
                    Text(
                        "Back up folders", color = ink, fontSize = 18.sp,
                        modifier = Modifier.clickable { menu = false; backupCode = makeBackup(prefs); backupMode = 1 }.padding(vertical = 10.dp)
                    )
                    Text(
                        "Restore folders", color = ink, fontSize = 18.sp,
                        modifier = Modifier.clickable { menu = false; restoreText = ""; backupMode = 2 }.padding(vertical = 10.dp)
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Kauncher ${appVersion(ctx)} · © 2026 Kart Production. All rights reserved. Official download only: kartproduction.github.io/kauncher",
                        color = mute, fontSize = 11.sp, lineHeight = 15.sp
                    )
                }
            }
        }
    }
    }
}
