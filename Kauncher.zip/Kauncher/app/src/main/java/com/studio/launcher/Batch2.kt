package com.studio.launcher

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import org.json.JSONArray
import org.json.JSONObject
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.temporal.ChronoUnit

// ---------------------------------------------------------------------------------------------
// Version 4.15: focus hours, bedtime mode, and Nepali birthdays and anniversaries.
// Everything is stored on the phone. No new permissions.
// ---------------------------------------------------------------------------------------------

val BS_MONTH_EN = arrayOf("Baisakh", "Jestha", "Asar", "Shrawan", "Bhadau", "Asoj", "Kartik", "Mangsir", "Poush", "Magh", "Falgun", "Chaitra")

fun hourLabel(h: Int) = when {
    h == 0 || h == 24 -> "12:00 AM"
    h < 12 -> "$h:00 AM"
    h == 12 -> "12:00 PM"
    else -> "${h - 12}:00 PM"
}

// True when the hour is inside the window. A window such as 22 to 6 runs over midnight.
private fun inWindow(hour: Int, from: Int, to: Int) = if (from < to) hour in from until to else hour >= from || hour < to

// ---- Scheduled focus ("focus hours") ----------------------------------------------------------

fun schedOn(p: SharedPreferences) = p.getBoolean("schedOn", false)
fun schedDays(p: SharedPreferences) = p.getInt("schedDays", 0)      // 0 Sun to Fri, 1 Mon to Fri, 2 every day
fun schedFrom(p: SharedPreferences) = p.getInt("schedFrom", 9)
fun schedTo(p: SharedPreferences) = p.getInt("schedTo", 12)

fun focusHoursActive(p: SharedPreferences, now: LocalDateTime): Boolean {
    if (!schedOn(p)) return false
    val d = now.dayOfWeek
    val dayOk = when (schedDays(p)) {
        0 -> d != DayOfWeek.SATURDAY
        1 -> d != DayOfWeek.SATURDAY && d != DayOfWeek.SUNDAY
        else -> true
    }
    return dayOk && inWindow(now.hour, schedFrom(p), schedTo(p))
}

// ---- Bedtime mode -----------------------------------------------------------------------------

fun bedOn(p: SharedPreferences) = p.getBoolean("bedOn", false)
fun bedFrom(p: SharedPreferences) = p.getInt("bedFrom", 22)
fun bedTo(p: SharedPreferences) = p.getInt("bedTo", 6)
fun bedtimeActive(p: SharedPreferences, now: LocalDateTime) = bedOn(p) && inWindow(now.hour, bedFrom(p), bedTo(p))

private val categoryCache = HashMap<String, Boolean>()

// Games and social apps, as the apps themselves declare it. Apps that do not say may stay visible.
fun isWindDownApp(ctx: Context, pkg: String): Boolean = categoryCache.getOrPut(pkg) {
    try {
        val c = ctx.packageManager.getApplicationInfo(pkg, 0).category
        c == ApplicationInfo.CATEGORY_GAME || c == ApplicationInfo.CATEGORY_SOCIAL
    } catch (e: Exception) { false }
}

/** A short message when this app is hidden right now (focus hours or bedtime), otherwise null. */
fun hiddenReason(ctx: Context, p: SharedPreferences, pkg: String, now: LocalDateTime, pauseSet: Set<String>): String? {
    if (bedtimeActive(p, now) && (pkg in pauseSet || isWindDownApp(ctx, pkg)))
        return tr("Bedtime · apps return at %s").replace("%s", hourLabel(bedTo(p)))
    if (focusHoursActive(p, now) && pkg in pauseSet)
        return tr("Focus hours · until %s").replace("%s", hourLabel(schedTo(p)))
    return null
}

// ---- Nepali birthdays and anniversaries ---------------------------------------------------------

class BEvent(val name: String, val month: Int, val day: Int, val anniv: Boolean)

fun loadBdays(p: SharedPreferences): List<BEvent> = try {
    val a = JSONArray(p.getString("bdays", "[]") ?: "[]")
    (0 until a.length()).map { val o = a.getJSONObject(it); BEvent(o.getString("n"), o.getInt("m"), o.getInt("d"), o.optBoolean("a", false)) }
} catch (e: Exception) { emptyList() }

private fun saveBdays(p: SharedPreferences, list: List<BEvent>) {
    val a = JSONArray()
    for (e in list) a.put(JSONObject().put("n", e.name).put("m", e.month).put("d", e.day).put("a", e.anniv))
    p.edit().putString("bdays", a.toString()).apply()
}

fun addBday(p: SharedPreferences, e: BEvent) = saveBdays(p, (loadBdays(p) + e).takeLast(100))
fun removeBday(p: SharedPreferences, i: Int) = saveBdays(p, loadBdays(p).filterIndexed { idx, _ -> idx != i })

/** The next birthday or anniversary within 30 days, as one line for the home screen, or null. */
fun nextBday(p: SharedPreferences, today: LocalDate): String? {
    val list = loadBdays(p)
    if (list.isEmpty()) return null
    val bs = NepaliDate.toBs(today) ?: return null
    var best: BEvent? = null
    var bestDays = Int.MAX_VALUE
    for (e in list) {
        var d = NepaliDate.toAd(bs.first, e.month, e.day)
        if (d != null && d.isBefore(today)) d = NepaliDate.toAd(bs.first + 1, e.month, e.day)
        if (d == null) continue
        val n = ChronoUnit.DAYS.between(today, d).toInt()
        if (n in 0..30 && n < bestDays) { best = e; bestDays = n }
    }
    val e = best ?: return null
    val whenText = when (bestDays) {
        0 -> tr("today")
        1 -> tr("tomorrow")
        else -> tr("in %d days").replace("%d", bestDays.toString())
    }
    return (if (e.anniv) "💍 " else "🎂 ") + e.name + " · " + whenText
}
