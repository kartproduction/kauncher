package com.studio.launcher

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

// ---------------------------------------------------------------------------------------------
// Focus sounds: quiet background sound during a session. The sound is made by the phone itself
// while it plays, so there are no audio files and Kauncher still needs no internet permission.
// ---------------------------------------------------------------------------------------------

val FOCUS_SOUND_NAMES = listOf("Off", "Rain", "Ticking clock", "Soft noise", "Ocean waves", "Wind", "Fire crackle", "Night crickets", "Warm hum")

object FocusSound {
    private var flag: AtomicBoolean? = null

    @Synchronized fun stop() { flag?.set(false); flag = null }

    @Synchronized fun start(kind: Int) {
        stop()
        if (kind !in 1 until FOCUS_SOUND_NAMES.size) return
        val f = AtomicBoolean(true)
        flag = f
        Thread { play(kind, f) }.apply { isDaemon = true }.start()
    }

    private fun play(kind: Int, on: AtomicBoolean) {
        val rate = 22050
        val chunk = 2048
        var track: AudioTrack? = null
        try {
            val minBuf = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
                )
                .setAudioFormat(
                    AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
                )
                .setBufferSizeInBytes(maxOf(minBuf, chunk * 2 * 4))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            track.play()
            val buf = ShortArray(chunk)
            val rnd = Random(System.nanoTime())
            var lp = 0f           // low-pass state (rain)
            var brown = 0f        // brown noise state
            var drop = 0f         // rain droplet envelope
            var pos = 0           // sample counter inside the current second (clock)
            var beat = 0          // alternates tick / tock (clock)
            var fade = 0f         // fade in over about one second
            var oLp = 0f          // ocean low-pass state
            var oPh = 0f          // ocean swell phase
            var wLp = 0f          // wind low-pass state
            var wPh1 = 0f         // wind gust phases
            var wPh2 = 0f
            var fLp = 0f          // fire rumble state
            var pop = 0f          // fire crackle envelope
            var cPos = 0          // cricket sample counter
            var hPh1 = 0f         // hum phases
            var hPh2 = 0f
            val twoPi = (2.0 * PI).toFloat()
            while (on.get()) {
                for (i in 0 until chunk) {
                    val w = rnd.nextFloat() * 2f - 1f
                    var s = 0f
                    when (kind) {
                        1 -> {
                            lp += 0.30f * (w - lp)
                            if (rnd.nextFloat() < 0.0009f) drop = 0.9f
                            s = lp * 0.55f + w * drop * 0.25f
                            drop *= 0.985f
                        }
                        2 -> {
                            if (pos < 1000) {
                                val f = if (beat == 0) 1900f else 1350f
                                val env = exp(-pos / 160f)
                                s = ((sin(2.0 * PI * f * pos / rate).toFloat() * 0.7f) + w * 0.3f) * env * 0.8f
                            }
                            pos++
                            if (pos >= rate) { pos = 0; beat = 1 - beat }
                        }
                        3 -> {
                            brown = (brown + 0.02f * w) / 1.02f
                            s = (brown * 3.2f).coerceIn(-1f, 1f) * 0.9f
                        }
                        4 -> {
                            // ocean: soft noise that swells and fades about every 10 seconds
                            oLp += 0.07f * (w - oLp)
                            oPh += twoPi / (rate * 10f); if (oPh > twoPi) oPh -= twoPi
                            val sw = 0.5f + 0.5f * sin(oPh.toDouble()).toFloat()
                            s = (oLp * 3.2f * (0.15f + 0.85f * sw * sw)).coerceIn(-1f, 1f)
                        }
                        5 -> {
                            // wind: dark noise with slow gusts
                            wLp += 0.025f * (w - wLp)
                            wPh1 += twoPi / (rate * 13f); if (wPh1 > twoPi) wPh1 -= twoPi
                            wPh2 += twoPi / (rate * 7f); if (wPh2 > twoPi) wPh2 -= twoPi
                            val g = (0.5f + 0.5f * sin(wPh1.toDouble()).toFloat()) * (0.65f + 0.35f * sin(wPh2.toDouble()).toFloat())
                            s = (wLp * 5f * (0.2f + 0.8f * g)).coerceIn(-1f, 1f)
                        }
                        6 -> {
                            // fire: low rumble with random little pops
                            fLp += 0.03f * (w - fLp)
                            if (rnd.nextFloat() < 0.0007f) pop = 0.4f + 0.6f * rnd.nextFloat()
                            s = fLp * 1.6f + w * pop * 0.45f
                            pop *= 0.93f
                        }
                        7 -> {
                            // crickets: two soft chirping voices
                            s = (cricket(cPos, (rate * 1.1f).toInt(), 4400f, rate) + cricket(cPos + 9000, (rate * 1.37f).toInt(), 4900f, rate)) * 0.5f
                            cPos++
                            if (cPos >= rate * 100) cPos = 0
                        }
                        else -> {
                            // warm hum: low steady tones with a little rumble
                            hPh1 += twoPi * 110f / rate; if (hPh1 > twoPi) hPh1 -= twoPi
                            hPh2 += twoPi * 165f / rate; if (hPh2 > twoPi) hPh2 -= twoPi
                            brown = (brown + 0.02f * w) / 1.02f
                            s = sin(hPh1.toDouble()).toFloat() * 0.45f + sin(hPh2.toDouble()).toFloat() * 0.2f + brown * 1.2f
                        }
                    }
                    if (fade < 1f) fade = minOf(1f, fade + 1f / rate)
                    buf[i] = (s * fade * 0.28f * 32767f).toInt().coerceIn(-32768, 32767).toShort()
                }
                if (track.write(buf, 0, chunk) < 0) break
            }
        } catch (e: Exception) {
        } finally {
            try { track?.stop() } catch (e: Exception) { }
            try { track?.release() } catch (e: Exception) { }
        }
    }
}

// one cricket: a group of three short chirps, then silence until the cycle repeats
private fun cricket(n: Int, cycle: Int, freq: Float, rate: Int): Float {
    val pos = n % cycle
    val step = (0.065f * rate).toInt()
    val len = (0.035f * rate).toInt()
    val k = pos / step
    if (k > 2) return 0f
    val inPulse = pos - k * step
    if (inPulse >= len) return 0f
    val env = sin(PI * inPulse / len).toFloat()
    return sin(2.0 * PI * freq * pos / rate).toFloat() * env * 0.35f
}

fun focusSoundKind(prefs: android.content.SharedPreferences) = prefs.getInt("focusSound", 0)
