package com.studio.launcher

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

// ---------------------------------------------------------------------------------------------
// Focus sounds: quiet background sound during a session. The sound is made by the phone itself
// while it plays, so there are no audio files and Kauncher still needs no internet permission.
// ---------------------------------------------------------------------------------------------

val FOCUS_SOUND_NAMES = listOf("Off", "Rain", "Ticking clock", "Soft noise")

object FocusSound {
    private var flag: AtomicBoolean? = null

    @Synchronized fun stop() { flag?.set(false); flag = null }

    @Synchronized fun start(kind: Int) {
        stop()
        if (kind !in 1..3) return
        val f = AtomicBoolean(true)
        flag = f
        Thread { play(kind, f) }.apply { isDaemon = true }.start()
    }

    private fun play(kind: Int, on: AtomicBoolean) {
        val rate = 22050
        val chunk = 2048
        var track: AudioTrack? = null
        try {
            val minBuf = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
                )
                .setAudioFormat(
                    AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
                )
                .setBufferSizeInBytes(maxOf(minBuf, chunk * 2 * 4))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            track.play()
            val buf = ShortArray(chunk)
            val rnd = Random(System.nanoTime())
            var lp = 0f           // low-pass state (rain)
            var brown = 0f        // brown noise state
            var drop = 0f         // rain droplet envelope
            var pos = 0           // sample counter inside the current second (clock)
            var beat = 0          // alternates tick / tock (clock)
            var fade = 0f         // fade in over about one second
            while (on.get()) {
                for (i in 0 until chunk) {
                    val w = rnd.nextFloat() * 2f - 1f
                    var s = 0f
                    when (kind) {
                        1 -> {
                            lp += 0.30f * (w - lp)
                            if (rnd.nextFloat() < 0.0009f) drop = 0.9f
                            s = lp * 0.55f + w * drop * 0.25f
                            drop *= 0.985f
                        }
                        2 -> {
                            if (pos < 1000) {
                                val f = if (beat == 0) 1900f else 1350f
                                val env = exp(-pos / 160f)
                                s = ((sin(2.0 * PI * f * pos / rate).toFloat() * 0.7f) + w * 0.3f) * env * 0.8f
                            }
                            pos++
                            if (pos >= rate) { pos = 0; beat = 1 - beat }
                        }
                        else -> {
                            brown = (brown + 0.02f * w) / 1.02f
                            s = (brown * 3.2f).coerceIn(-1f, 1f) * 0.9f
                        }
                    }
                    if (fade < 1f) fade = minOf(1f, fade + 1f / rate)
                    buf[i] = (s * fade * 0.28f * 32767f).toInt().coerceIn(-32768, 32767).toShort()
                }
                if (track.write(buf, 0, chunk) < 0) break
            }
        } catch (e: Exception) {
        } finally {
            try { track?.stop() } catch (e: Exception) { }
            try { track?.release() } catch (e: Exception) { }
        }
    }
}

fun focusSoundKind(prefs: android.content.SharedPreferences) = prefs.getInt("focusSound", 0)
