package com.studio.launcher

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.provider.AlarmClock
import android.provider.Settings

// ---------------------------------------------------------------------------------------------
// Do not disturb during focus (optional). Android makes you grant "Do Not Disturb access" to the
// app first. Kauncher remembers your previous setting and puts it back when the session ends.
// ---------------------------------------------------------------------------------------------

fun dndOn(prefs: SharedPreferences) = prefs.getBoolean("focusDnd", false)

fun hasDndAccess(ctx: Context): Boolean =
    try { (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).isNotificationPolicyAccessGranted } catch (e: Exception) { false }

fun openDndAccessSettings(ctx: Context) {
    try { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (e: Exception) { openPhoneSettings(ctx, "android.settings.SETTINGS") }
}

fun focusDnd(ctx: Context, prefs: SharedPreferences, on: Boolean) {
    try {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) return
        if (on) {
            if (prefs.getInt("dndPrev", -1) < 0) prefs.edit().putInt("dndPrev", nm.currentInterruptionFilter).apply()
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
        } else {
            val prev = prefs.getInt("dndPrev", -1)
            if (prev >= 0) {
                nm.setInterruptionFilter(if (prev in 1..4) prev else NotificationManager.INTERRUPTION_FILTER_ALL)
                prefs.edit().putInt("dndPrev", -1).apply()
            }
        }
    } catch (e: Exception) { }
}

// ---- Search shortcuts: "n buy milk" saves a note, "t 20" starts a 20 minute timer ---------------

fun quickNoteOf(q: String): String? =
    Regex("^n\\s+(.+)$", RegexOption.IGNORE_CASE).find(q.trim())?.groupValues?.get(1)?.trim()?.takeIf { it.isNotEmpty() }

fun quickTimerOf(q: String): Int? =
    Regex("^t\\s+(\\d{1,3})$", RegexOption.IGNORE_CASE).find(q.trim())?.groupValues?.get(1)?.toIntOrNull()?.takeIf { it in 1..600 }

fun saveQuickNote(prefs: SharedPreferences, text: String) {
    val n = Note(System.currentTimeMillis().toString(36) + (0..999).random(), text.take(500), System.currentTimeMillis(), "text")
    saveNotes(prefs, loadNotes(prefs) + n)
}

// Uses the phone's own clock app for the timer.
fun startPhoneTimer(ctx: Context, minutes: Int): Boolean = try {
    ctx.startActivity(
        Intent(AlarmClock.ACTION_SET_TIMER).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra(AlarmClock.EXTRA_LENGTH, minutes * 60).putExtra(AlarmClock.EXTRA_MESSAGE, "Kauncher")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
    )
    true
} catch (e: Exception) { false }
