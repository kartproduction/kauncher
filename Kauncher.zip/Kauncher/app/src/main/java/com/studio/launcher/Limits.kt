package com.studio.launcher

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

// ---------------------------------------------------------------------------------------------
// Phone-time cap ("under 4 hours a day") and per-app daily limits ("TikTok: 30 min a day").
// Both use Android's own usage data (Usage access), worked out on the phone only.
// ---------------------------------------------------------------------------------------------

val PHONE_CAP_OPTIONS = listOf(0, 120, 180, 240, 300, 360, 480)           // minutes a day, 0 = off
val APP_LIMIT_OPTIONS = listOf(0, 15, 30, 45, 60, 90, 120)                // minutes a day, 0 = off

fun phoneCapMin(ctx: Context) = studioPrefs(ctx).getInt("phoneCapMin", 0)

fun nextOption(options: List<Int>, cur: Int): Int = options[(options.indexOf(cur).coerceAtLeast(0) + 1) % options.size]

fun hrsText(min: Int): String = if (min <= 0) "Off" else fmtDur(min)

// ---- Phone-time cap -------------------------------------------------------------------------

fun phoneTodayMs(ctx: Context): Long =
    usageBetween(ctx, dayStartMs(LocalDate.now()), System.currentTimeMillis()).values.sum()

// If today's phone time has passed the cap: returns a gentle sentence (and posts one quiet
// notification per day). Returns null when there is no cap, no usage access, or you are under it.
fun phoneCapNudge(ctx: Context): String? {
    val cap = phoneCapMin(ctx)
    if (cap <= 0 || !hasUsageAccess(ctx)) return null
    val used = try { phoneTodayMs(ctx) } catch (e: Exception) { return null }
    if (used < cap * 60_000L) return null
    val text = "You have passed ${fmtDur(cap)} on your phone today (${fmtMs(used)}). A good moment to put it down."
    val p = studioPrefs(ctx)
    val today = LocalDate.now().toString()
    if (p.getString("capNudgeDay", "") != today) {
        p.edit().putString("capNudgeDay", today).apply()
        postCapNotification(ctx, text)
    }
    return text
}

private fun postCapNotification(ctx: Context, text: String) {
    try {
        if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) return
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26)
            nm.createNotificationChannel(NotificationChannel("phone_cap", "Phone time nudge", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(
            ctx, 1, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = android.app.Notification.Builder(ctx, "phone_cap")
            .setSmallIcon(android.R.drawable.ic_menu_recent_history)
            .setContentTitle("Gentle reminder")
            .setContentText(text)
            .setStyle(android.app.Notification.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(4402, n)
    } catch (e: Exception) { }
}

// Days in a week where phone time went over the cap.
fun daysOverCap(perDay: LongArray, capMin: Int): Int = if (capMin <= 0) 0 else perDay.count { it > capMin * 60_000L }

// ---- Per-app daily limits -------------------------------------------------------------------

fun loadAppLimits(prefs: SharedPreferences): Map<String, Int> = try {
    val o = JSONObject(prefs.getString("appLimits", "{}") ?: "{}")
    o.keys().asSequence().associateWith { o.getInt(it) }.filterValues { it > 0 }
} catch (e: Exception) { emptyMap() }

fun saveAppLimits(prefs: SharedPreferences, m: Map<String, Int>) {
    val o = JSONObject()
    for ((k, v) in m) if (v > 0) o.put(k, v)
    prefs.edit().putString("appLimits", o.toString()).apply()
}

fun appLimitMin(prefs: SharedPreferences, pkg: String): Int = loadAppLimits(prefs)[pkg] ?: 0

fun appUsageTodayMs(ctx: Context, pkg: String): Long =
    usageBetween(ctx, dayStartMs(LocalDate.now()), System.currentTimeMillis())[pkg] ?: 0L

// When you tap an app that has used up its limit today: returns the sentence for the pause screen,
// otherwise null. Needs Usage access; without it limits cannot be checked.
fun appLimitReached(ctx: Context, prefs: SharedPreferences, pkg: String): String? {
    val lim = appLimitMin(prefs, pkg)
    if (lim <= 0 || !hasUsageAccess(ctx)) return null
    val used = try { appUsageTodayMs(ctx, pkg) } catch (e: Exception) { return null }
    if (used < lim * 60_000L) return null
    return "You have used it for ${fmtMs(used)} today. Your daily limit is ${fmtDur(lim)}."
}

// Times the limit pause screen was shown (used by the weekly report).
fun recordLimitHit(prefs: SharedPreferences, pkg: String) {
    val old = try { JSONArray(prefs.getString("limitLog", "[]") ?: "[]") } catch (e: Exception) { JSONArray() }
    val a = JSONArray()
    for (i in maxOf(0, old.length() - 399) until old.length()) a.put(old.get(i))
    a.put(JSONObject().put("t", System.currentTimeMillis()).put("p", pkg))
    prefs.edit().putString("limitLog", a.toString()).apply()
}

fun loadLimitLog(prefs: SharedPreferences): List<Pair<Long, String>> = try {
    val a = JSONArray(prefs.getString("limitLog", "[]") ?: "[]")
    List(a.length()) { val o = a.getJSONObject(it); o.getLong("t") to o.optString("p", "") }
} catch (e: Exception) { emptyList() }

@Composable
fun AppLimitsScreen(
    ctx: Context, prefs: SharedPreferences, apps: List<AppItem>,
    ink: Color, mute: Color, surface: Color, line: Color, accent: Color, onBack: () -> Unit
) {
    var limits by remember { mutableStateOf(loadAppLimits(prefs)) }
    val allowed = remember { hasUsageAccess(ctx) }
    Box(Modifier.fillMaxSize().background(surface).pointerInput(Unit) { detectTapGestures { } }.padding(horizontal = 26.dp, vertical = 20.dp)) {
        Column(Modifier.fillMaxSize()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Daily app limits", color = ink, fontSize = 28.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Light, modifier = Modifier.weight(1f))
                Text("Back", color = accent, fontSize = 16.sp, modifier = Modifier.clickable { onBack() }.padding(8.dp))
            }
            Text(
                "Tap an app to change its limit. After the limit, the pause screen shows every time you open it that day, and your weekly report counts how often.",
                color = mute, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
            )
            if (!allowed) {
                Text("Limits need Usage access, so Kauncher can see how long each app was open. Allow usage access", color = accent, fontSize = 15.sp,
                    modifier = Modifier.clickable { openUsageAccessSettings(ctx) }.padding(vertical = 8.dp))
            }
            LazyColumn(Modifier.weight(1f)) {
                items(apps.sortedBy { it.label.lowercase() }, key = { it.pkg }) { a ->
                    val cur = limits[a.pkg] ?: 0
                    Row(
                        Modifier.fillMaxWidth().clickable {
                            limits = limits + (a.pkg to nextOption(APP_LIMIT_OPTIONS, cur))
                            saveAppLimits(prefs, limits)
                        }.padding(vertical = 13.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(a.label, color = ink, fontSize = 18.sp, modifier = Modifier.weight(1f))
                        Text(if (cur > 0) fmtDur(cur) + " a day" else "", color = accent, fontSize = 15.sp)
                    }
                    Box(Modifier.fillMaxWidth().height(1.dp).background(line))
                }
            }
        }
    }
}
