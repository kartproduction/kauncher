package com.studio.launcher

import android.app.WallpaperManager
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import java.time.LocalDate

// ---------------------------------------------------------------------------------------------
// Optional: your streak as the lock screen wallpaper. It is drawn by the phone and replaces the
// current lock screen wallpaper. It is redrawn after a focus session and when the day changes.
// ---------------------------------------------------------------------------------------------

fun streakWallOn(prefs: SharedPreferences) = prefs.getBoolean("streakWall", false)

fun applyStreakWallpaper(ctx: Context, force: Boolean = false) {
    val app = ctx.applicationContext
    val prefs = studioPrefs(app)
    if (!force && !streakWallOn(prefs)) return
    val (todayMin, streak) = focusStats(prefs)
    val key = "${LocalDate.now()}|$streak|$todayMin"
    if (!force && prefs.getString("streakWallKey", "") == key) return
    Thread {
        try {
            val dm = app.resources.displayMetrics
            val w = dm.widthPixels; val h = dm.heightPixels
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            c.drawColor(0xFF16122A.toInt())
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
            p.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            p.color = 0xFFEDEAF8.toInt(); p.textSize = w * 0.30f
            c.drawText("$streak", w / 2f, h * 0.42f, p)
            p.textSize = w * 0.06f; p.color = 0xFF9C8CFF.toInt()
            c.drawText(if (streak == 1) "day in a row" else "days in a row", w / 2f, h * 0.42f + w * 0.12f, p)
            p.textSize = w * 0.04f; p.color = 0xFF9189B0.toInt()
            c.drawText(fmtDur(todayMin) + " focus today", w / 2f, h * 0.42f + w * 0.22f, p)
            WallpaperManager.getInstance(app).setBitmap(bmp, null, true, WallpaperManager.FLAG_LOCK)
            prefs.edit().putString("streakWallKey", key).apply()
        } catch (e: Exception) { }
    }.start()
}
