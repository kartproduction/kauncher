package com.studio.launcher

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.exifinterface.media.ExifInterface
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

// ---------------------------------------------------------------------------------------------
// "What you made" gallery. Most work is made outside the phone, so you can add a photo or a file
// of it after a session or from the weekly report. Files are copied into Kauncher (photos are
// shrunk), stay on the phone, and show in the weekly report for the week they were added.
// ---------------------------------------------------------------------------------------------

class MadeItem(val t: Long, val file: String, val name: String, val image: Boolean)

private const val MADE_KEY = "madeFiles"
private const val MADE_MAX = 120

fun madeDir(ctx: Context): File = File(ctx.filesDir, "made").also { it.mkdirs() }

fun loadMade(prefs: SharedPreferences): List<MadeItem> = try {
    val a = JSONArray(prefs.getString(MADE_KEY, "[]") ?: "[]")
    List(a.length()) { val o = a.getJSONObject(it); MadeItem(o.getLong("t"), o.getString("f"), o.optString("n", "File"), o.optBoolean("i", false)) }
} catch (e: Exception) { emptyList() }

private fun saveMade(ctx: Context, prefs: SharedPreferences, list: List<MadeItem>) {
    val keep = list.takeLast(MADE_MAX)
    for (gone in list.dropLast(MADE_MAX)) try { File(madeDir(ctx), gone.file).delete() } catch (e: Exception) { }
    val a = JSONArray()
    for (m in keep) a.put(JSONObject().put("t", m.t).put("f", m.file).put("n", m.name).put("i", m.image))
    prefs.edit().putString(MADE_KEY, a.toString()).apply()
}

// Copies a picked photo or file into Kauncher. Returns true if it was added.
fun addMadeFile(ctx: Context, uri: Uri): Boolean {
    return try {
        val cr = ctx.contentResolver
        val mime = cr.getType(uri) ?: ""
        var name = "File"
        cr.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) name = it.getString(0) ?: name }
        val id = System.currentTimeMillis().toString(36) + (0..99).random()
        val isImage = mime.startsWith("image/")
        val outName: String
        if (isImage) {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 1600 || bounds.outHeight / sample > 1600) sample *= 2
            var bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample }) } ?: return false
            val orient = try {
                cr.openInputStream(uri)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL) } ?: ExifInterface.ORIENTATION_NORMAL
            } catch (e: Exception) { ExifInterface.ORIENTATION_NORMAL }
            val deg = when (orient) { ExifInterface.ORIENTATION_ROTATE_90 -> 90f; ExifInterface.ORIENTATION_ROTATE_180 -> 180f; ExifInterface.ORIENTATION_ROTATE_270 -> 270f; else -> 0f }
            if (deg != 0f) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
            outName = "$id.jpg"
            File(madeDir(ctx), outName).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 82, it) }
        } else {
            val ext = name.substringAfterLast('.', "").filter { it.isLetterOrDigit() }.take(8)
            outName = if (ext.isEmpty()) id else "$id.$ext"
            val f = File(madeDir(ctx), outName)
            var copied = 0L
            cr.openInputStream(uri)?.use { input ->
                f.outputStream().use { out ->
                    val buf = ByteArray(16 * 1024)
                    while (true) {
                        val n = input.read(buf); if (n < 0) break
                        copied += n; if (copied > 25L * 1024 * 1024) { f.delete(); return false }   // keep files under 25 MB
                        out.write(buf, 0, n)
                    }
                }
            } ?: return false
        }
        val prefs = studioPrefs(ctx)
        saveMade(ctx, prefs, loadMade(prefs) + MadeItem(System.currentTimeMillis(), outName, name.take(60), isImage))
        true
    } catch (e: Exception) { false }
}

@Composable
fun MadeRow(ctx: Context, items: List<MadeItem>, ink: Color, mute: Color, line: Color) {
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        for (m in items) {
            val bmp = remember(m.file) {
                if (!m.image) null else try {
                    BitmapFactory.decodeFile(File(madeDir(ctx), m.file).path, BitmapFactory.Options().apply { inSampleSize = 4 })?.asImageBitmap()
                } catch (e: Exception) { null }
            }
            Box(Modifier.size(96.dp).clip(RoundedCornerShape(14.dp)).background(line), contentAlignment = Alignment.Center) {
                if (bmp != null) Image(bmp, m.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                else Text(m.name, color = ink, fontSize = 12.sp, maxLines = 4, modifier = Modifier.padding(8.dp))
            }
        }
    }
}
