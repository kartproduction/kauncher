package com.studio.launcher

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.provider.DocumentsContract
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

// ---------------------------------------------------------------------------------------------
// Extras: pause before apps, quiet apps, end-of-session prompt, breaks, gentle sound, and an
// automatic backup to a folder you choose. Everything stays on the phone.
// ---------------------------------------------------------------------------------------------

// ---- Small saved lists (JSON arrays of text) -------------------------------------------------

fun loadSet(prefs: SharedPreferences, key: String): Set<String> = try {
    val a = JSONArray(prefs.getString(key, "[]") ?: "[]")
    (0 until a.length()).map { a.getString(it) }.toSet()
} catch (e: Exception) { emptySet() }

fun saveSet(prefs: SharedPreferences, key: String, set: Set<String>) {
    val a = JSONArray(); for (s in set) a.put(s)
    prefs.edit().putString(key, a.toString()).apply()
}

// ---- Simple options --------------------------------------------------------------------------

fun breakMinutes(prefs: SharedPreferences) = prefs.getInt("breakMin", 5)          // 0 = no break offer
fun chimeOn(prefs: SharedPreferences) = prefs.getBoolean("chime", true)
fun askMadeOn(prefs: SharedPreferences) = prefs.getBoolean("askMade", true)

// A soft sound (the phone's own notification sound, so it follows the phone's volume and silent mode).
fun playChime(ctx: Context) {
    try {
        val uri = android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_NOTIFICATION)
        android.media.RingtoneManager.getRingtone(ctx, uri)?.play()
    } catch (e: Exception) { }
}

// ---- Pause log (used by the weekly report) ---------------------------------------------------

fun recordPause(prefs: SharedPreferences, opened: Boolean) {
    val old = try { JSONArray(prefs.getString("pauseLog", "[]") ?: "[]") } catch (e: Exception) { JSONArray() }
    val a = JSONArray()
    for (i in maxOf(0, old.length() - 299) until old.length()) a.put(old.get(i))
    a.put(JSONObject().put("t", System.currentTimeMillis()).put("o", opened))
    prefs.edit().putString("pauseLog", a.toString()).apply()
}

// Pairs of (time, opened anyway?)
fun loadPauseLog(prefs: SharedPreferences): List<Pair<Long, Boolean>> = try {
    val a = JSONArray(prefs.getString("pauseLog", "[]") ?: "[]")
    List(a.length()) { val o = a.getJSONObject(it); o.getLong("t") to o.optBoolean("o", true) }
} catch (e: Exception) { emptyList() }

// ---- "What did you make?" --------------------------------------------------------------------

// Adds a line to the note of the newest focus-log entry.
fun addToLastFocusNote(prefs: SharedPreferences, text: String) {
    val t = text.trim().take(200)
    if (t.isEmpty()) return
    try {
        val a = JSONArray(prefs.getString("focusLog", "[]") ?: "[]")
        if (a.length() == 0) return
        val o = a.getJSONObject(a.length() - 1)
        val old = o.optString("n", "")
        o.put("n", if (old.isBlank()) t else "$old · $t")
        prefs.edit().putString("focusLog", a.toString()).apply()
    } catch (e: Exception) { }
}

// ---- Backup to a folder you choose -----------------------------------------------------------

const val BACKUP_FILE = "kauncher-backup.txt"

fun backupTree(prefs: SharedPreferences): Uri? = prefs.getString("backupTree", null)?.let { Uri.parse(it) }

private fun findChild(ctx: Context, tree: Uri, name: String): Uri? {
    val parentId = DocumentsContract.getTreeDocumentId(tree)
    val kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId)
    ctx.contentResolver.query(
        kids, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null
    )?.use { c ->
        while (c.moveToNext()) if (c.getString(1) == name) return DocumentsContract.buildDocumentUriUsingTree(tree, c.getString(0))
    }
    return null
}

fun writeFolderBackup(ctx: Context, prefs: SharedPreferences): Boolean {
    val tree = backupTree(prefs) ?: return false
    return try {
        val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        val doc = findChild(ctx, tree, BACKUP_FILE)
            ?: DocumentsContract.createDocument(ctx.contentResolver, parent, "text/plain", BACKUP_FILE) ?: return false
        ctx.contentResolver.openOutputStream(doc, "wt")?.use { it.write(makeBackup(prefs).toByteArray(Charsets.UTF_8)) } ?: return false
        prefs.edit().putLong("lastBackupAt", System.currentTimeMillis()).apply()
        true
    } catch (e: Exception) { false }
}

fun readFolderBackup(ctx: Context, prefs: SharedPreferences): String? {
    val tree = backupTree(prefs) ?: return null
    return try {
        val doc = findChild(ctx, tree, BACKUP_FILE) ?: return null
        ctx.contentResolver.openInputStream(doc)?.use { String(it.readBytes(), Charsets.UTF_8) }
    } catch (e: Exception) { null }
}

// Backs up quietly in the background, at most once every 6 hours. Safe to call often.
fun autoBackupIfDue(ctx: Context, prefs: SharedPreferences, force: Boolean = false) {
    if (backupTree(prefs) == null) return
    val last = prefs.getLong("lastBackupAt", 0L)
    if (!force && System.currentTimeMillis() - last < 6 * 60 * 60 * 1000L) return
    val app = ctx.applicationContext
    Thread { writeFolderBackup(app, prefs) }.start()
}

// ---- Pause screen ----------------------------------------------------------------------------

@Composable
fun PauseScreen(label: String, seconds: Int, ink: Color, mute: Color, surface: Color, accent: Color, note: String? = null, intent: String? = null, opens: Int = -1, onOpen: () -> Unit, onCancel: () -> Unit) {
    var left by remember { mutableIntStateOf(seconds) }
    LaunchedEffect(Unit) { while (left > 0) { delay(1000); left-- } }
    val t = rememberInfiniteTransition(label = tr("breathe"))
    val s by t.animateFloat(0.65f, 1f, infiniteRepeatable(tween(4000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "s")
    Box(
        Modifier.fillMaxSize().background(surface).pointerInput(Unit) { detectTapGestures { } }.padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(150.dp).graphicsLayer { scaleX = s; scaleY = s }.clip(CircleShape).background(accent.copy(alpha = .35f)))
            Spacer(Modifier.height(32.dp))
            Text("Still want to open $label?", color = ink, fontSize = 24.sp, fontWeight = FontWeight.Light)
            Spacer(Modifier.height(8.dp))
            Text(note ?: "Take a slow breath first.", color = mute, fontSize = 16.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            if (intent != null) Text("Today you wanted to: $intent", color = accent, fontSize = 16.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.padding(top = 14.dp))
            if (opens >= 0) Text(
                if (opens == 0) tr("First time today") else if (opens == 1) tr("Opened once today") else tr("Opened %d times today").replace("%d", opens.toString()),
                color = mute, fontSize = 15.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.padding(top = 12.dp)
            )
            Spacer(Modifier.height(28.dp))
            Text(
                if (left > 0) "Open in $left" else "Open $label", color = if (left > 0) mute else accent, fontSize = 18.sp,
                fontWeight = if (left > 0) FontWeight.Normal else FontWeight.SemiBold,
                modifier = Modifier.clickable(enabled = left <= 0) { onOpen() }.padding(vertical = 12.dp)
            )
            Text(tr("Not now"), color = ink, fontSize = 18.sp, modifier = Modifier.clickable { onCancel() }.padding(vertical = 12.dp))
        }
    }
}

// ---- End of session: "What did you make?" and break offer ------------------------------------

@Composable
fun SessionEndCard(
    minutes: Int, askMade: Boolean, breakMin: Int, ink: Color, mute: Color, surface: Color, line: Color, accent: Color,
    onSave: (String) -> Unit, onBreak: (String) -> Unit, onClose: () -> Unit
) {
    var text by remember { mutableStateOf("") }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var addedCount by remember { mutableIntStateOf(0) }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null && addMadeFile(ctx, uri)) addedCount++
    }
    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = .55f)).clickable { onClose() },
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.padding(28.dp).clip(RoundedCornerShape(24.dp)).background(surface)
                .pointerInput(Unit) { detectTapGestures { } }.padding(24.dp)
        ) {
            Text(tr("Session complete ✓"), color = ink, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text("${fmtDur(minutes)} of focus.", color = mute, fontSize = 15.sp)
            if (askMade) {
                Spacer(Modifier.height(16.dp))
                Text(tr("What did you make?"), color = ink, fontSize = 17.sp)
                BasicTextField(
                    value = text, onValueChange = { text = it.take(120) }, singleLine = true,
                    textStyle = TextStyle(color = ink, fontSize = 18.sp), cursorBrush = SolidColor(accent),
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 6.dp),
                    decorationBox = { inner -> Box { if (text.isEmpty()) Text(tr("A line or two (optional)"), color = mute, fontSize = 18.sp); inner() } }
                )
                Box(Modifier.fillMaxWidth().height(1.5.dp).background(line))
            }
            Text(
                if (addedCount == 0) "Add a photo or file of it" else "Added $addedCount ✓  ·  add another", color = accent, fontSize = 16.sp,
                modifier = Modifier.clickable { filePicker.launch("*/*") }.padding(top = 12.dp, bottom = 4.dp)
            )
            Spacer(Modifier.height(10.dp))
            if (breakMin > 0) Text(
                "Take a $breakMin min break", color = accent, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clickable { onBreak(text) }.padding(vertical = 10.dp)
            )
            Text(
                if (askMade) "Save" else "Done", color = if (breakMin > 0) ink else accent, fontSize = 17.sp,
                fontWeight = if (breakMin > 0) FontWeight.Normal else FontWeight.SemiBold,
                modifier = Modifier.clickable { onSave(text) }.padding(vertical = 10.dp)
            )
            if (askMade) Text(tr("Skip"), color = mute, fontSize = 17.sp, modifier = Modifier.clickable { onClose() }.padding(vertical = 10.dp))
        }
    }
}

// ---- Break timer -----------------------------------------------------------------------------

@Composable
fun BreakScreen(ctx: Context, minutes: Int, chime: Boolean, ink: Color, mute: Color, surface: Color, accent: Color, pomodoro: Boolean = false, onStop: () -> Unit = {}, onDone: () -> Unit) {
    val endAt = remember { System.currentTimeMillis() + minutes * 60_000L }
    var left by remember { mutableIntStateOf(minutes * 60) }
    var over by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            left = maxOf(0, ((endAt - System.currentTimeMillis() + 999) / 1000).toInt())
            if (left <= 0) break
            delay(500)
        }
        over = true
        if (chime) playChime(ctx)
        if (pomodoro) { delay(1500); onDone() }   // Pomodoro: the next focus session starts by itself
    }
    Box(
        Modifier.fillMaxSize().background(surface).pointerInput(Unit) { detectTapGestures { } }.padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(if (over) "Break over" else "Break", color = mute, fontSize = 16.sp)
            Spacer(Modifier.height(8.dp))
            Text(
                if (over) "Ready when you are" else "${left / 60}:${("0" + left % 60).takeLast(2)}",
                color = ink, fontSize = if (over) 28.sp else 64.sp, fontWeight = FontWeight.Light
            )
            Spacer(Modifier.height(10.dp))
            Text(tr("Stand up, drink some water, look into the distance."), color = mute, fontSize = 15.sp)
            Spacer(Modifier.height(28.dp))
            Text(if (over) "Back to Kauncher" else "Skip break", color = accent, fontSize = 18.sp,
                modifier = Modifier.clickable { onDone() }.padding(vertical = 12.dp))
            if (pomodoro) Text(tr("Stop Pomodoro"), color = mute, fontSize = 16.sp,
                modifier = Modifier.clickable { onStop() }.padding(vertical = 8.dp))
        }
    }
}

// ---- Settings page for all of this -----------------------------------------------------------

@Composable
private fun AppPickScreen(title: String, hint: String, apps: List<AppItem>, selected: Set<String>, ink: Color, mute: Color, surface: Color, line: Color, accent: Color,
                          onToggle: (String) -> Unit, onBack: () -> Unit) {
    Box(Modifier.fillMaxSize().background(surface).pointerInput(Unit) { detectTapGestures { } }.padding(horizontal = 26.dp, vertical = 20.dp)) {
        Column(Modifier.fillMaxSize()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = ink, fontSize = 28.sp, fontWeight = FontWeight.Light, modifier = Modifier.weight(1f))
                Text(tr("Back"), color = accent, fontSize = 16.sp, modifier = Modifier.clickable { onBack() }.padding(8.dp))
            }
            Text(hint, color = mute, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp, bottom = 8.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(apps.sortedBy { it.label.lowercase() }, key = { it.pkg }) { a ->
                    Row(Modifier.fillMaxWidth().clickable { onToggle(a.pkg) }.padding(vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(a.label, color = ink, fontSize = 18.sp, modifier = Modifier.weight(1f))
                        Text(if (a.pkg in selected) "On" else "", color = accent, fontSize = 15.sp)
                    }
                    Box(Modifier.fillMaxWidth().height(1.dp).background(line))
                }
            }
        }
    }
}

@Composable
fun ExtrasScreen(
    ctx: Context, prefs: SharedPreferences, apps: List<AppItem>,
    pauseSet: Set<String>, quietSet: Set<String>, onPauseSet: (Set<String>) -> Unit, onQuietSet: (Set<String>) -> Unit,
    onRestoreCode: (String) -> Unit,
    ink: Color, mute: Color, surface: Color, line: Color, accent: Color, onClose: () -> Unit
) {
    var tick by remember { mutableIntStateOf(0) }
    var sub by remember { mutableIntStateOf(0) }            // 0 main, 1 pause list, 2 quiet list, 3 app limits
    val soundHandler = remember { android.os.Handler(android.os.Looper.getMainLooper()) }
    DisposableEffect(Unit) { onDispose { soundHandler.removeCallbacksAndMessages(null); if (!FocusSound.sleeping) FocusSound.stop() } }
    var msg by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (e: Exception) { }
            prefs.edit().putString("backupTree", uri.toString()).apply()
            msg = if (writeFolderBackup(ctx, prefs)) "Backed up." else "Couldn’t write to that folder."
            tick++
        }
    }
    if (sub == 1) { AppPickScreen("Pause before opening", "Tap apps that should ask you to take a breath before they open.", apps, pauseSet, ink, mute, surface, line, accent,
        onToggle = { p -> onPauseSet(if (p in pauseSet) pauseSet - p else pauseSet + p) }) { sub = 0 }; return }
    if (sub == 4) { SetPinScreen(prefs, ink, mute, surface, line, accent) { sub = 0; tick++ }; return }
    if (sub == 3) { AppLimitsScreen(ctx, prefs, apps, ink, mute, surface, line, accent) { sub = 0; tick++ }; return }
    if (sub == 2) { AppPickScreen("Quiet apps", "Quiet apps are hidden from All apps. Search for the app’s name to open it.", apps, quietSet, ink, mute, surface, line, accent,
        onToggle = { p -> onQuietSet(if (p in quietSet) quietSet - p else quietSet + p) }) { sub = 0 }; return }

    @Composable
    fun Header(text: String) = Text(text.uppercase(), color = mute, fontSize = 12.sp, letterSpacing = 1.sp, modifier = Modifier.padding(top = 26.dp, bottom = 4.dp))
    @Composable
    fun Item(title: String, value: String? = null, onClick: () -> Unit) {
        Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = ink, fontSize = 17.sp, modifier = Modifier.weight(1f))
            if (value != null) Text(value, color = accent, fontSize = 15.sp)
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(line))
    }

    val bm = remember(tick) { breakMinutes(prefs) }
    val tree = remember(tick) { backupTree(prefs) }
    val last = remember(tick) { prefs.getLong("lastBackupAt", 0L) }
    Box(Modifier.fillMaxSize().background(surface).pointerInput(Unit) { detectTapGestures { } }.padding(horizontal = 26.dp, vertical = 20.dp)) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(tr("Calm tools"), color = ink, fontSize = 30.sp, fontWeight = FontWeight.Light, modifier = Modifier.weight(1f))
                Text(tr("Close"), color = accent, fontSize = 16.sp, modifier = Modifier.clickable { onClose() }.padding(8.dp))
            }

            Header(tr("Apps"))
            Item(tr("Pause before opening"), if (pauseSet.isEmpty()) "None" else "${pauseSet.size} apps") { sub = 1 }
            Item(tr("Quiet apps (hidden until searched)"), if (quietSet.isEmpty()) "None" else "${quietSet.size} apps") { sub = 2 }
            Item(tr("Daily app limits"), loadAppLimits(prefs).size.let { if (it == 0) "None" else "$it apps" }) { sub = 3 }

            Header(tr("During a focus session"))
            Item(tr("Focus sound"), FOCUS_SOUND_NAMES[focusSoundKind(prefs).coerceIn(0, FOCUS_SOUND_NAMES.size - 1)]) {
                val k = (focusSoundKind(prefs) + 1) % FOCUS_SOUND_NAMES.size
                prefs.edit().putInt("focusSound", k).apply(); tick++
                // a short preview so you can hear it
                soundHandler.removeCallbacksAndMessages(null); FocusSound.start(k)
                if (k > 0) soundHandler.postDelayed({ FocusSound.stop() }, 4000L)
            }
            Text(tr("Built into Kauncher, so it works with no internet. It plays quietly while a session runs and stops when it ends."), color = mute, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))

            Item(tr("Do not disturb during focus"), if (dndOn(prefs) && !hasDndAccess(ctx)) "Needs access" else if (dndOn(prefs)) "On" else "Off") {
                val now = !dndOn(prefs)
                prefs.edit().putBoolean("focusDnd", now).apply()
                if (now && !hasDndAccess(ctx)) { openDndAccessSettings(ctx); msg = "Allow Do Not Disturb access for Kauncher, then come back." } else msg = ""
                tick++
            }

            Header(tr("Pomodoro"))
            Item(tr("Pomodoro mode"), if (pomodoroOn(prefs)) "On" else "Off") { prefs.edit().putBoolean("pomodoro", !pomodoroOn(prefs)).apply(); tick++ }
            Text(tr("25 minutes of focus, then a 5 minute break with a gentle sound, again and again. Every fourth break is 15 minutes. Tap the focus line to stop."), color = mute, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))

            Header(tr("Sleep"))
            Item(tr("Sleep sound"), if (FocusSound.isPlaying() && FocusSound.sleeping) "Playing · tap to stop" else "Tap to play") {
                soundHandler.removeCallbacksAndMessages(null)
                if (FocusSound.isPlaying() && FocusSound.sleeping) FocusSound.stop()
                else FocusSound.start(focusSoundKind(prefs).let { if (it == 0) 4 else it }, sleepMinutes(prefs), true)
                tick++
            }
            Item(tr("Sleep timer"), "${sleepMinutes(prefs)} min") {
                val opts = listOf(15, 30, 60); prefs.edit().putInt("sleepMin", opts[(opts.indexOf(sleepMinutes(prefs)) + 1) % opts.size]).apply(); tick++
            }
            Text(tr("Plays your focus sound, then fades out and stops by itself. It uses the sound chosen above (Ocean waves if none is chosen)."), color = mute, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))

            Header(tr("Evening"))
            Item(tr("Evening reflection"), reflectHour(prefs).let { if (it == 0) "Off" else "${it - 12}:00 PM" }) {
                val opts = listOf(0, 18, 19, 20, 21, 22); prefs.edit().putInt("reflectHour", opts[(opts.indexOf(reflectHour(prefs)) + 1) % opts.size]).apply(); tick++
            }
            Text(tr("At this time Kauncher asks “What did you make today?” once. Your line is saved in Kotepad and shown in the weekly report."), color = mute, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))

            Header(tr("Focus hours"))
            Item(tr("Scheduled focus"), if (schedOn(prefs)) "On" else "Off") { prefs.edit().putBoolean("schedOn", !schedOn(prefs)).apply(); tick++ }
            Item(tr("Days"), listOf("Sun–Fri", "Mon–Fri", "Every day")[schedDays(prefs).coerceIn(0, 2)]) { prefs.edit().putInt("schedDays", (schedDays(prefs) + 1) % 3).apply(); tick++ }
            Item(tr("From"), hourLabel(schedFrom(prefs))) { val o = listOf(5, 6, 7, 8, 9, 10, 11, 12, 13, 14); prefs.edit().putInt("schedFrom", o[(o.indexOf(schedFrom(prefs)) + 1) % o.size]).apply(); tick++ }
            Item(tr("Until"), hourLabel(schedTo(prefs))) { val o = listOf(10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21); prefs.edit().putInt("schedTo", o[(o.indexOf(schedTo(prefs)) + 1) % o.size]).apply(); tick++ }
            Text(tr("During these hours Kauncher hides the apps you set to “Pause before opening” and shows “Focus hours” on the home screen."), color = mute, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))

            Header(tr("Bedtime"))
            Item(tr("Bedtime mode"), if (bedOn(prefs)) "On" else "Off") { prefs.edit().putBoolean("bedOn", !bedOn(prefs)).apply(); tick++ }
            Item(tr("Starts at"), hourLabel(bedFrom(prefs))) { val o = listOf(20, 21, 22, 23); prefs.edit().putInt("bedFrom", o[(o.indexOf(bedFrom(prefs)) + 1) % o.size]).apply(); tick++ }
            Item(tr("Ends at"), hourLabel(bedTo(prefs))) { val o = listOf(4, 5, 6, 7, 8); prefs.edit().putInt("bedTo", o[(o.indexOf(bedTo(prefs)) + 1) % o.size]).apply(); tick++ }
            Text(tr("After this time Kauncher turns gray and hides games, social apps and the apps you set to “Pause before opening”, until morning. Apps that do not say what they are may stay visible."), color = mute, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))

            Header(tr("Birthdays and anniversaries"))
            var bName by remember { mutableStateOf("") }
            var bMonth by remember { mutableIntStateOf(0) }
            var bDay by remember { mutableIntStateOf(1) }
            var bAnniv by remember { mutableStateOf(false) }
            val bds = remember(tick) { loadBdays(prefs) }
            bds.forEachIndexed { i, e -> Item((if (e.anniv) "💍 " else "🎂 ") + e.name, "${BS_MONTH_EN[e.month.coerceIn(0, 11)]} ${e.day} · " + tr("Remove")) { removeBday(prefs, i); tick++ } }
            androidx.compose.foundation.text.BasicTextField(
                value = bName, onValueChange = { bName = it.take(30) },
                textStyle = TextStyle(color = ink, fontSize = 17.sp), cursorBrush = SolidColor(accent),
                modifier = Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 6.dp),
                decorationBox = { inner -> Box { if (bName.isEmpty()) Text(tr("Name"), color = mute, fontSize = 17.sp); inner() } }
            )
            Box(Modifier.fillMaxWidth().height(1.dp).background(line))
            Item(tr("Nepali month"), BS_MONTH_EN[bMonth]) { bMonth = (bMonth + 1) % 12 }
            Item(tr("Nepali day"), bDay.toString()) { bDay = bDay % 32 + 1 }
            Item(tr("Day +5"), null) { bDay = (bDay - 1 + 5) % 32 + 1 }
            Item(tr("Type"), if (bAnniv) tr("Anniversary") else tr("Birthday")) { bAnniv = !bAnniv }
            Item(tr("Save"), null) { if (bName.isNotBlank()) { addBday(prefs, BEvent(bName.trim(), bMonth, bDay, bAnniv)); bName = ""; tick++ } }
            Text(tr("Saved by Nepali date, so they come back every year. The next one within 30 days shows on the home screen. Dates work for Nepali years 2082 to 2088."), color = mute, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))

            Header(tr("After a focus session"))
            Item(tr("Ask “What did you make?”"), if (askMadeOn(prefs)) "On" else "Off") { prefs.edit().putBoolean("askMade", !askMadeOn(prefs)).apply(); tick++ }
            Item(tr("Break offer"), if (bm == 0) "Off" else "$bm min") {
                val opts = listOf(0, 5, 10, 15); prefs.edit().putInt("breakMin", opts[(opts.indexOf(bm) + 1) % opts.size]).apply(); tick++
            }
            Item(tr("Gentle sound at the end"), if (chimeOn(prefs)) "On" else "Off") { prefs.edit().putBoolean("chime", !chimeOn(prefs)).apply(); tick++ }

            Header(tr("Home screen"))
            Item(tr("Show focus time and streak"), if (prefs.getBoolean("showProgress", true)) "On" else "Off") { prefs.edit().putBoolean("showProgress", !prefs.getBoolean("showProgress", true)).apply(); tick++ }
            Item(tr("Show intentions line"), if (prefs.getBoolean("showIntentions", true)) "On" else "Off") { prefs.edit().putBoolean("showIntentions", !prefs.getBoolean("showIntentions", true)).apply(); tick++ }
            Item(tr("Show Nepali date and next festival"), if (prefs.getBoolean("showNepaliDate", true)) "On" else "Off") { prefs.edit().putBoolean("showNepaliDate", !prefs.getBoolean("showNepaliDate", true)).apply(); tick++ }
            Item(tr("Streak freeze: one rest day a week"), if (streakFreezeOn(prefs)) "On" else "Off") { prefs.edit().putBoolean("streakFreeze", !streakFreezeOn(prefs)).apply(); tick++ }
            Item(tr("Streak on the lock screen"), if (streakWallOn(prefs)) "On" else "Off") {
                val now = !streakWallOn(prefs)
                prefs.edit().putBoolean("streakWall", now).putString("streakWallKey", "").apply()
                if (now) { applyStreakWallpaper(ctx, true); msg = "Your lock screen wallpaper now shows your streak." }
                else msg = "To bring a picture back, choose a lock screen wallpaper in your phone’s settings."
                tick++
            }
            Text(tr("The lock screen option replaces your current lock screen wallpaper."), color = mute, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))

            Header(tr("Edit lock"))
            Item(tr("Edit lock"), editLockLabel(prefs)) { if (cycleEditLock(prefs)) { sub = 4 } else { tick++ } }
            if (editLockMode(prefs) != 0) Item(tr("Lock again now"), null) { relockEdit(prefs); tick++ }
            Text(tr("Protects Calm tools, the focus lengths in Kettings, app pause and limit changes, and Restore. To change them you enter your PIN or wait first, and then they stay open for 10 minutes. It cannot stop someone from uninstalling Kauncher."), color = mute, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))

            Header(tr("Automatic backup"))
            Item(tr("Backup folder"), if (tree == null) "Not set" else "Set") { picker.launch(null) }
            if (tree != null) {
                Item(tr("Back up now"), if (last > 0) "Last: " + java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.MEDIUM, java.text.DateFormat.SHORT).format(java.util.Date(last)) else null) {
                    msg = if (writeFolderBackup(ctx, prefs)) "Backed up." else "Couldn’t write to that folder."; tick++
                }
                Item(tr("Restore from backup folder")) {
                    val code = readFolderBackup(ctx, prefs)
                    if (code == null) msg = "No backup found in that folder." else onRestoreCode(code)
                }
                Item(tr("Turn off automatic backup")) { prefs.edit().remove("backupTree").apply(); msg = ""; tick++ }
            }
            if (msg.isNotEmpty()) Text(msg, color = accent, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
            Text(
                "Pick a folder (for example Documents). Kauncher saves one file there, “$BACKUP_FILE”, with your folders, notes, sketches and focus log. It updates itself when you leave Kauncher, at most every few hours. Photos and recordings are not included.",
                color = mute, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp, bottom = 40.dp)
            )
        }
    }
}
