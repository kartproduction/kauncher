package com.studio.launcher

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

// Kotepad: Kauncher's own notepad. Notes are stored on the phone, inside the app.
class Note(val id: String, val text: String, val t: Long)

fun loadNotes(prefs: SharedPreferences): List<Note> = try {
    val a = org.json.JSONArray(prefs.getString("notes", "[]") ?: "[]")
    List(a.length()) { val o = a.getJSONObject(it); Note(o.getString("id"), o.getString("text"), o.optLong("t", 0L)) }
} catch (e: Exception) { emptyList() }

fun saveNotes(prefs: SharedPreferences, list: List<Note>) {
    val a = org.json.JSONArray()
    for (n in list) a.put(org.json.JSONObject().put("id", n.id).put("text", n.text).put("t", n.t))
    prefs.edit().putString("notes", a.toString()).apply()
}

private fun titleOf(text: String): String =
    text.lines().firstOrNull { it.isNotBlank() }?.trim()?.take(60) ?: "Untitled"

private fun snippetOf(text: String): String =
    text.lines().filter { it.isNotBlank() }.drop(1).joinToString(" ").take(90)

@Composable
fun Kotepad(
    ctx: Context, prefs: SharedPreferences,
    ink: Color, mute: Color, surface: Color, line: Color, accent: Color, onClose: () -> Unit
) {
    val notes = remember { mutableStateListOf<Note>().apply { addAll(loadNotes(prefs)) } }
    var editId by remember { mutableStateOf<String?>(null) }
    var text by remember { mutableStateOf("") }
    var query by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var confirmDelete by remember { mutableStateOf(false) }

    val latestText = rememberUpdatedState(text)
    val latestId = rememberUpdatedState(editId)

    fun write(id: String, t: String) {
        val i = notes.indexOfFirst { it.id == id }
        if (i >= 0 && notes[i].text != t) notes[i] = Note(id, t, System.currentTimeMillis())
        saveNotes(prefs, notes.toList())
    }

    fun leave() {
        val id = editId
        if (id != null) {
            if (text.isBlank()) { notes.removeAll { it.id == id }; saveNotes(prefs, notes.toList()) } else write(id, text)
        }
        editId = null; status = ""; confirmDelete = false
    }

    // Saves a moment after you stop typing.
    LaunchedEffect(text, editId) {
        val id = editId ?: return@LaunchedEffect
        val cur = notes.firstOrNull { it.id == id } ?: return@LaunchedEffect
        if (cur.text == text) return@LaunchedEffect
        status = "Saving…"
        delay(400)
        write(id, text)
        status = "Saved"
    }

    // If Kotepad is closed (for example by the Home button) while you are typing, nothing is lost.
    DisposableEffect(Unit) {
        onDispose {
            val id = latestId.value
            if (id != null) {
                val t = latestText.value
                if (t.isBlank()) { notes.removeAll { it.id == id }; saveNotes(prefs, notes.toList()) } else write(id, t)
            }
        }
    }

    BackHandler(editId != null) { leave() }

    @Composable
    fun Pill(label: String, filled: Boolean, onClick: () -> Unit) {
        Box(
            Modifier.clip(RoundedCornerShape(50))
                .then(if (filled) Modifier.background(ink) else Modifier.border(1.5.dp, line, RoundedCornerShape(50)))
                .clickable { onClick() }.padding(horizontal = 18.dp, vertical = 10.dp)
        ) { Text(label, color = if (filled) surface else ink, fontSize = 15.sp) }
    }

    Box(
        Modifier.fillMaxSize().background(surface).pointerInput(Unit) { detectTapGestures { } }
            .padding(horizontal = 22.dp, vertical = 20.dp)
    ) {
        Column(Modifier.fillMaxSize().imePadding()) {
            if (editId == null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Kotepad", color = ink, fontSize = 30.sp, fontWeight = FontWeight.Light, modifier = Modifier.weight(1f))
                    Text("Close", color = accent, fontSize = 16.sp, modifier = Modifier.clickable { onClose() }.padding(8.dp))
                }
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Pill("New note", true) {
                        val n = Note(System.currentTimeMillis().toString(36) + (0..999).random(), "", System.currentTimeMillis())
                        notes.add(n); text = ""; confirmDelete = false; editId = n.id
                    }
                    BasicTextField(
                        value = query, onValueChange = { query = it }, singleLine = true,
                        textStyle = TextStyle(color = ink, fontSize = 17.sp), cursorBrush = SolidColor(accent),
                        modifier = Modifier.weight(1f),
                        decorationBox = { inner -> Box { if (query.isEmpty()) Text("Search notes", color = mute, fontSize = 17.sp); inner() } }
                    )
                }
                Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth().height(1.5.dp).background(line))
                val shown = notes.filter { query.isBlank() || it.text.contains(query.trim(), ignoreCase = true) }
                    .sortedByDescending { it.t }
                if (shown.isEmpty()) {
                    Text(
                        if (query.isBlank()) "No notes yet. Tap New note to start." else "No notes match your search.",
                        color = mute, fontSize = 15.sp, modifier = Modifier.padding(top = 28.dp)
                    )
                }
                LazyColumn(Modifier.weight(1f)) {
                    items(shown, key = { it.id }) { n ->
                        Column(
                            Modifier.fillMaxWidth()
                                .clickable { text = n.text; confirmDelete = false; status = ""; editId = n.id }
                                .padding(vertical = 12.dp)
                        ) {
                            Text(titleOf(n.text), color = ink, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            val sn = snippetOf(n.text)
                            if (sn.isNotEmpty()) Text(sn, color = mute, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.MEDIUM, java.text.DateFormat.SHORT)
                                    .format(java.util.Date(n.t)),
                                color = mute, fontSize = 12.sp
                            )
                        }
                        Box(Modifier.fillMaxWidth().height(1.dp).background(line))
                    }
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    Text("← Notes", color = accent, fontSize = 16.sp, modifier = Modifier.clickable { leave() }.padding(vertical = 8.dp))
                    Spacer(Modifier.weight(1f))
                    Text(
                        "Share", color = accent, fontSize = 16.sp,
                        modifier = Modifier.clickable {
                            val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
                            try { ctx.startActivity(Intent.createChooser(send, "Share note")) } catch (e: Exception) { }
                        }.padding(vertical = 8.dp)
                    )
                    Text(
                        if (confirmDelete) "Tap again to delete" else "Delete",
                        color = accent, fontSize = 16.sp,
                        modifier = Modifier.clickable {
                            if (!confirmDelete) confirmDelete = true
                            else {
                                val id = editId
                                if (id != null) { notes.removeAll { it.id == id }; saveNotes(prefs, notes.toList()) }
                                text = ""; editId = null; status = ""; confirmDelete = false
                            }
                        }.padding(vertical = 8.dp)
                    )
                }
                Text(status, color = mute, fontSize = 12.sp)
                Spacer(Modifier.height(6.dp))
                Box(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) {
                    BasicTextField(
                        value = text, onValueChange = { text = it; confirmDelete = false },
                        textStyle = TextStyle(color = ink, fontSize = 18.sp, lineHeight = 27.sp),
                        cursorBrush = SolidColor(accent),
                        modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 320.dp),
                        decorationBox = { inner ->
                            Box { if (text.isEmpty()) Text("Start writing…", color = mute, fontSize = 18.sp); inner() }
                        }
                    )
                }
            }
        }
    }
}
