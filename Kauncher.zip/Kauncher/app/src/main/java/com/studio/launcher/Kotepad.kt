package com.studio.launcher

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

// Kotepad: Kauncher's own notepad for text notes and sketches. Everything is stored on the phone, inside the app.
// kind = "text" (text is the note) or "sketch" (text holds the pen strokes as JSON).
class Note(val id: String, val text: String, val t: Long, val kind: String = "text")

fun loadNotes(prefs: SharedPreferences): List<Note> = try {
    val a = org.json.JSONArray(prefs.getString("notes", "[]") ?: "[]")
    List(a.length()) {
        val o = a.getJSONObject(it)
        Note(o.getString("id"), o.getString("text"), o.optLong("t", 0L), o.optString("k", "text"))
    }
} catch (e: Exception) { emptyList() }

fun saveNotes(prefs: SharedPreferences, list: List<Note>) {
    val a = org.json.JSONArray()
    for (n in list) a.put(org.json.JSONObject().put("id", n.id).put("text", n.text).put("t", n.t).put("k", n.kind))
    prefs.edit().putString("notes", a.toString()).apply()
}

// ---- Sketch data: points are saved as fractions of the canvas width, so a sketch looks the same at any size. ----
private class Pen(val color: Int, val width: Float, val pts: List<Float>)

private fun pensToJson(list: List<Pen>): String {
    val a = org.json.JSONArray()
    for (p in list) a.put(
        org.json.JSONObject().put("c", p.color).put("w", p.width.toDouble())
            .put("p", org.json.JSONArray(p.pts.map { it.toDouble() }))
    )
    return a.toString()
}

private fun parsePens(json: String): List<Pen> = try {
    val a = org.json.JSONArray(json)
    List(a.length()) {
        val o = a.getJSONObject(it)
        val p = o.getJSONArray("p")
        Pen(o.getInt("c"), o.getDouble("w").toFloat(), List(p.length()) { i -> p.getDouble(i).toFloat() })
    }
} catch (e: Exception) { emptyList() }

private val PAPER = Color(0xFFF7F5FB)
private val PALETTE = listOf(Color(0xFF201A33), Color(0xFF4A35FF), Color(0xFFD64545), Color(0xFF2F9E5B), Color(0xFFE0A526))
private val WIDTHS = listOf(0.004f, 0.009f, 0.018f)

private fun DrawScope.drawPens(pens: List<Pen>, scale: Float, offX: Float = 0f, offY: Float = 0f, minPx: Float = 1f) {
    for (pen in pens) {
        val p = pen.pts
        if (p.size < 2) continue
        val path = Path()
        path.moveTo(offX + p[0] * scale, offY + p[1] * scale)
        if (p.size == 2) path.lineTo(offX + p[0] * scale + 0.1f, offY + p[1] * scale)
        var i = 2
        while (i + 1 < p.size) { path.lineTo(offX + p[i] * scale, offY + p[i + 1] * scale); i += 2 }
        drawPath(
            path, Color(pen.color),
            style = androidx.compose.ui.graphics.drawscope.Stroke(
                width = maxOf(pen.width * scale, minPx), cap = StrokeCap.Round, join = StrokeJoin.Round
            )
        )
    }
}

// Saves the sketch as a picture in the gallery (Pictures/Kotepad).
private fun saveSketchImage(ctx: Context, pens: List<Pen>, canvasW: Float, canvasH: Float): Boolean {
    if (canvasW <= 1f || pens.isEmpty()) return false
    return try {
        val w = 1080
        val h = (canvasH / canvasW * w).toInt().coerceAtLeast(1)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = android.graphics.Canvas(bmp)
        cv.drawColor(PAPER.toArgb())
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            style = android.graphics.Paint.Style.STROKE
            strokeCap = android.graphics.Paint.Cap.ROUND
            strokeJoin = android.graphics.Paint.Join.ROUND
        }
        for (pen in pens) {
            val p = pen.pts
            if (p.size < 2) continue
            val path = android.graphics.Path()
            path.moveTo(p[0] * w, p[1] * w)
            if (p.size == 2) path.lineTo(p[0] * w + 0.1f, p[1] * w)
            var i = 2
            while (i + 1 < p.size) { path.lineTo(p[i] * w, p[i + 1] * w); i += 2 }
            paint.color = pen.color
            paint.strokeWidth = maxOf(pen.width * w, 1f)
            cv.drawPath(path, paint)
        }
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "Kotepad-${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Kotepad")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
        ctx.contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        true
    } catch (e: Exception) { false }
}

private fun titleOf(n: Note): String =
    if (n.kind == "sketch") "Sketch"
    else n.text.lines().firstOrNull { it.isNotBlank() }?.trim()?.take(60) ?: "Untitled"

private fun snippetOf(n: Note): String =
    if (n.kind == "sketch") "Drawing"
    else n.text.lines().filter { it.isNotBlank() }.drop(1).joinToString(" ").take(90)

@Composable
fun Kotepad(
    ctx: Context, prefs: SharedPreferences, startSketch: Boolean, startNew: Boolean = false,
    ink: Color, mute: Color, surface: Color, line: Color, accent: Color, onClose: () -> Unit
) {
    val notes = remember { mutableStateListOf<Note>().apply { addAll(loadNotes(prefs)) } }
    var editId by remember { mutableStateOf<String?>(null) }
    var text by remember { mutableStateOf("") }
    var query by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf(false) }          // second tap for Delete / Clear
    var pens by remember { mutableStateOf<List<Pen>>(emptyList()) }
    var live by remember { mutableStateOf<List<Float>>(emptyList()) }
    var colorIdx by remember { mutableIntStateOf(0) }           // 0-4 colours, 5 eraser
    var thick by remember { mutableIntStateOf(1) }
    var cw by remember { mutableFloatStateOf(1f) }
    var chh by remember { mutableFloatStateOf(1f) }
    var redo by remember { mutableStateOf<List<Pen>>(emptyList()) }
    val undoS = remember { mutableStateListOf<String>() }
    val redoS = remember { mutableStateListOf<String>() }
    var lastPush by remember { mutableLongStateOf(0L) }

    val latestText = rememberUpdatedState(text)
    val latestId = rememberUpdatedState(editId)

    fun kindOf(id: String?): String = notes.firstOrNull { it.id == id }?.kind ?: "text"

    fun write(id: String, t: String) {
        val i = notes.indexOfFirst { it.id == id }
        if (i >= 0 && notes[i].text != t) notes[i] = Note(id, t, System.currentTimeMillis(), notes[i].kind)
        saveNotes(prefs, notes.toList())
    }

    fun remove(id: String) { notes.removeAll { it.id == id }; saveNotes(prefs, notes.toList()) }

    fun leave() {
        val id = editId
        if (id != null) {
            if (kindOf(id) == "sketch") { if (pens.isEmpty()) remove(id) }
            else if (text.isBlank()) remove(id) else write(id, text)
        }
        editId = null; status = ""; confirm = false; live = emptyList()
    }

    fun newNote(kind: String) {
        val n = Note(System.currentTimeMillis().toString(36) + (0..999).random(), if (kind == "sketch") "[]" else "", System.currentTimeMillis(), kind)
        notes.add(n); text = ""; pens = emptyList(); redo = emptyList(); undoS.clear(); redoS.clear(); confirm = false; status = ""; editId = n.id
    }

    fun undoText() { if (undoS.isNotEmpty()) { redoS.add(text); text = undoS.removeAt(undoS.size - 1); lastPush = 0L } }
    fun redoText() { if (redoS.isNotEmpty()) { undoS.add(text); text = redoS.removeAt(redoS.size - 1); lastPush = 0L } }

    LaunchedEffect(Unit) { if (startSketch) newNote("sketch") else if (startNew) newNote("text") }

    // Text notes save a moment after you stop typing.
    LaunchedEffect(text, editId) {
        val id = editId ?: return@LaunchedEffect
        val cur = notes.firstOrNull { it.id == id } ?: return@LaunchedEffect
        if (cur.kind != "text" || cur.text == text) return@LaunchedEffect
        status = "Saving…"
        delay(400)
        write(id, text)
        status = "Saved"
    }

    // If Kotepad closes (for example with the Home button) while you are typing, nothing is lost.
    DisposableEffect(Unit) {
        onDispose {
            val id = latestId.value
            if (id != null && kindOf(id) == "text") {
                val t = latestText.value
                if (t.isBlank()) remove(id) else write(id, t)
            }
        }
    }

    BackHandler(editId != null) { leave() }

    @Composable
    fun Pill(label: String, filled: Boolean, onClick: () -> Unit) {
        Box(
            Modifier.clip(RoundedCornerShape(50))
                .then(if (filled) Modifier.background(ink) else Modifier.border(1.5.dp, line, RoundedCornerShape(50)))
                .clickable { onClick() }.padding(horizontal = 16.dp, vertical = 10.dp)
        ) { Text(label, color = if (filled) surface else ink, fontSize = 15.sp) }
    }

    Box(
        Modifier.fillMaxSize().background(surface).pointerInput(Unit) { detectTapGestures { } }
            .padding(horizontal = 22.dp, vertical = 20.dp)
    ) {
        Column(Modifier.fillMaxSize().imePadding()) {
            val id = editId
            if (id == null) {
                // ---- list of notes ----
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Kotepad", color = ink, fontSize = 30.sp, fontWeight = FontWeight.Light, modifier = Modifier.weight(1f))
                    Text("Close", color = accent, fontSize = 16.sp, modifier = Modifier.clickable { onClose() }.padding(8.dp))
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Pill("New note", true) { newNote("text") }
                    Pill("New sketch", false) { newNote("sketch") }
                }
                Spacer(Modifier.height(10.dp))
                BasicTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    textStyle = TextStyle(color = ink, fontSize = 17.sp), cursorBrush = SolidColor(accent),
                    modifier = Modifier.fillMaxWidth(),
                    decorationBox = { inner -> Box { if (query.isEmpty()) Text("Search notes", color = mute, fontSize = 17.sp); inner() } }
                )
                Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth().height(1.5.dp).background(line))
                val q = query.trim()
                val shown = notes.filter {
                    q.isEmpty() || (if (it.kind == "sketch") "sketch drawing".contains(q, ignoreCase = true) else it.text.contains(q, ignoreCase = true))
                }.sortedByDescending { it.t }
                if (shown.isEmpty()) {
                    Text(
                        if (q.isEmpty()) "Nothing here yet. Tap New note or New sketch." else "No notes match your search.",
                        color = mute, fontSize = 15.sp, modifier = Modifier.padding(top = 28.dp)
                    )
                }
                LazyColumn(Modifier.weight(1f)) {
                    items(shown, key = { it.id }) { n ->
                        Row(
                            Modifier.fillMaxWidth()
                                .clickable {
                                    confirm = false; status = ""
                                    redo = emptyList(); undoS.clear(); redoS.clear()
                                    if (n.kind == "sketch") { pens = parsePens(n.text) } else { text = n.text }
                                    editId = n.id
                                }
                                .padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (n.kind == "sketch") {
                                val thumb = remember(n.id, n.t) { parsePens(n.text) }
                                Canvas(Modifier.size(52.dp).clip(RoundedCornerShape(10.dp)).background(PAPER)) {
                                    if (thumb.isNotEmpty()) {
                                        var x0 = Float.MAX_VALUE; var x1 = -Float.MAX_VALUE; var y0 = Float.MAX_VALUE; var y1 = -Float.MAX_VALUE
                                        for (pen in thumb) { var i = 0; while (i + 1 < pen.pts.size) {
                                            x0 = minOf(x0, pen.pts[i]); x1 = maxOf(x1, pen.pts[i]); y0 = minOf(y0, pen.pts[i + 1]); y1 = maxOf(y1, pen.pts[i + 1]); i += 2 } }
                                        val w = (x1 - x0).coerceAtLeast(0.02f); val h = (y1 - y0).coerceAtLeast(0.02f)
                                        val sc = minOf(size.width * 0.84f / w, size.height * 0.84f / h)
                                        drawPens(thumb, sc, (size.width - w * sc) / 2f - x0 * sc, (size.height - h * sc) / 2f - y0 * sc, 1.3f)
                                    }
                                }
                                Spacer(Modifier.width(14.dp))
                            }
                            Column(Modifier.weight(1f)) {
                                Text(titleOf(n), color = ink, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                val sn = snippetOf(n)
                                if (sn.isNotEmpty()) Text(sn, color = mute, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.MEDIUM, java.text.DateFormat.SHORT)
                                        .format(java.util.Date(n.t)),
                                    color = mute, fontSize = 12.sp
                                )
                            }
                        }
                        Box(Modifier.fillMaxWidth().height(1.dp).background(line))
                    }
                }
            } else if (kindOf(id) == "sketch") {
                // ---- sketch editor ----
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("← Notes", color = accent, fontSize = 15.sp, modifier = Modifier.clickable { leave() }.padding(vertical = 8.dp))
                    Spacer(Modifier.weight(1f))
                    Text("Undo", color = if (pens.isNotEmpty()) accent else mute, fontSize = 15.sp, modifier = Modifier.clickable {
                        if (pens.isNotEmpty()) { redo = redo + pens.last(); pens = pens.dropLast(1); write(id, pensToJson(pens)) }
                    }.padding(vertical = 8.dp))
                    Text("Redo", color = if (redo.isNotEmpty()) accent else mute, fontSize = 15.sp, modifier = Modifier.clickable {
                        if (redo.isNotEmpty()) { pens = pens + redo.last(); redo = redo.dropLast(1); write(id, pensToJson(pens)) }
                    }.padding(vertical = 8.dp))
                    Text(if (confirm) "Tap again" else "Clear", color = accent, fontSize = 15.sp, modifier = Modifier.clickable {
                        if (!confirm) confirm = true else { pens = emptyList(); redo = emptyList(); write(id, "[]"); confirm = false }
                    }.padding(vertical = 8.dp))
                }
                Spacer(Modifier.height(6.dp))
                Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(18.dp))) {
                    Canvas(
                        Modifier.fillMaxSize()
                            .onSizeChanged { cw = it.width.toFloat(); chh = it.height.toFloat() }
                            .pointerInput(colorIdx, thick, cw) {
                                awaitEachGesture {
                                    val down = awaitFirstDown(requireUnconsumed = false)
                                    down.consume()
                                    val w = cw
                                    var pts = listOf(down.position.x / w, down.position.y / w)
                                    live = pts
                                    while (true) {
                                        val ev = awaitPointerEvent()
                                        val c = ev.changes.firstOrNull() ?: break
                                        if (!c.pressed) break
                                        c.consume()
                                        pts = pts + (c.position.x / w) + (c.position.y / w)
                                        live = pts
                                    }
                                    val eraser = colorIdx == 5
                                    val col = if (eraser) PAPER else PALETTE[colorIdx]
                                    pens = pens + Pen(col.toArgb(), WIDTHS[thick] * (if (eraser) 2.5f else 1f), pts)
                                    write(id, pensToJson(pens))
                                    redo = emptyList()
                                    live = emptyList()
                                    confirm = false
                                }
                            }
                    ) {
                        drawRect(PAPER)
                        drawPens(pens, size.width)
                        if (live.size >= 2) {
                            val eraser = colorIdx == 5
                            val col = if (eraser) PAPER else PALETTE[colorIdx]
                            drawPens(listOf(Pen(col.toArgb(), WIDTHS[thick] * (if (eraser) 2.5f else 1f), live)), size.width)
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    for (i in PALETTE.indices) {
                        Box(
                            Modifier.size(32.dp).clip(CircleShape).background(PALETTE[i])
                                .then(if (colorIdx == i) Modifier.border(3.dp, accent, CircleShape) else Modifier.border(1.dp, line, CircleShape))
                                .clickable { colorIdx = i }
                        )
                    }
                    Pill("Eraser", colorIdx == 5) { colorIdx = if (colorIdx == 5) 0 else 5 }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Brush", color = mute, fontSize = 14.sp)
                    for (i in 0 until 3) {
                        Box(
                            Modifier.size(36.dp).clip(CircleShape)
                                .then(if (thick == i) Modifier.border(2.dp, accent, CircleShape) else Modifier.border(1.dp, line, CircleShape))
                                .clickable { thick = i },
                            contentAlignment = Alignment.Center
                        ) { Box(Modifier.size((6 + i * 6).dp).clip(CircleShape).background(ink)) }
                    }
                    Spacer(Modifier.weight(1f))
                    Text("Save image", color = accent, fontSize = 15.sp, modifier = Modifier.clickable {
                        val ok = saveSketchImage(ctx, pens, cw, chh)
                        Toast.makeText(ctx, if (ok) "Saved to Pictures/Kotepad" else "Nothing to save yet", Toast.LENGTH_SHORT).show()
                    }.padding(vertical = 8.dp))
                }
            } else {
                // ---- text editor ----
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("← Notes", color = accent, fontSize = 16.sp, modifier = Modifier.clickable { leave() }.padding(vertical = 8.dp))
                    Spacer(Modifier.weight(1f))
                    Text("Undo", color = if (undoS.isNotEmpty()) accent else mute, fontSize = 15.sp,
                        modifier = Modifier.clickable { undoText() }.padding(vertical = 8.dp))
                    Text("Redo", color = if (redoS.isNotEmpty()) accent else mute, fontSize = 15.sp,
                        modifier = Modifier.clickable { redoText() }.padding(vertical = 8.dp))
                    Text(
                        "Share", color = accent, fontSize = 15.sp,
                        modifier = Modifier.clickable {
                            val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
                            try { ctx.startActivity(Intent.createChooser(send, "Share note")) } catch (e: Exception) { }
                        }.padding(vertical = 8.dp)
                    )
                    Text(
                        if (confirm) "Tap again" else "Delete", color = accent, fontSize = 15.sp,
                        modifier = Modifier.clickable {
                            if (!confirm) confirm = true
                            else { remove(id); text = ""; editId = null; status = ""; confirm = false }
                        }.padding(vertical = 8.dp)
                    )
                }
                Text(status, color = mute, fontSize = 12.sp)
                Spacer(Modifier.height(6.dp))
                Box(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) {
                    BasicTextField(
                        value = text,
                        onValueChange = { v ->
                            val now = android.os.SystemClock.elapsedRealtime()
                            if (now - lastPush > 800 || kotlin.math.abs(v.length - text.length) > 1) {
                                undoS.add(text); if (undoS.size > 100) undoS.removeAt(0); lastPush = now
                            }
                            redoS.clear(); text = v; confirm = false
                        },
                        textStyle = TextStyle(color = ink, fontSize = 18.sp, lineHeight = 27.sp),
                        cursorBrush = SolidColor(accent),
                        modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 320.dp),
                        decorationBox = { inner ->
                            Box { if (text.isEmpty()) Text("Start writing…", color = mute, fontSize = 18.sp); inner() }
                        }
                    )
                }
            }
        }
    }
}
