package com.studio.launcher

import android.content.SharedPreferences
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.format.DateTimeFormatter

// Focus log: what you made and for how long. Stored on the phone.
class FocusEntry(val t: Long, val what: String, val min: Int, val done: Boolean, val learn: String = "", val note: String = "")

// Minutes as "45 min", "1 h" or "1 h 30 min".
fun fmtDur(min: Int): String = if (min < 60) "$min min" else "${min / 60} h" + (if (min % 60 == 0) "" else " ${min % 60} min")

fun loadFocusLog(prefs: SharedPreferences): List<FocusEntry> = try {
    val a = org.json.JSONArray(prefs.getString("focusLog", "[]") ?: "[]")
    List(a.length()) { val o = a.getJSONObject(it); FocusEntry(o.getLong("t"), o.optString("w", ""), o.getInt("m"), o.optBoolean("d", true), o.optString("l", ""), o.optString("n", "")) }
} catch (e: Exception) { emptyList() }

fun logFocus(prefs: SharedPreferences, what: String, minutes: Int, done: Boolean, learn: String = "", note: String = "") {
    if (minutes < 1) return
    val list = (loadFocusLog(prefs) + FocusEntry(System.currentTimeMillis(), what.trim().take(80), minutes, done, learn.trim().take(60), note.trim().take(200))).takeLast(2000)
    val a = org.json.JSONArray()
    for (e in list) a.put(org.json.JSONObject().put("t", e.t).put("w", e.what).put("m", e.min).put("d", e.done).put("l", e.learn).put("n", e.note))
    prefs.edit().putString("focusLog", a.toString()).apply()
}

private fun dayOf(t: Long): LocalDate = java.time.Instant.ofEpochMilli(t).atZone(java.time.ZoneId.systemDefault()).toLocalDate()

fun focusSummary(prefs: SharedPreferences): String {
    val today = LocalDate.now()
    val m = loadFocusLog(prefs).filter { dayOf(it.t) == today }.sumOf { it.min }
    return if (m > 0) "${fmtDur(m)} today" else "No sessions today"
}

@Composable
fun FocusLogScreen(prefs: SharedPreferences, ink: Color, mute: Color, surface: Color, line: Color, accent: Color, onClose: () -> Unit) {
    var log by remember { mutableStateOf(loadFocusLog(prefs)) }
    var confirm by remember { mutableStateOf(false) }
    val today = LocalDate.now()
    val days = log.groupBy { dayOf(it.t) }
    val todayMin = days[today]?.sumOf { it.min } ?: 0
    val totalMin = log.sumOf { it.min }
    val weekMin = log.filter { !dayOf(it.t).isBefore(today.minusDays(6)) }.sumOf { it.min }
    var streak = 0
    var d = if (days.containsKey(today)) today else today.minusDays(1)
    while (days.containsKey(d)) { streak++; d = d.minusDays(1) }
    val fmt = DateTimeFormatter.ofPattern("EEE, MMM d")

    Box(
        Modifier.fillMaxSize().background(surface).pointerInput(Unit) { detectTapGestures { } }
            .padding(horizontal = 24.dp, vertical = 20.dp)
    ) {
        Column(Modifier.fillMaxSize()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Focus log", color = ink, fontSize = 30.sp, fontWeight = FontWeight.Light, modifier = Modifier.weight(1f))
                Text("Close", color = accent, fontSize = 16.sp, modifier = Modifier.clickable { onClose() }.padding(8.dp))
            }
            Spacer(Modifier.height(10.dp))
            val streakText = "$streak day" + (if (streak == 1) "" else "s")
            for (pair in listOf(listOf("Today" to fmtDur(todayMin), "Last 7 days" to fmtDur(weekMin)), listOf("Total" to fmtDur(totalMin), "Streak" to streakText))) {
                Row(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    for ((label, value) in pair) {
                        Column(Modifier.weight(1f)) {
                            Text(value, color = ink, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                            Text(label, color = mute, fontSize = 13.sp)
                        }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Box(Modifier.fillMaxWidth().height(1.5.dp).background(line))
            if (log.isEmpty()) Text("Nothing yet. Finish a focus session and it shows up here.", color = mute, fontSize = 15.sp, modifier = Modifier.padding(top = 24.dp))
            LazyColumn(Modifier.weight(1f)) {
                for (day in days.keys.sortedDescending()) {
                    val entries = days[day]!!.sortedByDescending { it.t }
                    item(key = "h$day") {
                        Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 4.dp)) {
                            Text(
                                if (day == today) "Today" else if (day == today.minusDays(1)) "Yesterday" else day.format(fmt),
                                color = mute, fontSize = 13.sp, modifier = Modifier.weight(1f)
                            )
                            Text(fmtDur(entries.sumOf { it.min }), color = mute, fontSize = 13.sp)
                        }
                    }
                    items(entries, key = { "e${it.t}" }) { e ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(if (e.done) "✓" else "·", color = if (e.done) accent else mute, fontSize = 16.sp, modifier = Modifier.width(24.dp))
                            Column(Modifier.weight(1f)) {
                                Text(e.what.ifBlank { "Focus" }, color = ink, fontSize = 17.sp, maxLines = 2)
                                if (e.learn.isNotBlank()) Text("Learning: ${e.learn}", color = mute, fontSize = 13.sp, maxLines = 2)
                                if (e.note.isNotBlank()) Text(e.note, color = mute, fontSize = 14.sp, maxLines = 4)
                                if (!e.done) Text("Stopped early", color = mute, fontSize = 12.sp)
                            }
                            Text(fmtDur(e.min), color = mute, fontSize = 14.sp)
                        }
                    }
                }
            }
            if (log.isNotEmpty()) {
                Text(
                    if (confirm) "Tap again to clear the whole log" else "Clear log", color = accent, fontSize = 15.sp,
                    modifier = Modifier.clickable {
                        if (!confirm) confirm = true else { prefs.edit().putString("focusLog", "[]").apply(); log = emptyList(); confirm = false }
                    }.padding(vertical = 12.dp)
                )
            }
        }
    }
}
